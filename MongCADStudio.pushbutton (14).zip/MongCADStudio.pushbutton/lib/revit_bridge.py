# -*- coding: utf-8 -*-
"""
Revit 2025 (.NET 8) API Bridge for pyRevit CPython 3 (Upgraded Scanner + Pure-Python Logic).

Capabilities:
1. get_revit_scan_metadata(doc):
   Reads Levels (with Project Base Point elevation), Pile Families across 3 categories
   (Generic Models, Structural Foundation, Structural Columns) with auto-guessed D/L parameters,
   and Structural Foundation families with auto-guessed Pile Cap (DaiMong) flags.
2. scan_revit_foundations(doc, options=None):
   - Supports Level selection + Z-range fallback for slabs/WallFoundations with LevelId <= 0
   - Internal Origin vs Shared Coordinates transform + Project Base Point Z calibration
   - Drops embedded lean concrete solids (<= 150 mm) inside families (_drop_lot)
   - Relaxed planar face tolerance (|nz| > 0.98) for flat/sloped bottom extraction
   - Smart unit-safe _param_mm (handles Length vs unitless Number parameters)
   - Structural Framing true cross-section slicing (_profile) + B > bang_b (800mm) split
   - Pile-to-cap ownership (Z +-300mm, XY +50mm) & Column-to-foundation ownership
   - Collinear beam/strip segment chaining, support (goi) linking, Mark grouping & health warnings
   - World XY instance tracking (worldInstances) for red-circle floor-plan locator
"""

import math
import re
import unicodedata

from poly_geom import (
    clean_polygon,
    is_rect_poly,
    min_area_rect,
    point_in_polygon,
    polygon_area,
)

FT_TO_MM = 304.8
MM_TO_FT = 1.0 / 304.8
COL_Z_TOL = 1000.0
PILE_Z_TOL = 300.0
BBOX_PAD = 60.0
LOT_MAX = 150.0


def _eid_value(eid):
    if eid is None:
        return 0
    return int(getattr(eid, "Value", getattr(eid, "IntegerValue", 0)))


def _tname(obj):
    try:
        return obj.GetType().Name
    except Exception:
        return ""


def _to_mm(feet_val):
    try:
        from Autodesk.Revit.DB import UnitTypeId, UnitUtils
        return float(UnitUtils.ConvertFromInternalUnits(float(feet_val), UnitTypeId.Millimeters))
    except Exception:
        return float(feet_val) * FT_TO_MM


def _to_ft(mm_val):
    return float(mm_val) * MM_TO_FT


def _round5(val):
    return int(round(float(val) / 5.0) * 5)


# ==================== PURE-PYTHON HELPERS (UNIT-TESTABLE) ====================

def normalize_plain(text):
    s = unicodedata.normalize("NFD", u"%s" % (text or u""))
    s = u"".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.replace(u"đ", u"d").replace(u"Đ", u"D").lower().strip()


def _normalize_tokens(text):
    p = normalize_plain(text)
    return re.sub(r"[_\-\./,;:+()\[\]]+", " ", p).strip()


def nat_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", u"%s" % (s or u""))]


def guess_dai(name):
    """Auto-detect whether a Structural Foundation family/type name is a Pile Cap (Đài cọc)."""
    p = _normalize_tokens(name)
    if not p:
        return False
    p_compact = re.sub(r"\s+", "", p)
    for h in ("dai coc", "dai mong", "pile cap", "mong coc"):
        if h in p or h.replace(" ", "") in p_compact:
            return True
    return bool(re.match(r"^dai(\s|\d|$)", p))


def guess_pile_family(name):
    """Auto-detect whether a Revit family name represents a Pile (Cọc)."""
    p = _normalize_tokens(name)
    if not p:
        return False
    p_compact = re.sub(r"\s+", "", p)
    # Exclude foundation caps, pads, beams, slabs, and columns first
    for bad in (
        "dai coc", "dai mong", "pile cap", "mong coc",
        "mong don", "mong bang", "dam mong", "giang mong",
        "wall foundation", "slab", "column",
    ):
        if bad in p or bad.replace(" ", "") in p_compact:
            return False
    if re.search(r"\bcot\b", p):
        return False
    if re.search(r"\bpile\b|micropile|spunpile", p) or "pile" in p_compact:
        return True
    if re.search(r"(?:^|\s)coc(?:\s|\d|ep|nhoi|ly|$)", p):
        return True
    for kw in ("phc", "spun", "bored", "driven", "caisson", "ly tam", "khoan nhoi", "coc ep"):
        if kw in p or kw.replace(" ", "") in p_compact:
            return True
    return False


def guess_pile_shape(name):
    p = _normalize_tokens(name)
    if any(k in p for k in ("vuong", "square", "sq", "hv", "200x200", "250x250", "300x300", "350x350", "400x400")):
        return u"Vuông"
    return u"Tròn"


def classify_name_signals(mark="", fam="", typ=""):
    """
    Inspect Vietnamese mark (preserving Đ vs D) + family/type names to infer foundation category.
    Returns one of: 'mong_coc', 'mong_bang', 'dam_mong', 'mong_don', or '' if neutral.
    """
    m_raw = (u"%s" % (mark or u"")).strip().upper()
    ft_sp = _normalize_tokens(u"%s %s" % (fam or u"", typ or u""))
    ft_compact = re.sub(r"\s+", "", ft_sp)

    # 1) Explicit Vietnamese Mark with diacritic distinction: ĐM / ĐC = Đài móng (pile cap)
    if re.match(r"^(ĐM|ĐC|MC|DC|PC)([\s_-]?\d|$|-)", m_raw):
        return "mong_coc"
    if re.match(r"^(MB)([\s_-]?\d|$|-)", m_raw):
        return "mong_bang"
    if re.match(r"^(GM|GD|TB|GB)([\s_-]?\d|$|-)", m_raw):
        return "dam_mong"
    if re.match(r"^(MĐ|MD)([\s_-]?\d|$|-)", m_raw):
        return "mong_don"

    # 2) Family / Type descriptive phrases
    if guess_dai(ft_sp):
        return "mong_coc"
    for k in ("mong bang", "strip footing", "wall foundation", "continuous footing"):
        if k in ft_sp or k.replace(" ", "") in ft_compact:
            return "mong_bang"
    for k in ("giang mong", "dam mong", "tie beam", "ground beam", "foundation beam", "grade beam"):
        if k in ft_sp or k.replace(" ", "") in ft_compact:
            return "dam_mong"
    for k in ("mong don", "isolated", "pad footing", "spread footing"):
        if k in ft_sp or k.replace(" ", "") in ft_compact:
            return "mong_don"

    # 3) Plain 'DM' mark without Đ: treat as dam_mong hint (will still yield to mong_coc if piles exist)
    if re.match(r"^DM([\s_-]?\d|$|-)", m_raw):
        return "dam_mong"
    return ""


def guess_pile_params(param_names):
    """Auto-guess Diameter/Size and Length parameter names from a family's numeric params."""
    if not param_names:
        return ("", "")

    def pick(hints):
        best_score = -1
        best_name = ""
        for nm in param_names:
            pl = normalize_plain(nm)
            for idx, h in enumerate(hints):
                if pl == h:
                    score = 100 - idx
                elif h in pl:
                    score = 50 - idx
                else:
                    continue
                if score > best_score:
                    best_score = score
                    best_name = nm
        return best_name

    d_hints = (
        "duong kinh",
        "duongkinh",
        "dk_coc",
        "dk",
        "diameter",
        "dia",
        "d_coc",
        "canh coc",
        "canh",
        "size",
        "width",
        "b",
        "d",
    )
    r_hints = (
        "ban kinh",
        "bankinh",
        "radius",
        "r_coc",
        "rad",
    )
    l_hints = (
        "chieu dai coc",
        "chieu dai",
        "chieudai",
        "dai coc",
        "length",
        "len",
        "l_coc",
        "chieu sau",
        "depth",
        "dai",
        "l",
    )
    d_param = pick(d_hints)
    if not d_param:
        d_param = pick(r_hints)
    l_param = pick([h for h in l_hints if normalize_plain(h) != normalize_plain(d_param)] or l_hints)
    if l_param == d_param and len(param_names) > 1:
        # Try picking a second distinct parameter for length
        others = [nm for nm in param_names if nm != d_param]
        l_param = pick_from(others, l_hints)
    return (d_param, l_param)


def pick_from(param_names, hints):
    best_score = -1
    best_name = ""
    for nm in param_names:
        pl = normalize_plain(nm)
        for idx, h in enumerate(hints):
            if pl == h:
                score = 100 - idx
            elif h in pl:
                score = 50 - idx
            else:
                continue
            if score > best_score:
                best_score = score
                best_name = nm
    return best_name


def _is_radius_param(name):
    pl = normalize_plain(name)
    return any(k in pl for k in ("ban kinh", "bankinh", "radius", "r_coc")) or pl == "r"


def _parse_diam_from_name(text):
    """Fallback pile diameter/width parser from Family/Type name like 'D300', '300x300', 'Cọc PHC D300'."""
    s = u"%s" % (text or u"")
    m = re.search(r"(\d{3})\s*[xX×]\s*(\d{3})", s)
    if m:
        v1, v2 = int(m.group(1)), int(m.group(2))
        if 120 <= min(v1, v2) <= 1500:
            return float(max(v1, v2))
    m = re.search(r"(?:^|[^A-Za-z0-9])[DdΦφØø]\s*[-_]?\s*(\d{3})(?!\d)", s)
    if m:
        v = int(m.group(1))
        if 120 <= v <= 1500:
            return float(v)
    return None


def _bbox_pts(pts):
    if not pts:
        return (0.0, 0.0, 0.0, 0.0)
    xs = [p["x"] for p in pts]
    ys = [p["y"] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))


def _pt_seg_dist(pt, a, b):
    dx = b["x"] - a["x"]
    dy = b["y"] - a["y"]
    l2 = dx * dx + dy * dy
    if l2 < 1e-12:
        return math.hypot(pt["x"] - a["x"], pt["y"] - a["y"])
    t = max(0.0, min(1.0, ((pt["x"] - a["x"]) * dx + (pt["y"] - a["y"]) * dy) / l2))
    return math.hypot(pt["x"] - (a["x"] + t * dx), pt["y"] - (a["y"] + t * dy))


def _seg_dist(a, b, c, d):
    def orient(p, q, r):
        return (q["x"] - p["x"]) * (r["y"] - p["y"]) - (q["y"] - p["y"]) * (r["x"] - p["x"])

    d1 = orient(c, d, a)
    d2 = orient(c, d, b)
    d3 = orient(a, b, c)
    d4 = orient(a, b, d)
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)) and d1 * d2 < 0 and d3 * d4 < 0:
        return 0.0
    return min(_pt_seg_dist(a, c, d), _pt_seg_dist(b, c, d), _pt_seg_dist(c, a, b), _pt_seg_dist(d, a, b))


def strip_params_from_poly(poly, p0, p1):
    """Compute strip/beam length, width b, eccentricity offset (+ left), and ext_len along p0->p1."""
    dx = p1["x"] - p0["x"]
    dy = p1["y"] - p0["y"]
    L = math.hypot(dx, dy)
    if L < 1e-6 or not poly:
        return None
    ux, uy = dx / L, dy / L
    nx, ny = -uy, ux
    us = [(p["x"] - p0["x"]) * ux + (p["y"] - p0["y"]) * uy for p in poly]
    vs = [(p["x"] - p0["x"]) * nx + (p["y"] - p0["y"]) * ny for p in poly]
    return {
        "len": L,
        "b": max(vs) - min(vs),
        "offset": (max(vs) + min(vs)) / 2.0,
        "ext_len": max(us) - min(us),
    }


def group_touching_segments(items, tol=20.0):
    """Group segments whose footprints touch/overlap (used for unmarked strip footings)."""
    n = len(items)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            d = _seg_dist(items[i]["p0"], items[i]["p1"], items[j]["p0"], items[j]["p1"])
            if d <= items[i]["reach"] + items[j]["reach"] + tol:
                ri, rj = find(i), find(j)
                if ri != rj:
                    parent[rj] = ri
    labels = {}
    out = []
    for i in range(n):
        r = find(i)
        if r not in labels:
            labels[r] = len(labels)
        out.append(labels[r])
    return out


def _collinear_match(s1_p0, s1_p1, s2_p0, s2_p1, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=None, b1=None, b2=None):
    """Check if two segments share near-collinear direction, compatible width, and small/bridged gap."""
    if b1 is not None and b2 is not None and abs(float(b1) - float(b2)) > max(50.0, 0.25 * min(float(b1), float(b2))):
        return False, False
    u1x, u1y = s1_p1["x"] - s1_p0["x"], s1_p1["y"] - s1_p0["y"]
    u2x, u2y = s2_p1["x"] - s2_p0["x"], s2_p1["y"] - s2_p0["y"]
    l1, l2 = math.hypot(u1x, u1y), math.hypot(u2x, u2y)
    if l1 < 1e-3 or l2 < 1e-3:
        return False, False
    ux, uy = u1x / l1, u1y / l1
    dot = abs((ux * u2x + uy * u2y) / l2)
    cos_tol = math.cos(math.radians(angle_tol_deg))
    if dot < cos_tol:
        return False, False
    # Check perpendicular offset between lines
    perp = abs((s2_p0["x"] - s1_p0["x"]) * (-uy) + (s2_p0["y"] - s1_p0["y"]) * ux)
    if perp > 140.0:
        return False, False

    # Project candidate endpoints onto ray starting at s1_p1 in direction (ux, uy)
    t_a = (s2_p0["x"] - s1_p1["x"]) * ux + (s2_p0["y"] - s1_p1["y"]) * uy
    t_b = (s2_p1["x"] - s1_p1["x"]) * ux + (s2_p1["y"] - s1_p1["y"]) * uy
    if t_a <= t_b:
        near_t, far_t, flip = t_a, t_b, False
        near_pt = s2_p0
    else:
        near_t, far_t, flip = t_b, t_a, True
        near_pt = s2_p1

    # Candidate must extend forward (or overlap slightly around s1_p1 without doubling back on s1)
    if far_t <= 50.0 or near_t < -min(450.0, l1 * 0.45):
        return False, False

    gap = max(0.0, near_t)
    if gap <= max_gap_mm:
        return True, flip

    # Allow chaining across intermediate pile caps / pads / columns up to 2200mm
    if gap <= 2200.0 and bridge_polys:
        mid_pt = {"x": (s1_p1["x"] + near_pt["x"]) / 2.0, "y": (s1_p1["y"] + near_pt["y"]) / 2.0}
        for poly in bridge_polys:
            if poly and point_in_polygon(mid_pt, poly, 160.0):
                return True, flip
    return False, False


def chain_collinear_segments(segs, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=None):
    """
    Merge collinear continuous segments (sharing same group/Mark) into continuous multi-span chains.
    Returns list of dicts with p0, p1, total_len, seg_lens, segments, etc.
    """
    if not segs:
        return []
    remaining = [dict(s) for s in segs]
    chains = []
    while remaining:
        seed = remaining.pop(0)
        p0, p1 = seed["p0"], seed["p1"]
        dx_s = p1["x"] - p0["x"]
        dy_s = p1["y"] - p0["y"]
        # Standard structural framing elevation view direction (East -> West for vertical beams; South -> North for horizontal beams):
        # - Vertical / steep-Y beams run Top (+Y) -> Bottom (-Y) so Grid B/C is Left and Grid A is Right.
        # - Horizontal beams run Left (-X) -> Right (+X) so Grid 1 is Left and Grid 2/3 is Right.
        is_vert_view = (abs(dx_s) <= 5.0) or (abs(dy_s) > abs(dx_s) * 1.15)
        if is_vert_view:
            if p1["y"] > p0["y"] + 5.0:
                p0, p1 = p1, p0
        else:
            if p1["x"] < p0["x"] - 5.0:
                p0, p1 = p1, p0
        run = [dict(seed, p0=p0, p1=p1)]

        # Grow forward from run[-1].p1
        changed = True
        while changed:
            changed = False
            tail = run[-1]
            tail_b = (tail.get("sp") or {}).get("b")
            for idx, cand in enumerate(remaining):
                cand_b = (cand.get("sp") or {}).get("b")
                ok, flip = _collinear_match(
                    tail["p0"], tail["p1"], cand["p0"], cand["p1"],
                    max_gap_mm, angle_tol_deg, bridge_polys, tail_b, cand_b,
                )
                if ok:
                    nxt = dict(cand)
                    if flip:
                        nxt["p0"], nxt["p1"] = cand["p1"], cand["p0"]
                    run.append(nxt)
                    remaining.pop(idx)
                    changed = True
                    break

        # Grow backward from run[0].p0
        changed = True
        while changed:
            changed = False
            head = run[0]
            head_b = (head.get("sp") or {}).get("b")
            for idx, cand in enumerate(remaining):
                cand_b = (cand.get("sp") or {}).get("b")
                ok, flip = _collinear_match(
                    head["p1"], head["p0"], cand["p0"], cand["p1"],
                    max_gap_mm, angle_tol_deg, bridge_polys, head_b, cand_b,
                )
                if ok:
                    prv = dict(cand)
                    if not flip:
                        prv["p0"], prv["p1"] = cand["p1"], cand["p0"]
                    run.insert(0, prv)
                    remaining.pop(idx)
                    changed = True
                    break

        run_p0 = run[0]["p0"]
        run_p1 = run[-1]["p1"]
        total_len = math.hypot(run_p1["x"] - run_p0["x"], run_p1["y"] - run_p0["y"])
        seg_lens = [s["sp"]["len"] for s in run]
        chains.append({
            "segments": run,
            "p0": run_p0,
            "p1": run_p1,
            "total_len": total_len if total_len > 10.0 else sum(seg_lens),
            "seg_lens": seg_lens,
            "rep": run[0],
        })
    return chains


def _is_rect_prof(poly):
    if not poly or len(poly) != 4:
        return False
    vs = sorted(set(round(p["x"], 0) for p in poly))
    zs = sorted(set(round(p["y"], 0) for p in poly))
    return len(vs) == 2 and len(zs) == 2


def extract_strip_section_dims(prof_polys, b_total, total_h, default_b_dam=300):
    """
    Extract exact (B_dam, canhTrai, canhPhai, hMep, hVat, vaiMepDam) from one or more
    2D cross-section polygons [(v, z)] in mm. Handles single trapezoidal/stepped solids
    as well as unjoined multi-solid families (e.g. bottom flange + top stem).
    """
    if not prof_polys:
        return None
    # Accept either a flat list of points [{"x":..,"y":..}] or list of polygons
    if isinstance(prof_polys[0], dict):
        polys = [prof_polys]
    else:
        polys = [p for p in prof_polys if p and len(p) >= 3]
    all_pts = [pt for poly in polys for pt in poly]
    if len(all_pts) < 3:
        return None

    z_lo = min(pt["y"] for pt in all_pts)
    z_hi = max(pt["y"] for pt in all_pts)
    h_span = z_hi - z_lo
    if h_span < 10.0:
        return None

    top_pts = [pt for pt in all_pts if pt["y"] >= z_hi - 5.0]
    bot_pts = [pt for pt in all_pts if pt["y"] <= z_lo + 5.0]
    if not top_pts or not bot_pts:
        return None

    v_top_min = min(pt["x"] for pt in top_pts)
    v_top_max = max(pt["x"] for pt in top_pts)
    v_bot_min = min(pt["x"] for pt in bot_pts)
    v_bot_max = max(pt["x"] for pt in bot_pts)

    b_bot = _round5(max(b_total, v_bot_max - v_bot_min))
    b_dam = max(150, min(b_bot, _round5(v_top_max - v_top_min)))
    if b_dam <= 0:
        b_dam = min(int(default_b_dam or 300), b_bot)

    canh_trai = max(0, _round5(v_top_min - v_bot_min))
    canh_phai = max(0, _round5(v_bot_max - v_top_max))
    # Keep canhTrai + B_dam + canhPhai consistent with b_bot when rounding
    diff_b = b_bot - (canh_trai + b_dam + canh_phai)
    if abs(diff_b) > 0 and (canh_trai > 0 or canh_phai > 0):
        if canh_trai >= canh_phai:
            canh_trai = max(0, canh_trai + diff_b)
        else:
            canh_phai = max(0, canh_phai + diff_b)

    # Pure rectangular beam/strip (no wings)
    if canh_trai < 25 and canh_phai < 25:
        h_val = max(300, _round5(total_h or h_span))
        return {
            "B_total": b_bot,
            "B_dam": b_bot,
            "canhTrai": 0,
            "canhPhai": 0,
            "hMep": min(h_val, max(150, int(round(h_val)))),
            "hVat": 0,
            "vaiMepDam": 0,
        }

    # Measure outer vertical wing edge height (hMep) at extreme left/right faces
    edge_hs = []
    if canh_trai >= 25:
        left_edge_zs = [pt["y"] - z_lo for pt in all_pts if pt["x"] <= v_bot_min + 8.0]
        if left_edge_zs:
            edge_hs.append(max(left_edge_zs))
    if canh_phai >= 25:
        right_edge_zs = [pt["y"] - z_lo for pt in all_pts if pt["x"] >= v_bot_max - 8.0]
        if right_edge_zs:
            edge_hs.append(max(right_edge_zs))

    h_mep_raw = max(edge_hs) if edge_hs else min(200.0, h_span * 0.35)
    h_mep = max(100, min(_round5(h_span), _round5(h_mep_raw)))

    # Measure haunch slope height (hVat) and shoulder width (vaiMepDam)
    # Look for intermediate vertices strictly between (z_lo + h_mep) and (z_hi - 5) or at stem shelf
    h_vat = 0
    vai_mep = 0
    shelf_zs = []
    for pt in all_pts:
        rel_z = pt["y"] - z_lo
        if rel_z >= h_mep - 2.0 and rel_z <= h_span - 5.0:
            if (canh_trai >= 25 and v_bot_min + 8.0 < pt["x"] <= v_top_min + 8.0) or (
                canh_phai >= 25 and v_top_max - 8.0 <= pt["x"] < v_bot_max - 8.0
            ):
                shelf_zs.append((pt["x"], rel_z))

    if shelf_zs:
        z_sh = max(z for _, z in shelf_zs)
        h_vat = max(0, min(_round5(h_span) - h_mep, _round5(z_sh - h_mep)))
        # Shoulder width near z_sh outside the stem wall
        sh_pts_l = [v_top_min - x for x, z in shelf_zs if abs(z - z_sh) <= 5.0 and x < v_top_min - 2.0]
        sh_pts_r = [x - v_top_max for x, z in shelf_zs if abs(z - z_sh) <= 5.0 and x > v_top_max + 2.0]
        sh_w = max(sh_pts_l + sh_pts_r) if (sh_pts_l or sh_pts_r) else 0.0
        vai_mep = max(0, min(200, _round5(sh_w)))

    return {
        "B_total": b_bot,
        "B_dam": b_dam,
        "canhTrai": canh_trai,
        "canhPhai": canh_phai,
        "hMep": h_mep,
        "hVat": h_vat,
        "vaiMepDam": vai_mep,
    }


def _samples(p0, p1, step=100.0):
    L = math.hypot(p1["x"] - p0["x"], p1["y"] - p0["y"])
    n = max(int(L / step), 1)
    return [
        {
            "x": p0["x"] + (p1["x"] - p0["x"]) * i / float(n),
            "y": p0["y"] + (p1["y"] - p0["y"]) * i / float(n),
        }
        for i in range(n + 1)
    ]


def _proj_t(pt, p0, p1):
    dx = p1["x"] - p0["x"]
    dy = p1["y"] - p0["y"]
    l2 = dx * dx + dy * dy
    if l2 < 1e-9:
        return 0.0
    return max(0.0, min(1.0, ((pt["x"] - p0["x"]) * dx + (pt["y"] - p0["y"]) * dy) / l2))


def _intersect_grids_along_line(p0, p1, grids, end_pad=600.0):
    """
    Find all Revit Grid lines crossing line segment p0->p1 at >= 15 deg angle.
    Returns sorted list of {"name": str, "u": float} where u is mm distance along p0->p1.
    """
    if not grids:
        return []
    dx = p1["x"] - p0["x"]
    dy = p1["y"] - p0["y"]
    seg_len = math.hypot(dx, dy)
    if seg_len < 10.0:
        return []
    ux, uy = dx / seg_len, dy / seg_len
    min_sin = math.sin(math.radians(15.0))
    hits = []
    for g in grids:
        gp0, gp1 = g.get("p0"), g.get("p1")
        if not gp0 or not gp1:
            continue
        dgx = gp1["x"] - gp0["x"]
        dgy = gp1["y"] - gp0["y"]
        glen = math.hypot(dgx, dgy)
        if glen < 10.0:
            continue
        gux, guy = dgx / glen, dgy / glen
        if abs(ux * guy - uy * gux) < min_sin:
            continue
        denom = uy * dgx - ux * dgy
        if abs(denom) < 1e-6:
            continue
        rx = gp0["x"] - p0["x"]
        ry = gp0["y"] - p0["y"]
        u = (ry * dgx - rx * dgy) / denom
        t = (ux * ry - uy * rx) / denom
        if -0.35 <= t <= 1.35 and -end_pad <= u <= seg_len + end_pad:
            hits.append({"name": g["name"], "u": u})
    hits.sort(key=lambda item: item["u"])
    # Deduplicate same grid label or nearly coincident parallel duplicates
    out = []
    for h in hits:
        if out and abs(h["u"] - out[-1]["u"]) < 120.0 and h["name"] == out[-1]["name"]:
            continue
        out.append(h)
    return out


def build_revit_candidates(foots, piles, strips, dams, cols, options=None, notes=None, grids=None):
    """
    Pure-Python post-processing, classification, ownership linking, collinear chaining,
    Mark grouping, and structural health validation on extracted Revit geometry dicts.
    """
    opts = dict(options or {})
    notes = list(notes or [])
    grids = list(grids or [])
    fam_set = set(opts.get("pile_families") or [])
    dai_set = set(opts.get("dai_fams") or [])
    bang_b = float(opts.get("bang_b") or 800.0)

    # 0) Classify Structural Framing / LocationCurve items accurately using multi-signal rules
    # (in case caller passed raw framing into dams/strips, re-balance using name signals & stepped profile)
    rebalanced_strips = []
    rebalanced_dams = []
    for seg in list(strips) + list(dams):
        seg_b = float((seg.get("sp") or {}).get("b") or 0.0)
        sig = classify_name_signals(seg.get("mark", ""), seg.get("fam", ""), seg.get("type", ""))
        is_forced = bool(seg.get("forced"))  # WallFoundation / StructuralFoundation LocationCurve
        prof_obj = seg.get("prof")
        is_stepped = bool(prof_obj and not (isinstance(prof_obj, dict) and prof_obj.get("kind") == "rect"))
        if is_forced or sig == "mong_bang" or is_stepped:
            rebalanced_strips.append(seg)
        elif sig == "dam_mong" and seg_b <= max(bang_b, 1000.0):
            rebalanced_dams.append(seg)
        elif seg_b >= bang_b:
            rebalanced_strips.append(seg)
        else:
            rebalanced_dams.append(seg)
    strips = rebalanced_strips
    dams = rebalanced_dams

    # 1) Assign piles -> smallest enclosing foundation (or strip)
    for p in piles:
        p["owner"] = None
        cands = []
        for f in foots:
            x0, y0, x1, y1 = f["bbox"]
            if not (x0 - BBOX_PAD <= p["x"] <= x1 + BBOX_PAD and y0 - BBOX_PAD <= p["y"] <= y1 + BBOX_PAD):
                continue
            if p["ztop"] < f["zmin"] - PILE_Z_TOL or p["zbot"] > f["zmax"] + PILE_Z_TOL:
                continue
            if point_in_polygon({"x": p["x"], "y": p["y"]}, f["poly"], 50.0):
                cands.append(f)
        if cands:
            owner_f = min(cands, key=lambda q: polygon_area(q["poly"]))
            owner_f["piles"].append(p)
            p["owner"] = owner_f

    # Promote nested pile shafts detected inside Pile Cap families if no external piles matched
    for f in foots:
        if not f["piles"] and f.get("nestedPiles"):
            for np_i, np_item in enumerate(f["nestedPiles"]):
                np_rec = dict(np_item)
                np_rec.setdefault("id", "%s-np-%d" % (f["id"], np_i + 1))
                np_rec["owner"] = f
                f["piles"].append(np_rec)
                piles.append(np_rec)

    def is_dai(f):
        if f["piles"]:
            return True
        if f.get("fam") in dai_set or f.get("type") in dai_set:
            return True
        if guess_dai(f.get("fam", "")) or guess_dai(f.get("type", "")):
            return True
        return classify_name_signals(f.get("mark", ""), f.get("fam", ""), f.get("type", "")) == "mong_coc"

    # Assign columns to foots BEFORE checking elongated slabs -> strips (since >=2 columns helps confirm Móng Băng)
    remaining_cols = []
    for c in cols:
        cx, cy = c["cx"], c["cy"]
        zmin, zmax = c["zmin"], c["zmax"]
        assigned = False
        for f in foots:
            x0, y0, x1, y1 = f["bbox"]
            if (x0 - BBOX_PAD <= cx <= x1 + BBOX_PAD and y0 - BBOX_PAD <= cy <= y1 + BBOX_PAD
                    and zmax >= f["zmin"] - 50.0 and zmin <= f["zmax"] + COL_Z_TOL):
                if point_in_polygon({"x": cx, "y": cy}, f["poly"], 5.0):
                    f["cots"].append(c)
                    assigned = True
                    break
        if not assigned:
            remaining_cols.append(c)

    # Re-route elongated/strip-labeled non-pile pads (e.g. Foundation Slab / stretched pad) -> MongBang or DamMong
    pad_foots = []
    for f in foots:
        if is_dai(f):
            pad_foots.append(f)
            continue
        b_dim = float(f.get("B") or 0.0)
        l_dim = float(f.get("L") or 0.0)
        short_s = min(b_dim, l_dim)
        long_s = max(b_dim, l_dim)
        aspect = long_s / max(1.0, short_s)
        sig = classify_name_signals(f.get("mark", ""), f.get("fam", ""), f.get("type", ""))
        is_slab_el = bool(f.get("is_slab")) or ("slab" in normalize_plain(f.get("fam", "")))
        n_cols = len(f.get("cots") or [])

        route_kind = None
        if sig == "mong_bang" or f.get("is_wall_fnd"):
            route_kind = "strip"
        elif sig == "dam_mong" and aspect >= 2.8 and short_s <= max(bang_b, 900.0):
            route_kind = "dam"
        elif sig != "mong_don" and long_s >= 2400.0 and (
            aspect >= 3.0
            or (aspect >= 2.2 and n_cols >= 2)
            or (is_slab_el and aspect >= 2.4)
        ):
            route_kind = "dam" if short_s < 500.0 else "strip"

        if route_kind in ("strip", "dam"):
            ang_rad = math.radians(float(f.get("ang") or 0.0))
            ux, uy = math.cos(ang_rad), math.sin(ang_rad)
            vx, vy = -uy, ux
            # Centerline runs along the longer OBB axis
            if b_dim > l_dim:
                ax_x, ax_y = ux, uy
                half_len = b_dim / 2.0
            else:
                ax_x, ax_y = vx, vy
                half_len = l_dim / 2.0
            p0 = {"x": f["cx"] - ax_x * half_len, "y": f["cy"] - ax_y * half_len}
            p1 = {"x": f["cx"] + ax_x * half_len, "y": f["cy"] + ax_y * half_len}
            seg_obj = {
                "id": f["id"],
                "level": f.get("level", ""),
                "mark": f.get("mark", ""),
                "fam": f.get("fam", ""),
                "type": f.get("type", ""),
                "poly": f["poly"],
                "bbox": f["bbox"],
                "zmin": f["zmin"],
                "zmax": f["zmax"],
                "p0": p0,
                "p1": p1,
                "sp": {"b": short_s, "len": long_s, "offset": 0.0},
                "cong": 0,
                "cots": list(f.get("cots") or []),
                "reach": short_s / 2.0,
                "prof": None,
                "forced": (route_kind == "strip"),
            }
            if route_kind == "strip":
                strips.append(seg_obj)
            else:
                dams.append(seg_obj)
        else:
            pad_foots.append(f)

    foots = pad_foots

    # 1B) Merge collinear Structural Framing beams sitting on top of / overlapping strip footings
    # (handles Revit models where Strip Footing is modeled as WallFoundation/Slab 300mm + Beam 300/600mm on top)
    if strips and dams:
        remaining_dams = []
        merged_sb_count = 0
        for d in dams:
            dp0, dp1 = d["p0"], d["p1"]
            dux, duy = dp1["x"] - dp0["x"], dp1["y"] - dp0["y"]
            d_len = math.hypot(dux, duy)
            if d_len < 1e-3:
                remaining_dams.append(d)
                continue
            dux /= d_len
            duy /= d_len
            dnx, dny = -duy, dux
            matched_strip = None
            for s in strips:
                sp0, sp1 = s["p0"], s["p1"]
                sux, suy = sp1["x"] - sp0["x"], sp1["y"] - sp0["y"]
                s_len = math.hypot(sux, suy)
                if s_len < 1e-3:
                    continue
                sux /= s_len
                suy /= s_len
                if abs(dux * sux + duy * suy) < math.cos(math.radians(6.0)):
                    continue
                perp = abs((sp0["x"] - dp0["x"]) * dnx + (sp0["y"] - dp0["y"]) * dny)
                if perp > max(150.0, s["sp"]["b"] * 0.55):
                    continue
                # Vertical contact/overlap (within 60mm)
                if d["zmin"] > s["zmax"] + 60.0 or d["zmax"] < s["zmin"] - 60.0:
                    continue
                # Longitudinal overlap >= 50% of shorter element
                t0 = (sp0["x"] - dp0["x"]) * dux + (sp0["y"] - dp0["y"]) * duy
                t1 = (sp1["x"] - dp0["x"]) * dux + (sp1["y"] - dp0["y"]) * duy
                ov = min(d_len, max(t0, t1)) - max(0.0, min(t0, t1))
                if ov >= max(400.0, 0.5 * min(d_len, s_len)):
                    matched_strip = s
                    break
            if matched_strip is not None:
                s = matched_strip
                slab_h = max(100, _round5(s["zmax"] - s["zmin"]))
                s["zmin"] = min(s["zmin"], d["zmin"])
                s["zmax"] = max(s["zmax"], d["zmax"])
                # Compute exact left/right wing overhang relative to the beam stem
                vs_bot = [(p["x"] - dp0["x"]) * dnx + (p["y"] - dp0["y"]) * dny for p in (s.get("poly") or [])]
                if vs_bot:
                    v_bot_min, v_bot_max = min(vs_bot), max(vs_bot)
                    d_off = float((d.get("sp") or {}).get("offset") or 0.0)
                    b_dam_m = max(150, _round5((d.get("sp") or {}).get("b") or 300.0))
                    v_top_min, v_top_max = d_off - b_dam_m / 2.0, d_off + b_dam_m / 2.0
                    # Ensure consistent sign when strip & beam centerlines run opposite directions
                    if (dux * (s["p1"]["x"] - s["p0"]["x"]) + duy * (s["p1"]["y"] - s["p0"]["y"])) < 0:
                        c_trai = max(0, _round5(v_bot_max - v_top_max))
                        c_phai = max(0, _round5(v_top_min - v_bot_min))
                    else:
                        c_trai = max(0, _round5(v_top_min - v_bot_min))
                        c_phai = max(0, _round5(v_bot_max - v_top_max))
                    base_dims = s.get("sectionDims") or {}
                    s["sectionDims"] = {
                        "B_total": max(400, _round5(v_bot_max - v_bot_min)),
                        "B_dam": b_dam_m,
                        "canhTrai": c_trai,
                        "canhPhai": c_phai,
                        "hMep": base_dims.get("hMep") or slab_h,
                        "hVat": base_dims.get("hVat") or 0,
                        "vaiMepDam": base_dims.get("vaiMepDam") or 0,
                    }
                if d.get("cots"):
                    s.setdefault("cots", []).extend(d["cots"])
                if not s.get("mark") and d.get("mark"):
                    s["mark"] = d["mark"]
                merged_sb_count += 1
            else:
                remaining_dams.append(d)
        dams = remaining_dams
        if merged_sb_count:
            notes.append(u"Đã tự động gộp %d dầm móng nằm trùng trên bản cánh thành tiết diện Móng Băng hoàn chỉnh." % merged_sb_count)

    # 2) Assign temporary Marks where Revit Mark is empty
    all_marks = set(
        [f["mark"] for f in foots if f.get("mark")]
        + [s["mark"] for s in strips if s.get("mark")]
        + [d["mark"] for d in dams if d.get("mark")]
    )
    counters = {}

    def auto_mark(prefix):
        n = counters.get(prefix, 0)
        while True:
            n += 1
            nm = u"%s%d" % (prefix, n)
            if nm not in all_marks:
                break
        counters[prefix] = n
        return nm

    def foot_order_key(f):
        return (round(f["zmin"] / 50.0), round(f["cx"] / 10.0), round(f["cy"] / 10.0))

    dai_list = sorted([f for f in foots if is_dai(f)], key=foot_order_key)
    don_list = sorted([f for f in foots if not is_dai(f)], key=foot_order_key)

    for f in don_list:
        f["ten"] = f["mark"] or auto_mark(u"MĐ?")
        f["loai"] = "MongDon"
    for f in dai_list:
        f["ten"] = f["mark"] or auto_mark(u"ĐM?")
        f["loai"] = "DaiMong"

    # Pre-collect bridge polygons (pads, strips, columns) so split beams over caps/columns chain cleanly
    bridge_polys = (
        [f["poly"] for f in foots if f.get("poly")]
        + [s["poly"] for s in strips if s.get("poly")]
        + [c["poly"] for c in cols if c.get("poly")]
    )

    unmarked_strips = [s for s in strips if not s.get("mark")]
    if unmarked_strips:
        gids = group_touching_segments(unmarked_strips)
        for s, g in zip(unmarked_strips, gids):
            s["g"] = g
        # Also bridge collinear unmarked strip segments separated by columns/pads
        tagged_s = [dict(s, _orig_idx=idx) for idx, s in enumerate(unmarked_strips)]
        for ch in chain_collinear_segments(tagged_s, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=bridge_polys):
            if len(ch["segments"]) > 1:
                base_g = unmarked_strips[ch["segments"][0]["_orig_idx"]]["g"]
                merge_gs = set(unmarked_strips[seg["_orig_idx"]]["g"] for seg in ch["segments"])
                for s in unmarked_strips:
                    if s["g"] in merge_gs:
                        s["g"] = base_g
        gorder = {}
        for s in sorted(unmarked_strips, key=lambda s: (round(s["p0"]["x"] / 10.0), round(s["p0"]["y"] / 10.0))):
            if s["g"] not in gorder:
                gorder[s["g"]] = auto_mark(u"MB?")
        for s in unmarked_strips:
            s["nhom"] = gorder[s["g"]]
    for s in strips:
        if s.get("mark"):
            s["nhom"] = s["mark"]
        elif not s.get("nhom"):
            s["nhom"] = auto_mark(u"MB?")

    # CRITICAL: Pre-chain unmarked DamMong segments BEFORE assigning temporary DM? marks
    # so a multi-segment beam without Revit Mark is treated as ONE continuous beam (SL=1), not N sub-beams!
    unmarked_idx = [i for i, d in enumerate(dams) if not d.get("mark")]
    if unmarked_idx:
        tagged_d = [dict(dams[i], _orig_idx=i) for i in unmarked_idx]
        tagged_d.sort(key=lambda d: (round(d["zmin"] / 50.0), round(d["p0"]["x"] / 10.0), round(d["p0"]["y"] / 10.0)))
        un_chains = chain_collinear_segments(tagged_d, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=bridge_polys)
        for ch in un_chains:
            tmp_mark = auto_mark(u"DM?")
            for seg in ch["segments"]:
                dams[seg["_orig_idx"]]["ten"] = tmp_mark
    for d in dams:
        if d.get("mark"):
            d["ten"] = d["mark"]
        elif not d.get("ten"):
            d["ten"] = auto_mark(u"DM?")

    # 3) Assign remaining columns -> strips / dams
    for c in remaining_cols:
        cx, cy = c["cx"], c["cy"]
        zmin, zmax = c["zmin"], c["zmax"]
        assigned = False
        for s in strips:
            x0, y0, x1, y1 = s["bbox"]
            if (x0 - BBOX_PAD <= cx <= x1 + BBOX_PAD and y0 - BBOX_PAD <= cy <= y1 + BBOX_PAD
                    and zmax >= s["zmin"] - 50.0 and zmin <= s["zmax"] + COL_Z_TOL):
                if point_in_polygon({"x": cx, "y": cy}, s["poly"], 5.0):
                    s.setdefault("cots", []).append(c)
                    assigned = True
                    break
        if assigned:
            continue
        for d in dams:
            x0, y0, x1, y1 = d["bbox"]
            if (x0 - BBOX_PAD <= cx <= x1 + BBOX_PAD and y0 - BBOX_PAD <= cy <= y1 + BBOX_PAD
                    and zmax >= d["zmin"] - 50.0 and zmin <= d["zmax"] + COL_Z_TOL):
                if point_in_polygon({"x": cx, "y": cy}, d["poly"], 5.0):
                    d.setdefault("cots", []).append(c)
                    break

    # 4) Link supports (gối đài / móng) for DamMong segments
    # NOTE: support projection along continuous chains is also computed accurately in 5C below;
    # keep per-segment warnings/quick links here for segment inspection.
    for d in dams:
        pts = _samples(d["p0"], d["p1"])
        dx0, dy0, dx1, dy1 = d["bbox"]
        ux, uy = d["p1"]["x"] - d["p0"]["x"], d["p1"]["y"] - d["p0"]["y"]
        dl = math.hypot(ux, uy) or 1.0
        ux, uy = ux / dl, uy / dl
        sup = []
        for f in foots:
            x0, y0, x1, y1 = f["bbox"]
            if x1 < dx0 - 150 or x0 > dx1 + 150 or y1 < dy0 - 150 or y0 > dy1 + 150:
                continue
            hit = None
            for i, pt in enumerate(pts):
                eps = 150.0 if i in (0, len(pts) - 1) else 0.0
                if point_in_polygon(pt, f["poly"], eps):
                    hit = i
                    break
            if hit is not None:
                us = [(q["x"] - d["p0"]["x"]) * ux + (q["y"] - d["p0"]["y"]) * uy for q in f["poly"]]
                proj_len = max(200.0, max(us) - min(us)) if us else max(f["B"], f["L"])
                sup.append((hit / float(max(len(pts) - 1, 1)), f["ten"], f["id"], proj_len))
        for end_i, t_end in ((0, 0.0), (len(pts) - 1, 1.0)):
            pt = pts[end_i]
            if any(point_in_polygon(pt, f["poly"], 150.0) for f in foots):
                continue
            for s in strips:
                if point_in_polygon(pt, s["poly"], 150.0) and not any(x[1] == s["nhom"] for x in sup):
                    us = [(q["x"] - d["p0"]["x"]) * ux + (q["y"] - d["p0"]["y"]) * uy for q in s["poly"]]
                    proj_len = max(200.0, max(us) - min(us)) if us else s["sp"]["b"]
                    sup.append((t_end, s["nhom"], s["id"], proj_len))
                    break
        sup.sort(key=lambda x: x[0])
        d["goi"] = sup

    # Check Mark collisions across MongDon & DaiMong
    mark_kind_map = {}
    for f in don_list + dai_list:
        mark_kind_map.setdefault(f["ten"], set()).add(f["loai"])

    candidates = []

    # 5A) Build MongDon & DaiMong candidates with full local transforms + health warnings
    for f in don_list + dai_list:
        ten = f["ten"]
        is_cap = f["loai"] == "DaiMong"
        B = max(300, _round5(f["B"]))
        L = max(300, _round5(f["L"]))
        H = max(150, _round5(f["zmax"] - f["zmin"]))
        ang = f.get("ang", 0.0)
        rad = math.radians(ang)
        ux, uy = math.cos(rad), math.sin(rad)
        vx, vy = -uy, ux
        cx, cy = f["cx"], f["cy"]

        local_poly = f.get("localPoly")
        if local_poly is None and f.get("poly"):
            loc = [
                {
                    "x": round((p["x"] - cx) * ux + (p["y"] - cy) * uy),
                    "y": round((p["x"] - cx) * vx + (p["y"] - cy) * vy),
                }
                for p in f["poly"]
            ]
            loc = clean_polygon(loc, 2.0)
            local_poly = loc if (len(loc) >= 3 and not is_rect_poly(loc)) else None

        # Columns in local OBB coordinates
        matched_cols = []
        overhang_msgs = []
        for c in f["cots"]:
            dx, dy = c["cx"] - cx, c["cy"] - cy
            lx = _round5(dx * ux + dy * uy)
            ly = _round5(dx * vx + dy * vy)
            matched_cols.append({"x": lx, "y": ly, "b": _round5(c["b"]), "h": _round5(c["h"]), "mark": c.get("mark", "")})
            if c.get("poly") and any(not point_in_polygon(vp, f["poly"], 5.0) for vp in c["poly"]):
                overhang_msgs.append(u"Cột %s chờm ra ngoài biên móng" % (c.get("mark") or ("Id%s" % c.get("id"))))

        c0 = matched_cols[0] if matched_cols else {"x": 0, "y": 0, "b": 300 if is_cap else 200, "h": 220 if is_cap else 200}
        extra_cols = [
            {"id": "rv-ec-%s-%d" % (f["id"], ci + 1), "x": ec["x"], "y": ec["y"], "b": ec["b"], "h": ec["h"]}
            for ci, ec in enumerate(matched_cols[1:])
        ]
        if not matched_cols:
            mode = "center"
        elif (not local_poly) and abs(c0["y"] - (L / 2.0 - c0["h"] / 2.0)) <= 30:
            mode = "top_flush"
        elif abs(c0["x"]) > 20 or abs(c0["y"]) > 20:
            mode = "custom"
        else:
            mode = "center"

        warns = []
        if not f.get("mark"):
            warns.append(u"Chưa có Mark trong Revit (nên điền Mark rồi quét lại)")
        if len(mark_kind_map.get(ten, ())) > 1:
            warns.append(u"Mark '%s' bị trùng giữa Móng đơn và Đài cọc" % ten)
        if not f["cots"]:
            warns.append(u"Không tìm thấy cột nằm trên móng")
        warns.extend(overhang_msgs)
        if f.get("note") == "bbox":
            warns.append(u"Không có mặt đáy phẳng, đang dùng hộp bao BoundingBox")

        cand_base = {
            "id": "rv-%s" % f["id"],
            "selected": True,
            "kind": "mong_coc" if is_cap else "mong_don",
            "ten": ten,
            "soLuong": 1,
            "B": B,
            "L": L,
            "H": H,
            "hMep": f.get("hMep") if f.get("hMep") is not None else min(200, int(round(H / 2.0))),
            "caoTrinh": round((f["zmax"] if is_cap else f["zmin"]) / 1000.0, 3),
            "shapePreset": "custom" if local_poly else None,
            "customPolygon": local_poly,
            "topPoly": f.get("topPoly"),
            "chamferLines": f.get("chamferLines"),
            "gocXoay": round(ang, 1) if abs(ang) >= 0.8 else None,
            "extraColumns": extra_cols if extra_cols else None,
            "cotB": max(120, c0["b"]),
            "cotH": max(120, c0["h"]),
            "viTriCotMode": mode,
            "lechTamX": c0["x"],
            "lechTamY": c0["y"],
            "revitMeta": {
                "fam": f.get("fam", ""),
                "type": f.get("type", ""),
                "level": f.get("level", ""),
                "lot": f.get("lot", 0),
                "nPiles": len(f["piles"]),
            },
            "worldInstances": [{
                "ten": ten,
                "kind": "mong_coc" if is_cap else "mong_don",
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "B": B,
                "L": L,
                "ang": round(ang, 1),
                "poly": [[round(p["x"], 1), round(p["y"], 1)] for p in (f.get("poly") or [])],
                "level": f.get("level", ""),
            }],
            "sourceType": "mong2_json",
        }

        if is_cap:
            p_list = f["piles"]
            local_piles = []
            for p in p_list:
                dx, dy = p["x"] - cx, p["y"] - cy
                local_piles.append({
                    "x": _round5(dx * ux + dy * uy),
                    "y": _round5(dx * vx + dy * vy),
                    "d": _round5(p["d"]),
                    "shape": "square" if "vu" in normalize_plain(p.get("shape", "")) or "square" in normalize_plain(p.get("shape", "")) else "circle",
                })

            if p_list:
                d_max = max(p["d"] for p in p_list)
                min_dist = None
                for ia in range(len(p_list)):
                    for ib in range(ia + 1, len(p_list)):
                        d_ab = math.hypot(p_list[ia]["x"] - p_list[ib]["x"], p_list[ia]["y"] - p_list[ib]["y"])
                        if min_dist is None or d_ab < min_dist:
                            min_dist = d_ab
                if min_dist is not None and d_max > 0 and min_dist < 3.0 * d_max - 1.0:
                    warns.append(u"Tim cọc gần nhất %.0f mm < 3D (%.0f mm)" % (min_dist, 3.0 * d_max))
            else:
                warns.append(u"Thuộc Family đài cọc nhưng không tìm thấy cọc nào bên trong")

            xs = sorted(set(int(round(p["x"] / 40.0) * 40) for p in local_piles))
            ys = sorted(set(int(round(p["y"] / 40.0) * 40) for p in local_piles))
            so_coc_x = max(1, len(xs) or 2)
            so_coc_y = max(1, len(ys) or 2)
            buoc_x = _round5((xs[-1] - xs[0]) / (len(xs) - 1)) if len(xs) > 1 else 600
            buoc_y = _round5((ys[-1] - ys[0]) / (len(ys) - 1)) if len(ys) > 1 else 600
            fallback_d = _parse_diam_from_name(u"%s %s" % (f.get("fam", ""), f.get("type", ""))) or int(opts.get("default_coc_d") or 200)
            coc_d = _round5(local_piles[0]["d"]) if local_piles else fallback_d
            coc_shape = local_piles[0]["shape"] if local_piles else guess_pile_shape(u"%s %s" % (f.get("fam", ""), f.get("type", "")))

            is_non_grid = len(local_piles) > 0 and (
                len(local_piles) in (3, 5) or (len(xs) * len(ys) != len(local_piles)) or bool(local_poly)
            )
            custom_piles = None
            if is_non_grid:
                custom_piles = [
                    {
                        "id": "p-%d" % (pi + 1),
                        "x": lp["x"],
                        "y": lp["y"],
                        "d": lp["d"] if lp["d"] != coc_d else None,
                    }
                    for pi, lp in enumerate(local_piles)
                ]

            pile_desc = ("%d cọc tự do" % len(custom_piles)) if custom_piles else (
                "%d×%d cọc Ø%s" % (so_coc_x, so_coc_y, coc_d) if local_piles else "Chưa thấy cọc"
            )
            cand_base.update({
                "customPiles": custom_piles,
                "cocD": coc_d,
                "cocHinh": coc_shape,
                "soCocX": so_coc_x,
                "soCocY": so_coc_y,
                "buocCocX": max(300, buoc_x),
                "buocCocY": max(300, buoc_y),
                "summary": u"Revit Đài Cọc · %s / %s · %s×%s×%s · %s%s" % (
                    f.get("fam", ""), f.get("type", ""), B, L, H, pile_desc,
                    (u" · tách BT lót") if f.get("lot") else u"",
                ),
                "warnings": warns,
            })
        else:
            cand_base.update({
                "summary": u"Revit Móng Đơn · %s / %s · %s×%s×%s · %d cột%s" % (
                    f.get("fam", ""), f.get("type", ""), B, L, H, max(1, len(matched_cols)),
                    (u" · tách BT lót") if f.get("lot") else u"",
                ),
                "warnings": warns,
            })
        candidates.append(cand_base)

    # 5B) Chain collinear MongBang segments & build candidates
    strip_groups = {}
    for s in strips:
        strip_groups.setdefault(s["nhom"], []).append(s)
    for nhom in sorted(strip_groups.keys(), key=nat_key):
        grp_segs = strip_groups[nhom]
        chains = chain_collinear_segments(grp_segs, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=bridge_polys)
        for ch_idx, ch in enumerate(chains):
            rep = ch["rep"]
            b_total = max(400, _round5(rep["sp"]["b"]))
            H = max(300, _round5(rep["zmax"] - rep["zmin"]))
            total_l = max(1200, _round5(ch["total_len"]))
            sdims = rep.get("sectionDims")
            if not sdims and rep.get("prof"):
                sdims = extract_strip_section_dims(rep["prof"], b_total, H, default_b_dam=int(opts.get("bang_b_dam") or 300))
            if sdims:
                b_total = max(400, int(sdims.get("B_total") or b_total))
                b_dam = min(int(sdims.get("B_dam") or 300), b_total)
                canh_trai = max(0, int(sdims.get("canhTrai", 0)))
                canh_phai = max(0, int(sdims.get("canhPhai", 0)))
                h_mep_val = max(100, min(H, int(sdims.get("hMep") or min(200, int(round(H * 0.35))))))
                h_vat_val = max(0, min(H - h_mep_val, int(sdims.get("hVat", 0))))
                vai_mep_val = max(0, int(sdims.get("vaiMepDam", 0)))
            else:
                b_dam = min(int(opts.get("bang_b_dam") or 300), b_total)
                offset = rep["sp"].get("offset", 0.0)
                canh_trai = max(0, _round5((b_total - b_dam) / 2.0 - offset))
                canh_phai = max(0, _round5(b_total - b_dam - canh_trai))
                if 0 < canh_trai < 50:
                    canh_phai = max(0, b_total - b_dam)
                    canh_trai = 0
                elif 0 < canh_phai < 50:
                    canh_trai = max(0, b_total - b_dam)
                    canh_phai = 0
                h_mep_val = min(200, max(120, int(round(H * 0.3))))
                h_vat_val = min(200, max(0, int(round(H * 0.3))))
                vai_mep_val = 50

            # Collect columns & Revit Grids along this strip chain
            ch_ux = ch["p1"]["x"] - ch["p0"]["x"]
            ch_uy = ch["p1"]["y"] - ch["p0"]["y"]
            ch_l = math.hypot(ch_ux, ch_uy) or 1.0
            ch_ux, ch_uy = ch_ux / ch_l, ch_uy / ch_l
            strip_grids = _intersect_grids_along_line(ch["p0"], ch["p1"], grids, end_pad=350.0)

            chain_cols = []
            seen_col_id = set()
            for seg in ch["segments"]:
                for c in seg.get("cots", []):
                    if c["id"] in seen_col_id:
                        continue
                    seen_col_id.add(c["id"])
                    u_c = (c["cx"] - ch["p0"]["x"]) * ch_ux + (c["cy"] - ch["p0"]["y"]) * ch_uy
                    us_c = [(p["x"] - ch["p0"]["x"]) * ch_ux + (p["y"] - ch["p0"]["y"]) * ch_uy for p in (c.get("poly") or [])]
                    cw_proj = max(150, _round5(max(us_c) - min(us_c))) if us_c else max(150, _round5(c["b"]))
                    chain_cols.append((u_c, cw_proj, c))
            chain_cols.sort(key=lambda x: x[0])

            strip_cols = []
            spans = []
            if len(chain_cols) >= 2:
                used_g = set()
                for k, (u_c, cw_proj, c) in enumerate(chain_cols):
                    lbl = str(k + 1)
                    align = "center"
                    best_g_idx = None
                    best_gd = 1e9
                    for gi, g in enumerate(strip_grids):
                        if gi in used_g:
                            continue
                        gd = abs(g["u"] - u_c)
                        if gd <= cw_proj * 0.75 + 120.0 and gd < best_gd:
                            best_gd = gd
                            best_g_idx = gi
                    if best_g_idx is not None:
                        used_g.add(best_g_idx)
                        g = strip_grids[best_g_idx]
                        lbl = g["name"]
                        rel_g = g["u"] - u_c
                        if rel_g < -cw_proj * 0.25:
                            align = "left"
                        elif rel_g > cw_proj * 0.25:
                            align = "right"
                    strip_cols.append({"trucLabel": lbl, "bCot": cw_proj, "align": align})
                    if k > 0:
                        prev_u, prev_cw, _ = chain_cols[k - 1]
                        dist_c = (u_c - prev_u) - (prev_cw + cw_proj) / 2.0
                        spans.append(max(800, _round5(dist_c)))
            elif len(ch["seg_lens"]) >= 2:
                for k in range(len(ch["seg_lens"]) + 1):
                    lbl = strip_grids[k]["name"] if k < len(strip_grids) else str(k + 1)
                    strip_cols.append({"trucLabel": lbl, "bCot": 300, "align": "center"})
                spans = [max(800, _round5(sl)) for sl in ch["seg_lens"]]
            else:
                half_sp = max(1200, _round5((total_l - 900) / 2.0))
                lbls = [g["name"] for g in strip_grids[:3]]
                while len(lbls) < 3:
                    lbls.append(["C", "B", "A"][len(lbls)])
                strip_cols = [
                    {"trucLabel": lbls[0], "bCot": 300, "align": "center"},
                    {"trucLabel": lbls[1], "bCot": 300, "align": "center"},
                    {"trucLabel": lbls[2], "bCot": 300, "align": "center"},
                ]
                spans = [half_sp, half_sp]

            warns = []
            if not rep.get("mark"):
                warns.append(u"Chưa có Mark trong Revit (tên nhóm tạm %s)" % nhom)
            if any(s.get("cong") for s in ch["segments"]):
                warns.append(u"Đoạn cong: B và lệch tâm tính gần đúng")
            if len(set((s.get("type"), _round5(s["sp"]["b"]), _round5(s["zmax"] - s["zmin"])) for s in grp_segs)) > 1:
                warns.append(u"Mark %s dùng cho các đoạn Móng băng khác B/H/Type" % nhom)

            # Keep explicit Mark unchanged so Step 6 consolidates identical Marks into 1 typical with SL summed!
            name_out = nhom if (rep.get("mark") or len(chains) == 1) else ("%s-%d" % (nhom, ch_idx + 1))
            ch_cx = (ch["p0"]["x"] + ch["p1"]["x"]) / 2.0
            ch_cy = (ch["p0"]["y"] + ch["p1"]["y"]) / 2.0
            ch_ang = math.degrees(math.atan2(ch["p1"]["y"] - ch["p0"]["y"], ch["p1"]["x"] - ch["p0"]["x"]))
            ux, uy = math.cos(math.radians(ch_ang)), math.sin(math.radians(ch_ang))
            vx, vy = -uy, ux
            hb = b_total / 2.0
            strip_poly = [
                [round(ch["p0"]["x"] - vx * hb, 1), round(ch["p0"]["y"] - vy * hb, 1)],
                [round(ch["p1"]["x"] - vx * hb, 1), round(ch["p1"]["y"] - vy * hb, 1)],
                [round(ch["p1"]["x"] + vx * hb, 1), round(ch["p1"]["y"] + vy * hb, 1)],
                [round(ch["p0"]["x"] + vx * hb, 1), round(ch["p0"]["y"] + vy * hb, 1)],
            ]
            ct_top = round(rep["zmax"] / 1000.0, 3)
            ct_bot = round(ct_top - H / 1000.0, 3)

            candidates.append({
                "id": "rv-mb-%s-%d" % (rep["id"], ch_idx),
                "selected": True,
                "kind": "mong_bang",
                "ten": name_out,
                "soLuong": 1,
                "B": b_total,
                "L": total_l,
                "H": H,
                "hMep": h_mep_val,
                "hVat": h_vat_val,
                "vaiMepDam": vai_mep_val,
                "caoTrinh": ct_top,
                "cotB": strip_cols[0]["bCot"],
                "cotH": 300,
                "viTriCotMode": "center",
                "lechTamX": 0,
                "lechTamY": 0,
                "B_dam": b_dam,
                "canhTrai": canh_trai,
                "canhPhai": canh_phai,
                "stripCols": strip_cols,
                "spans": spans,
                "revitMeta": {"fam": "Strip", "type": rep.get("type", ""), "level": rep.get("level", ""), "nSegs": len(ch["segments"])},
                "worldInstances": [{
                    "ten": name_out,
                    "kind": "mong_bang",
                    "cx": round(ch_cx, 1),
                    "cy": round(ch_cy, 1),
                    "B": b_total,
                    "L": total_l,
                    "ang": round(ch_ang, 1),
                    "poly": strip_poly,
                    "p0": [round(ch["p0"]["x"], 1), round(ch["p0"]["y"], 1)],
                    "p1": [round(ch["p1"]["x"], 1), round(ch["p1"]["y"], 1)],
                    "level": rep.get("level", ""),
                }],
                "sourceType": "mong2_json",
                "summary": u"Revit Móng Băng · %s · B=%s (%s/%s/%s) · H=%s (mép %s/vát %s) · Cote %+.3f/%+.3f m · L=%s (%d đoạn)" % (
                    rep.get("type", ""), b_total, canh_trai, b_dam, canh_phai, H, h_mep_val, h_vat_val, ct_top, ct_bot, total_l, len(ch["segments"])
                ),
                "warnings": warns,
            })

    # 5C) Chain collinear DamMong segments & link true projected Đài Móng / Columns / Revit Grids
    dam_groups = {}
    for d in dams:
        dam_groups.setdefault(d["ten"], []).append(d)
    for d_name in sorted(dam_groups.keys(), key=nat_key):
        grp_d = dam_groups[d_name]
        chains = chain_collinear_segments(grp_d, max_gap_mm=450.0, angle_tol_deg=6.0, bridge_polys=bridge_polys)
        for ch_idx, ch in enumerate(chains):
            rep = ch["rep"]
            B_dam = max(180, _round5(rep["sp"]["b"]))
            beam_zmax = max(seg["zmax"] for seg in ch["segments"])
            beam_zmin = min(seg["zmin"] for seg in ch["segments"])
            H_dam = max(250, _round5(beam_zmax - beam_zmin))
            ch_ux = ch["p1"]["x"] - ch["p0"]["x"]
            ch_uy = ch["p1"]["y"] - ch["p0"]["y"]
            ch_l = math.hypot(ch_ux, ch_uy) or 1.0
            ch_ux, ch_uy = ch_ux / ch_l, ch_uy / ch_l
            ch_nx, ch_ny = -ch_uy, ch_ux
            total_l = max(1200, _round5(ch_l))

            # Helper to project any polygon onto beam local (u, v) coords relative to ch["p0"]
            def _proj_poly_uv(poly_pts):
                us = [(q["x"] - ch["p0"]["x"]) * ch_ux + (q["y"] - ch["p0"]["y"]) * ch_uy for q in poly_pts]
                vs = [(q["x"] - ch["p0"]["x"]) * ch_nx + (q["y"] - ch["p0"]["y"]) * ch_ny for q in poly_pts]
                return min(us), max(us), min(vs), max(vs)

            # Collect all structural columns lying along this continuous beam axis
            beam_cols = []
            seen_col_ids = set()
            for c in cols:
                if c["id"] in seen_col_ids:
                    continue
                if c.get("poly"):
                    cu0, cu1, cv0, cv1 = _proj_poly_uv(c["poly"])
                    if cv1 >= -B_dam / 2.0 - 80.0 and cv0 <= B_dam / 2.0 + 80.0 and -250.0 <= cu1 and cu0 <= ch_l + 250.0:
                        if c["zmax"] >= beam_zmin - 200.0 and c["zmin"] <= beam_zmax + 400.0:
                            seen_col_ids.add(c["id"])
                            beam_cols.append({
                                "id": c["id"],
                                "mark": c.get("mark", ""),
                                "u_min": cu0,
                                "u_max": cu1,
                                "u_mid": (cu0 + cu1) / 2.0,
                                "col_w": max(150, _round5(cu1 - cu0)),
                                "zmin": c["zmin"],
                                "zmax": c["zmax"],
                            })
            beam_cols.sort(key=lambda item: item["u_mid"])

            # Find all Đài Móng / Móng Đơn / Crossing Strips along this continuous beam chain
            raw_sups = []
            seen_sup_ids = set()
            for f in foots:
                if not f.get("poly"):
                    continue
                if f["zmax"] < beam_zmin - 450.0 or f["zmin"] > beam_zmax + 450.0:
                    continue
                u0, u1, v0, v1 = _proj_poly_uv(f["poly"])
                if v1 < -B_dam / 2.0 - 150.0 or v0 > B_dam / 2.0 + 150.0:
                    continue
                if u1 < -250.0 or u0 > ch_l + 250.0:
                    continue
                seen_sup_ids.add(f["id"])
                sup_len = max(300, _round5(u1 - u0))
                dai_h = max(150, _round5(f["zmax"] - f["zmin"]))
                dai_top_off = _round5(beam_zmax - f["zmax"])
                # Find structural column seated on this pad
                pad_cols = [bc for bc in beam_cols if u0 - 150.0 <= bc["u_mid"] <= u1 + 150.0]
                if not pad_cols and f.get("cots"):
                    for fc in f["cots"]:
                        if fc.get("poly"):
                            fcu0, fcu1, _, _ = _proj_poly_uv(fc["poly"])
                            pad_cols.append({
                                "u_min": fcu0, "u_max": fcu1, "u_mid": (fcu0 + fcu1) / 2.0,
                                "col_w": max(150, _round5(fcu1 - fcu0)), "mark": fc.get("mark", ""),
                            })
                c0 = pad_cols[0] if pad_cols else None
                col_w = c0["col_w"] if c0 else B_dam
                col_off = max(col_w / 2.0, min(sup_len - col_w / 2.0, _round5(c0["u_mid"] - u0))) if c0 else None
                raw_sups.append({
                    "id": f["id"],
                    "supportName": f["ten"],
                    "trucLabel": f["ten"],
                    "u_min": u0,
                    "u_max": u1,
                    "u_mid": (u0 + u1) / 2.0,
                    "len": sup_len,
                    "daiH": dai_h,
                    "daiTopOffset": dai_top_off,
                    "colW": col_w,
                    "colH": min(700, H_dam),
                    "colOffset": col_off,
                    "col_u_mid": c0["u_mid"] if c0 else None,
                    "isPad": True,
                })

            # Check crossing strip footings at ends (or mid) if not covered by pad
            for s in strips:
                if not s.get("poly") or s["id"] in seen_sup_ids:
                    continue
                if s["zmax"] < beam_zmin - 450.0 or s["zmin"] > beam_zmax + 450.0:
                    continue
                u0, u1, v0, v1 = _proj_poly_uv(s["poly"])
                if v1 < -B_dam / 2.0 - 150.0 or v0 > B_dam / 2.0 + 150.0:
                    continue
                # Must cross cleanly (not collinear with beam itself)
                if (u1 - u0) > ch_l * 0.75:
                    continue
                if u1 < -200.0 or u0 > ch_l + 200.0:
                    continue
                u_mid_s = (u0 + u1) / 2.0
                if any(rs["u_min"] - 100.0 <= u_mid_s <= rs["u_max"] + 100.0 for rs in raw_sups):
                    continue
                sup_len = max(300, _round5(u1 - u0))
                dai_h = max(150, _round5(s["zmax"] - s["zmin"]))
                dai_top_off = _round5(beam_zmax - s["zmax"])
                raw_sups.append({
                    "id": s["id"],
                    "supportName": s["nhom"],
                    "trucLabel": s["nhom"],
                    "u_min": u0,
                    "u_max": u1,
                    "u_mid": u_mid_s,
                    "len": sup_len,
                    "daiH": dai_h,
                    "daiTopOffset": dai_top_off,
                    "colW": min(sup_len, B_dam),
                    "colH": min(700, H_dam),
                    "colOffset": None,
                    "col_u_mid": None,
                    "isPad": True,
                })

            # Also add standalone columns resting along beam outside any pad/strip support
            for bc in beam_cols:
                if any(rs["u_min"] - 180.0 <= bc["u_mid"] <= rs["u_max"] + 180.0 for rs in raw_sups):
                    continue
                cw = bc["col_w"]
                raw_sups.append({
                    "id": "col-%s" % bc["id"],
                    "supportName": bc["mark"] or "Cột",
                    "trucLabel": bc["mark"] or "C",
                    "u_min": bc["u_min"],
                    "u_max": bc["u_max"],
                    "u_mid": bc["u_mid"],
                    "len": cw,
                    "daiH": H_dam,
                    "daiTopOffset": 0,
                    "colW": cw,
                    "colH": min(700, H_dam),
                    "colOffset": round(cw / 2.0),
                    "col_u_mid": bc["u_mid"],
                    "isPad": False,
                })

            raw_sups.sort(key=lambda rs: rs["u_mid"])

            # Merge/drop overlapping supports if two pads touch at virtually the same center (<150mm)
            dedup_sups = []
            for rs in raw_sups:
                if dedup_sups and rs["u_min"] < dedup_sups[-1]["u_max"] - 80.0 and abs(rs["u_mid"] - dedup_sups[-1]["u_mid"]) < 250.0:
                    if rs["isPad"] and not dedup_sups[-1]["isPad"]:
                        dedup_sups[-1] = rs
                else:
                    dedup_sups.append(rs)
            raw_sups = dedup_sups

            # Intersect Revit Grids with continuous beam line
            beam_grids = _intersect_grids_along_line(ch["p0"], ch["p1"], grids, end_pad=max(600.0, max((rs["len"] for rs in raw_sups), default=600.0)))
            used_grid_idxs = set()

            for rs in raw_sups:
                ref_u = rs["col_u_mid"] if rs["col_u_mid"] is not None else rs["u_mid"]
                best_gi = None
                best_gd = 1e9
                for gi, g in enumerate(beam_grids):
                    if gi in used_grid_idxs:
                        continue
                    if rs["u_min"] - 250.0 <= g["u"] <= rs["u_max"] + 250.0:
                        gd = abs(g["u"] - ref_u)
                        if gd < best_gd:
                            best_gd = gd
                            best_gi = gi
                if best_gi is not None:
                    used_grid_idxs.add(best_gi)
                    g = beam_grids[best_gi]
                    rs["trucLabel"] = g["name"]
                    rs["axisOffset"] = max(0, min(rs["len"], _round5(g["u"] - rs["u_min"])))
                    if rs["colOffset"] is None:
                        rs["colOffset"] = rs["axisOffset"]

            extra_grids = []
            if len(raw_sups) >= 2:
                origin_u = raw_sups[0]["u_min"]
                end_u = raw_sups[-1]["u_max"]
                for gi, g in enumerate(beam_grids):
                    if gi not in used_grid_idxs and (origin_u - 250.0) <= g["u"] <= (end_u + 250.0):
                        extra_grids.append({
                            "label": g["name"],
                            "posX": _round5(g["u"] - origin_u),
                        })

            if len(raw_sups) >= 2:
                supports = [
                    {
                        "trucLabel": rs["trucLabel"],
                        "supportName": rs["supportName"],
                        "len": rs["len"],
                        "colW": rs["colW"],
                        "colH": rs["colH"],
                        "daiH": rs["daiH"],
                        "daiTopOffset": rs["daiTopOffset"],
                        "axisOffset": rs.get("axisOffset"),
                        "colOffset": rs.get("colOffset"),
                    }
                    for rs in raw_sups
                ]
                spans = []
                for k in range(len(raw_sups) - 1):
                    clear_l = raw_sups[k + 1]["u_min"] - raw_sups[k]["u_max"]
                    spans.append(max(200, _round5(clear_l)))
                total_l = sum(s["len"] for s in supports) + sum(spans)
            else:
                # Fallback when 0 or 1 support detected
                lbl_a = beam_grids[0]["name"] if len(beam_grids) >= 1 else (raw_sups[0]["trucLabel"] if raw_sups else "B")
                lbl_b = beam_grids[-1]["name"] if len(beam_grids) >= 2 else "A"
                len_0 = raw_sups[0]["len"] if raw_sups else 1200
                dai_h0 = raw_sups[0]["daiH"] if raw_sups else H_dam
                supports = [
                    {"trucLabel": lbl_a, "len": len_0, "colW": B_dam, "colH": min(700, H_dam), "daiH": dai_h0, "daiTopOffset": 0},
                    {"trucLabel": lbl_b, "len": 1200, "colW": B_dam, "colH": min(700, H_dam), "daiH": dai_h0, "daiTopOffset": 0},
                ]
                spans = [max(800, total_l - len_0 - 1200)]

            warns = []
            if not rep.get("mark"):
                warns.append(u"Chưa có Mark trong Revit (tên tạm %s)" % d_name)
            if any(d.get("cong") for d in ch["segments"]):
                warns.append(u"Dầm cong: B và lệch tâm chỉ gần đúng")
            if len(raw_sups) == 0:
                warns.append(u"Dầm không gối vào đài/móng nào")
            elif len(raw_sups) == 1:
                warns.append(u"Dầm chỉ gối vào 1 đài/móng, chưa thấy gối thứ hai")
            if not beam_grids:
                warns.append(u"Chưa bắt được đường Grid giao cắt — đang dùng tên gối tạm")

            sup_desc = " - ".join(s["trucLabel"] for s in supports)
            # Keep same explicit Mark so identical separate continuous beams consolidate into 1 typical beam with summed SL!
            name_out = d_name if (rep.get("mark") or len(chains) == 1) else ("%s-%d" % (d_name, ch_idx + 1))
            ch_cx = (ch["p0"]["x"] + ch["p1"]["x"]) / 2.0
            ch_cy = (ch["p0"]["y"] + ch["p1"]["y"]) / 2.0
            ch_ang = math.degrees(math.atan2(ch["p1"]["y"] - ch["p0"]["y"], ch["p1"]["x"] - ch["p0"]["x"]))
            ux, uy = math.cos(math.radians(ch_ang)), math.sin(math.radians(ch_ang))
            vx, vy = -uy, ux
            hb = B_dam / 2.0
            beam_poly = [
                [round(ch["p0"]["x"] - vx * hb, 1), round(ch["p0"]["y"] - vy * hb, 1)],
                [round(ch["p1"]["x"] - vx * hb, 1), round(ch["p1"]["y"] - vy * hb, 1)],
                [round(ch["p1"]["x"] + vx * hb, 1), round(ch["p1"]["y"] + vy * hb, 1)],
                [round(ch["p0"]["x"] + vx * hb, 1), round(ch["p0"]["y"] + vy * hb, 1)],
            ]

            candidates.append({
                "id": "rv-dm-%s-%d" % (rep["id"], ch_idx),
                "selected": True,
                "kind": "dam_mong",
                "ten": name_out,
                "soLuong": 1,
                "B": B_dam,
                "L": total_l,
                "H": H_dam,
                "caoTrinh": round(beam_zmax / 1000.0, 3),
                "cotB": B_dam,
                "cotH": H_dam,
                "viTriCotMode": "center",
                "lechTamX": 0,
                "lechTamY": 0,
                "B_dam": B_dam,
                "supports": supports,
                "spans": spans,
                "extraGrids": extra_grids if extra_grids else None,
                "revitMeta": {"fam": "Beam", "type": rep.get("type", ""), "level": rep.get("level", ""), "nSegs": len(ch["segments"])},
                "worldInstances": [{
                    "ten": name_out,
                    "kind": "dam_mong",
                    "cx": round(ch_cx, 1),
                    "cy": round(ch_cy, 1),
                    "B": B_dam,
                    "L": total_l,
                    "ang": round(ch_ang, 1),
                    "poly": beam_poly,
                    "p0": [round(ch["p0"]["x"], 1), round(ch["p0"]["y"], 1)],
                    "p1": [round(ch["p1"]["x"], 1), round(ch["p1"]["y"], 1)],
                    "level": rep.get("level", ""),
                }],
                "sourceType": "mong2_json",
                "summary": u"Revit Dầm Móng · %s · %s×%s · L=%s (%d khúc nối) · Trục: %s" % (
                    rep.get("type", ""), B_dam, H_dam, total_l, len(ch["segments"]), sup_desc
                ),
                "warnings": warns,
            })

    # 6) Consolidate ALL items sharing the same (kind, Mark) into ONE typical configuration + sum SL!
    dim_sigs_by_mark = {}
    for c in candidates:
        poly_sig = ("%dv" % len(c["customPolygon"])) if c.get("customPolygon") else "rect"
        pile_sig = str(c["revitMeta"]["nPiles"]) if c["kind"] == "mong_coc" else "0"
        sig = (c["kind"], c["B"], c["L"], c["H"], poly_sig, pile_sig)
        dim_sigs_by_mark.setdefault((c["kind"], c["ten"].strip().upper()), set()).add(sig)

    grouped = []
    by_key = {}
    for c in candidates:
        mark_key = c["ten"].strip().upper()
        k_mark = (c["kind"], mark_key)
        if len(dim_sigs_by_mark.get(k_mark, ())) > 1:
            msg_conflict = u"Mark '%s' có nhiều kích thước/số cọc hơi khác nhau — đã gom chung thành 1 điển hình (kiểm tra lại)" % c["ten"]
            if msg_conflict not in c["warnings"]:
                c["warnings"].append(msg_conflict)

        # Group strictly by (kind, Mark) when Mark is explicit; only split auto/unmarked if geometry differs
        is_auto = mark_key.endswith("?") or ("?" in mark_key)
        if is_auto:
            poly_sig = ("%dv" % len(c["customPolygon"])) if c.get("customPolygon") else "rect"
            pile_sig = ("%sp" % len(c["customPiles"])) if c.get("customPiles") else ("%sx%s" % (c.get("soCocX", 0), c.get("soCocY", 0)))
            key = "%s::%s::%sx%sx%s::%s::%s" % (c["kind"], mark_key, c["B"], c["L"], c["H"], poly_sig, pile_sig)
        else:
            key = "%s::%s" % (c["kind"], mark_key)

        if key in by_key:
            g = grouped[by_key[key]]
            g["soLuong"] += c["soLuong"]
            g.setdefault("worldInstances", []).extend(c.get("worldInstances") or [])
            for w in c["warnings"]:
                if w not in g["warnings"]:
                    g["warnings"].append(w)
        else:
            by_key[key] = len(grouped)
            grouped.append(c)

    # Summary statistics messages
    orphan_piles = [p for p in piles if p.get("owner") is None]
    if fam_set and not piles:
        notes.append(u"Không tìm thấy cọc thuộc family đã chọn trong Generic Models / Structural Foundation / Structural Columns.")
    elif piles:
        msg_p = u"Cọc: %d (thuộc đài %d, ngoài đài %d)" % (len(piles), len(piles) - len(orphan_piles), len(orphan_piles))
        if orphan_piles:
            msg_p += u" [Id ngoài đài: %s]" % ", ".join(str(p["id"]) for p in orphan_piles[:6])
        notes.append(msg_p)

    n_don = sum(1 for c in grouped if c["kind"] == "mong_don")
    n_bang = sum(1 for c in grouped if c["kind"] == "mong_bang")
    n_coc = sum(1 for c in grouped if c["kind"] == "mong_coc")
    n_dam = sum(1 for c in grouped if c["kind"] == "dam_mong")
    notes.insert(
        0,
        u"Quét Revit hoàn tất: %d loại Móng Đơn, %d Móng Băng (B>%gmm), %d Đài Cọc, %d Dầm Móng."
        % (n_don, n_bang, bang_b, n_coc, n_dam),
    )

    return {
        "candidates": grouped,
        "messages": notes,
        "stats": {
            "footsRaw": len(foots),
            "piles": len(piles),
            "orphanPiles": len(orphan_piles),
            "stripsRaw": len(strips),
            "damsRaw": len(dams),
            "cols": len(cols),
        },
    }


# ==================== REVIT 2025 API EXTRACTION ====================

def _revit_categories():
    from Autodesk.Revit.DB import BuiltInCategory
    bic_gm = BuiltInCategory.OST_GenericModel
    bic_sf = getattr(BuiltInCategory, "OST_StructuralFoundation", getattr(BuiltInCategory, "OST_StructuralFoundations", None))
    bic_sc = BuiltInCategory.OST_StructuralColumns
    bic_fr = BuiltInCategory.OST_StructuralFraming
    return bic_gm, bic_sf, bic_sc, bic_fr


def _pstr(el, bip):
    try:
        p = el.get_Parameter(bip)
        if p is not None and p.HasValue:
            return p.AsString() or p.AsValueString() or ""
    except Exception:
        pass
    return ""


def _mark(el):
    from Autodesk.Revit.DB import BuiltInParameter
    m = _pstr(el, BuiltInParameter.ALL_MODEL_MARK).strip()
    if m:
        return m
    p = el.LookupParameter("Mark")
    if p is not None and p.HasValue:
        return (p.AsString() or p.AsValueString() or "").strip()
    return ""


def _fam_type(el, doc=None):
    from Autodesk.Revit.DB import BuiltInParameter
    fam, typ = "", ""
    try:
        sym = el.Symbol
        try:
            fam = sym.FamilyName
        except Exception:
            fam = sym.Family.Name
        try:
            typ = sym.Name
        except Exception:
            typ = _pstr(sym, BuiltInParameter.SYMBOL_NAME_PARAM)
    except Exception:
        pass
    if not fam and doc is not None:
        try:
            t = doc.GetElement(el.GetTypeId())
            typ = t.Name
            fam = getattr(t, "FamilyName", "") or ""
        except Exception:
            pass
        fam = fam or u"Foundation Slab"
    return fam or "", typ or ""


def _is_slab(el):
    return _tname(el) in ("Floor",)


def _level_id(el):
    from Autodesk.Revit.DB import BuiltInParameter
    try:
        lid = el.LevelId
        if lid is not None and _eid_value(lid) > 0:
            return _eid_value(lid)
    except Exception:
        pass
    for bip in (
        BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM,
        BuiltInParameter.FAMILY_LEVEL_PARAM,
        BuiltInParameter.SCHEDULE_LEVEL_PARAM,
    ):
        try:
            p = el.get_Parameter(bip)
            if p is not None and p.HasValue:
                v = _eid_value(p.AsElementId())
                if v > 0:
                    return v
        except Exception:
            continue
    return -1


def _list_numeric_params(el):
    from Autodesk.Revit.DB import StorageType
    names = []
    seen = set()
    sources = [el]
    try:
        if getattr(el, "Symbol", None) is not None:
            sources.append(el.Symbol)
    except Exception:
        pass
    for src in sources:
        try:
            for p in src.Parameters:
                try:
                    if p.StorageType == StorageType.Double:
                        nm = p.Definition.Name
                        if nm not in seen:
                            seen.add(nm)
                            names.append(nm)
                except Exception:
                    continue
        except Exception:
            continue
    names.sort(key=lambda s: s.lower())
    return names


def _param_mm(el, name, min_sane=50.0, max_sane=40000.0):
    """
    Bug-fixed parameter reader:
    Checks whether Revit StorageType.Double parameter is a Length SpecType or unitless Number,
    preventing 304.8x scaling explosions when a family uses a unitless number parameter.
    """
    if not name:
        return None
    from Autodesk.Revit.DB import StorageType
    for src in (el, getattr(el, "Symbol", None)):
        if src is None:
            continue
        try:
            p = src.LookupParameter(name)
            if p is None or p.StorageType != StorageType.Double or not p.HasValue:
                continue
            raw = float(p.AsDouble())
            if raw <= 0.0:
                continue
            is_unitless = False
            try:
                from Autodesk.Revit.DB import SpecTypeId, UnitTypeId
                try:
                    if p.Definition.GetDataType() != SpecTypeId.Length:
                        is_unitless = True
                except Exception:
                    pass
                if not is_unitless:
                    uid = p.GetUnitTypeId()
                    if uid == UnitTypeId.Custom:
                        is_unitless = True
            except Exception:
                is_unitless = True
            if is_unitless:
                if min_sane <= raw <= max_sane:
                    return raw
                val_mm = raw * 1000.0 if raw < min_sane else raw
            else:
                val_mm = raw * FT_TO_MM
            if min_sane <= val_mm <= max_sane:
                return val_mm
            # Fallback check if raw itself is already mm despite length metadata ambiguity
            if min_sane <= raw <= max_sane:
                return raw
        except Exception:
            continue
    return None


class _RevitCtx(object):
    def __init__(self, doc, shared, zoff_mm):
        self.doc = doc
        self.tf = None
        if shared:
            try:
                self.tf = doc.ActiveProjectLocation.GetTotalTransform()
            except Exception:
                self.tf = None
        self.zoff = zoff_mm

    def xy(self, pt):
        if self.tf is not None:
            pt = self.tf.OfPoint(pt)
        return {"x": float(pt.X) * FT_TO_MM, "y": float(pt.Y) * FT_TO_MM}

    def z(self, z_ft):
        if self.tf is not None:
            try:
                from Autodesk.Revit.DB import XYZ
                p = self.tf.OfPoint(XYZ(0.0, 0.0, float(z_ft)))
                return float(p.Z) * FT_TO_MM
            except Exception:
                pass
        return float(z_ft) * FT_TO_MM - self.zoff


def get_revit_scan_metadata(doc):
    """
    Collect Levels (with foundation/framing counts), Pile Families (3 categories + numeric params
    + auto-guess flags), and Structural Foundation families from active Revit 2025 Document.
    """
    from Autodesk.Revit.DB import FilteredElementCollector, Level

    levels = list(FilteredElementCollector(doc).OfClass(Level))
    levels.sort(key=lambda lv: lv.Elevation)
    bic_gm, bic_sf, bic_sc, bic_fr = _revit_categories()

    # Count Structural Foundation + Structural Framing elements per Level to auto-select foundation levels
    lv_counts = {}
    lvl_z = [(_eid_value(lv.Id), float(lv.Elevation)) for lv in levels]
    for bic in (bic_sf, bic_fr):
        if bic is None:
            continue
        for el in FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType():
            lid = _level_id(el)
            if lid <= 0:
                try:
                    bb = el.get_BoundingBox(None)
                    if bb is not None:
                        for i, z in lvl_z:
                            if bb.Min.Z - 1.5 <= z <= bb.Max.Z + 1.5:
                                lid = i
                                break
                except Exception:
                    pass
            if lid > 0:
                lv_counts[lid] = lv_counts.get(lid, 0) + 1

    level_items = []
    for lv in levels:
        eid = _eid_value(lv.Id)
        cnt = lv_counts.get(eid, 0)
        suffix = (u" · %d CK" % cnt) if cnt > 0 else u""
        elev_mm = round(float(lv.Elevation) * FT_TO_MM)
        proj_mm = round(float(lv.ProjectElevation) * FT_TO_MM)
        level_items.append({
            "id": eid,
            "name": lv.Name,
            "elevationFt": float(lv.Elevation),
            "elevationMm": elev_mm,
            "projectElevationMm": proj_mm,
            "elementCount": cnt,
            "hasFoundations": cnt > 0,
            "label": u"%s (%.0f mm%s)" % (lv.Name, elev_mm, suffix),
        })

    fam_map = {}
    for bic, cat_label in (
        (bic_gm, "Generic Models"),
        (bic_sf, "Structural Foundation"),
        (bic_sc, "Structural Columns"),
    ):
        if bic is None:
            continue
        for el in FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance":
                continue
            fam, _ = _fam_type(el, doc)
            if not fam:
                continue
            if fam in fam_map:
                fam_map[fam]["count"] += 1
            else:
                params = _list_numeric_params(el)
                gd, gl = guess_pile_params(params)
                fam_map[fam] = {
                    "name": fam,
                    "count": 1,
                    "category": cat_label,
                    "params": params,
                    "guessedD": gd,
                    "guessedL": gl,
                    "isPileGuess": guess_pile_family(fam),
                    "guessedShape": guess_pile_shape(fam),
                }

    pile_fams = sorted(fam_map.values(), key=lambda x: (not x["isPileGuess"], x["name"].lower()))

    dai_counts = {}
    if bic_sf is not None:
        for el in FilteredElementCollector(doc).OfCategory(bic_sf).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance" and not _is_slab(el):
                continue
            fam, typ = _fam_type(el, doc)
            if fam:
                if fam not in dai_counts:
                    dai_counts[fam] = {"count": 0, "isDai": guess_dai(fam) or guess_dai(typ)}
                dai_counts[fam]["count"] += 1
                if guess_dai(typ):
                    dai_counts[fam]["isDai"] = True

    dai_fams = [
        {"name": nm, "count": info["count"], "isDaiGuess": info["isDai"]}
        for nm, info in sorted(dai_counts.items(), key=lambda t: t[0].lower())
    ]

    return {
        "title": getattr(doc, "Title", "Revit 2025"),
        "levels": level_items,
        "pileFamilies": pile_fams,
        "daiFamilies": dai_fams,
    }


def detect_revit_foundation_kinds(doc, bang_b=800.0):
    """
    Lightweight, fast Revit 2025 model detector (BoundingBox + Category + Family heuristics).
    Returns {"kinds": set(...), "counts": {"mong_don": int, "mong_bang": int, "mong_coc": int, "dam_mong": int}}
    so the UI can highlight (khoanh đỏ) which foundation module tabs actually exist in the active Revit model.
    """
    counts = {"mong_don": 0, "mong_bang": 0, "mong_coc": 0, "dam_mong": 0}
    if doc is None:
        return {"kinds": set(), "counts": counts}
    try:
        from Autodesk.Revit.DB import FilteredElementCollector, Level
    except Exception:
        return {"kinds": set(), "counts": counts}

    bic_gm, bic_sf, bic_sc, bic_fr = _revit_categories()
    levels = list(FilteredElementCollector(doc).OfClass(Level))
    lvl_z = [(_eid_value(lv.Id), float(lv.Elevation)) for lv in levels]
    fnd_level_ids = set()

    def _fast_lid(el):
        lid = _level_id(el)
        if lid > 0:
            return lid
        try:
            bb = el.get_BoundingBox(None)
            if bb is not None:
                for i, z in lvl_z:
                    if bb.Min.Z - 1.5 <= z <= bb.Max.Z + 1.5:
                        return i
        except Exception:
            pass
        return 0

    def _is_curve(el):
        try:
            return _tname(el.Location) == "LocationCurve"
        except Exception:
            return False

    # 1. Collect foundation pads & wall/curve foundations in Structural Foundation
    sf_pads = []
    if bic_sf is not None:
        for el in FilteredElementCollector(doc).OfCategory(bic_sf).WhereElementIsNotElementType():
            tn = _tname(el)
            if tn not in ("FamilyInstance", "WallFoundation") and not _is_slab(el):
                continue
            fam, typ = _fam_type(el, doc)
            if tn == "FamilyInstance" and (guess_pile_family(fam) or guess_pile_family(typ)):
                continue
            lid = _fast_lid(el)
            if lid > 0:
                fnd_level_ids.add(lid)
            if tn in ("FamilyInstance", "WallFoundation") and _is_curve(el):
                counts["mong_bang"] += 1
                continue
            try:
                bb = el.get_BoundingBox(None)
            except Exception:
                bb = None
            if bb is None:
                continue
            sig = classify_name_signals(_mark(el), fam, typ)
            sf_pads.append({
                "id": _eid_value(el.Id),
                "x0": float(bb.Min.X) * FT_TO_MM - BBOX_PAD,
                "y0": float(bb.Min.Y) * FT_TO_MM - BBOX_PAD,
                "x1": float(bb.Max.X) * FT_TO_MM + BBOX_PAD,
                "y1": float(bb.Max.Y) * FT_TO_MM + BBOX_PAD,
                "zmin": float(bb.Min.Z) * FT_TO_MM,
                "zmax": float(bb.Max.Z) * FT_TO_MM,
                "sig": sig,
                "is_dai_name": guess_dai(fam) or guess_dai(typ),
            })

    # Fallback foundation level guess if no Structural Foundation elements have explicit level ids
    if not fnd_level_ids and levels:
        for lv in levels:
            nm = normalize_plain(lv.Name)
            if any(k in nm for k in ("mong", "fnd", "footing", "foundation", "dai", "be")):
                fnd_level_ids.add(_eid_value(lv.Id))
        if not fnd_level_ids:
            levels_sorted = sorted(levels, key=lambda l: float(l.Elevation))
            fnd_level_ids.add(_eid_value(levels_sorted[0].Id))

    # 2. Collect candidate piles across Generic Models, Structural Foundation, Structural Columns
    pile_boxes = []
    for bic in (bic_gm, bic_sf, bic_sc):
        if bic is None:
            continue
        for el in FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance":
                continue
            fam, typ = _fam_type(el, doc)
            is_name = guess_pile_family(fam) or guess_pile_family(typ)
            try:
                bb = el.get_BoundingBox(None)
            except Exception:
                bb = None
            if bb is None:
                continue
            x0, y0 = float(bb.Min.X) * FT_TO_MM, float(bb.Min.Y) * FT_TO_MM
            x1, y1 = float(bb.Max.X) * FT_TO_MM, float(bb.Max.Y) * FT_TO_MM
            zbot, ztop = float(bb.Min.Z) * FT_TO_MM, float(bb.Max.Z) * FT_TO_MM
            cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            ex, ey, h_mm = abs(x1 - x0), abs(y1 - y0), ztop - zbot
            if not is_name:
                slender = (100.0 <= max(ex, ey) <= 1300.0) and (h_mm >= max(1600.0, 2.2 * max(ex, ey)))
                if not slender or not sf_pads:
                    continue
                if bic == bic_sc:
                    under = any(
                        p["x0"] <= cx <= p["x1"] and p["y0"] <= cy <= p["y1"]
                        and ztop <= p["zmax"] + 50.0 and zbot < p["zmin"] - 400.0
                        for p in sf_pads
                    )
                else:
                    under = any(
                        p["x0"] <= cx <= p["x1"] and p["y0"] <= cy <= p["y1"]
                        and ztop >= p["zmin"] - PILE_Z_TOL and zbot <= p["zmax"] + PILE_Z_TOL and zbot < p["zmin"] - 200.0
                        for p in sf_pads
                    )
                if not under:
                    continue
            pile_boxes.append((cx, cy, zbot, ztop))

    # Classify each pad: pile cap vs single footing
    for pad in sf_pads:
        has_pile = any(
            pad["x0"] <= pcx <= pad["x1"] and pad["y0"] <= pcy <= pad["y1"]
            and pztop >= pad["zmin"] - PILE_Z_TOL and pzbot <= pad["zmax"] + PILE_Z_TOL
            for pcx, pcy, pzbot, pztop in pile_boxes
        )
        if has_pile or (pad["is_dai_name"] and pile_boxes) or pad["sig"] == "mong_coc":
            counts["mong_coc"] += 1
        elif pad["sig"] == "mong_bang":
            counts["mong_bang"] += 1
        else:
            counts["mong_don"] += 1

    # 3. Structural Framing on foundation levels (or explicitly named as ground beam / strip)
    if bic_fr is not None:
        for el in FilteredElementCollector(doc).OfCategory(bic_fr).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance" or not _is_curve(el):
                continue
            fam, typ = _fam_type(el, doc)
            mk = _mark(el)
            sig = classify_name_signals(mk, fam, typ)
            lid = _fast_lid(el)
            on_fnd_lv = (lid in fnd_level_ids) if lid > 0 else False
            if not on_fnd_lv and sig not in ("mong_bang", "dam_mong"):
                continue
            bw = 400.0
            try:
                crv = el.Location.Curve
                p0, p1 = crv.GetEndPoint(0), crv.GetEndPoint(1)
                dx = (float(p1.X) - float(p0.X)) * FT_TO_MM
                dy = (float(p1.Y) - float(p0.Y)) * FT_TO_MM
                bb = el.get_BoundingBox(None)
                if bb is not None and math.hypot(dx, dy) > 10.0:
                    ln = math.hypot(dx, dy)
                    nx, ny = -dy / ln, dx / ln
                    ex = (float(bb.Max.X) - float(bb.Min.X)) * FT_TO_MM
                    ey = (float(bb.Max.Y) - float(bb.Min.Y)) * FT_TO_MM
                    # Estimate width perpendicular to curve axis for axis-aligned/angled beams
                    bw = abs(ex * nx) + abs(ey * ny) if (abs(dx) < 50 or abs(dy) < 50) else min(ex, ey)
            except Exception:
                pass
            for pname in ("b", "B", "Width", "Be rong", "B_dam"):
                pv = _param_mm(el, pname, 120.0, 6000.0)
                if pv is not None:
                    bw = pv
                    break
            if sig == "mong_bang" or (sig != "dam_mong" and bw > float(bang_b)):
                counts["mong_bang"] += 1
            else:
                counts["dam_mong"] += 1

    kinds = set(k for k, v in counts.items() if v > 0)
    return {"kinds": kinds, "counts": counts}



def _revit_solids(el):
    from Autodesk.Revit.DB import Options, SolidUtils, Transform, ViewDetailLevel
    opt = Options()
    opt.DetailLevel = ViewDetailLevel.Fine
    opt.ComputeReferences = False
    opt.IncludeNonVisibleObjects = False
    out = []

    def walk(ge, parent_tf=None):
        for obj in ge:
            tn = _tname(obj)
            if tn == "Solid":
                try:
                    if obj.Volume > 1e-9 and obj.Faces.Size > 0:
                        sol = obj
                        if parent_tf is not None and not parent_tf.IsIdentity:
                            sol = SolidUtils.CreateTransformed(obj, parent_tf)
                        out.append(sol)
                except Exception:
                    pass
            elif tn == "GeometryInstance":
                try:
                    inst_tf = obj.Transform
                    if parent_tf is None:
                        # Top-level GeometryInstance: GetInstanceGeometry() is already in project coords
                        walk(obj.GetInstanceGeometry(), None)
                    else:
                        walk(obj.GetSymbolGeometry(), parent_tf.Multiply(inst_tf))
                except Exception:
                    try:
                        walk(obj.GetInstanceGeometry(), None)
                    except Exception:
                        pass

    try:
        ge = el.get_Geometry(opt)
        if ge is not None:
            walk(ge, None)
    except Exception:
        pass
    return out


def _extract_pad_edge_height(solids, zmin, zmax, ctx):
    """Extract vertical edge skirt height (hMep) of a pad footing from its solid faces touching zmin."""
    H = max(0.0, zmax - zmin)
    if H < 10.0 or not solids:
        return min(200, int(round(H / 2.0)))
    vert_heights = []
    for s in solids:
        try:
            for f in s.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                if abs(f.FaceNormal.Z) > 0.15:
                    continue
                zs = []
                for loop in f.GetEdgesAsCurveLoops():
                    for c in loop:
                        for q in c.Tessellate():
                            zs.append(ctx.z(q.Z))
                if zs and min(zs) <= zmin + 8.0:
                    fh = max(zs) - min(zs)
                    if fh >= 50.0:
                        vert_heights.append(fh)
        except Exception:
            continue
    if vert_heights:
        # Take the smallest full vertical face height touching zmin (handles stepped/chamfered pads cleanly)
        h_mep = _round5(min(vert_heights))
        return max(100, min(_round5(H), h_mep))
    return min(200, int(round(H / 2.0)))


def _extract_pad_plan_details(solids, zmin, zmax, cx, cy, ux, uy, vx, vy, ctx):
    """
    Extract true top plateau polygon (topPoly) and sloped chamfer ridge lines (chamferLines)
    in local OBB coordinates for sloped/stepped pad footings from Revit solid geometry.
    """
    if not solids or (zmax - zmin) < 15.0:
        return {"topPoly": None, "chamferLines": None}

    def to_loc(pt_xyz):
        w = ctx.xy(pt_xyz)
        dx, dy = w["x"] - cx, w["y"] - cy
        return {
            "x": round(dx * ux + dy * uy, 1),
            "y": round(dx * vx + dy * vy, 1),
        }

    # 1) Find top horizontal plateau(s) near zmax (or upper step face)
    top_faces = []
    has_sloped_face = False
    for s in solids:
        try:
            for f in s.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                nz = float(f.FaceNormal.Z)
                if 0.05 < nz < 0.96:
                    has_sloped_face = True
                elif nz >= 0.98:
                    fz = ctx.z(f.Origin.Z)
                    if fz >= zmin + 15.0:
                        top_faces.append((fz, float(f.Area), f))
        except Exception:
            continue

    top_poly = None
    if top_faces:
        # Prefer face at zmax (the top pedestal / upper plateau)
        top_faces.sort(key=lambda item: (-round(item[0] / 5.0), -item[1]))
        best_f = top_faces[0][2]
        raw_top = _face_poly(best_f, ctx)
        if raw_top and len(raw_top) >= 3:
            loc_top = [
                {
                    "x": round((p["x"] - cx) * ux + (p["y"] - cy) * uy, 1),
                    "y": round((p["x"] - cx) * vx + (p["y"] - cy) * vy, 1),
                }
                for p in raw_top
            ]
            loc_top = clean_polygon(loc_top, 2.0)
            if len(loc_top) >= 3:
                top_poly = loc_top

    # 2) Extract diagonal/sloped ridge edges (connecting lower outer perimeter to upper plateau)
    chamfer_lines = []
    seen_edges = set()
    for s in solids:
        try:
            for e in s.Edges:
                try:
                    crv = e.AsCurve()
                    ep0 = crv.GetEndPoint(0)
                    ep1 = crv.GetEndPoint(1)
                    z0 = ctx.z(ep0.Z)
                    z1 = ctx.z(ep1.Z)
                    if abs(z1 - z0) < 8.0:
                        continue
                    l0 = to_loc(ep0)
                    l1 = to_loc(ep1)
                    if math.hypot(l1["x"] - l0["x"], l1["y"] - l0["y"]) < 8.0:
                        continue
                    a_k = (int(round(l0["x"])), int(round(l0["y"])))
                    b_k = (int(round(l1["x"])), int(round(l1["y"])))
                    ekey = (a_k, b_k) if a_k <= b_k else (b_k, a_k)
                    if ekey not in seen_edges:
                        seen_edges.add(ekey)
                        chamfer_lines.append([l0["x"], l0["y"], l1["x"], l1["y"]])
                except Exception:
                    continue
        except Exception:
            continue

    if not chamfer_lines and not has_sloped_face:
        # Check if top_poly is significantly smaller than bottom polygon (flat stepped pad)
        bot_poly = _bottom_polygon(solids, ctx)
        if top_poly and bot_poly:
            ar_top = polygon_area(top_poly)
            ar_bot = polygon_area(bot_poly)
            if ar_top >= ar_bot * 0.98:
                top_poly = None

    return {
        "topPoly": top_poly,
        "chamferLines": chamfer_lines if chamfer_lines else None,
    }


def _loop_points(loop, ctx):
    pts = []
    for c in loop:
        if _tname(c) == "Line":
            pts.append(ctx.xy(c.GetEndPoint(0)))
        else:
            tess = list(c.Tessellate())
            for p in tess[:-1]:
                pts.append(ctx.xy(p))
    return pts


def _face_poly(face, ctx):
    best = None
    for loop in face.GetEdgesAsCurveLoops():
        pts = clean_polygon(_loop_points(loop, ctx), 1.0)
        if len(pts) >= 3:
            ar = polygon_area(pts)
            if best is None or ar > best[0]:
                best = (ar, pts)
    return best[1] if best else None


def _flat_poly(solid, ctx, down=True):
    """Relaxed planar face normal check (|nz| > 0.98) for bottom or top face extraction."""
    faces = []
    try:
        for f in solid.Faces:
            if _tname(f) != "PlanarFace":
                continue
            nz = f.FaceNormal.Z
            if (down and nz < -0.98) or ((not down) and nz > 0.98):
                faces.append((f.Origin.Z, f))
    except Exception:
        return None
    if not faces:
        return None
    z_ref = min(q[0] for q in faces) if down else max(q[0] for q in faces)
    sel = [f for zz, f in faces if abs(zz - z_ref) < 1e-3]
    sel.sort(key=lambda f: -f.Area)
    return _face_poly(sel[0], ctx)


def _bottom_polygon(solids, ctx):
    faces = []
    for s in solids:
        try:
            for f in s.Faces:
                if _tname(f) == "PlanarFace" and f.FaceNormal.Z < -0.98:
                    faces.append((f.Origin.Z, f))
        except Exception:
            continue
    if not faces:
        return None
    zmin = min(z for z, _ in faces)
    low = [f for z, f in faces if abs(z - zmin) < 1e-3]
    low.sort(key=lambda f: -f.Area)
    return _face_poly(low[0], ctx)


def _solid_z(solid, ctx):
    zs = []
    try:
        for e in solid.Edges:
            try:
                for q in e.AsCurve().Tessellate():
                    zs.append(ctx.z(q.Z))
            except Exception:
                continue
    except Exception:
        pass
    return (min(zs), max(zs)) if zs else None


def _solid_material_is_lot(doc, solid):
    if doc is None:
        return False
    try:
        for f in solid.Faces:
            mid = getattr(f, "MaterialElementId", None)
            if mid is not None and _eid_value(mid) > 0:
                mat = doc.GetElement(mid)
                if mat is not None:
                    nm = normalize_plain(getattr(mat, "Name", ""))
                    if any(k in nm for k in ("lot", "lean", "blinding", "bt lot", "be tong lot")):
                        return True
    except Exception:
        pass
    return False


def _drop_lot(solids, ctx, doc=None):
    """
    Filter out embedded lean concrete slabs (<= 150 mm thick sitting below a thicker solid).
    IMPORTANT: Only treat a layer as lean concrete if its material explicitly says Lot/Lean/Blinding
    OR its XY footprint strictly overhangs the structural solid above (>= 3.5% larger area),
    never dropping an equal-footprint structural layer of a stepped/layered cap (e.g. 100 + 200 = 300mm).
    """
    if len(solids) < 2:
        return solids
    from poly_geom import polygon_centroid
    info = [(s, _solid_z(s, ctx), _flat_poly(s, ctx, True)) for s in solids]
    keep = []
    for i, (s, zr, bp) in enumerate(info):
        is_lot = False
        if zr is not None and bp is not None and (zr[1] - zr[0]) <= LOT_MAX:
            ar_bp = polygon_area(bp)
            mat_lot = _solid_material_is_lot(doc, s)
            for j, (_, zt, bt) in enumerate(info):
                if j == i or zt is None or bt is None:
                    continue
                ar_bt = polygon_area(bt)
                if (abs(zt[0] - zr[1]) <= 3.0
                        and (zt[1] - zt[0]) >= (zr[1] - zr[0]) - 1.0
                        and point_in_polygon(polygon_centroid(bt), bp, 1.0)):
                    if mat_lot or (ar_bp > ar_bt * 1.035):
                        is_lot = True
                        break
        if not is_lot:
            keep.append(s)
    return keep or solids


def _extract_pile_solid_diam(el, ctx):
    """Measure true shaft cross-section width/diameter & shape from pile solids."""
    solids = _revit_solids(el)
    if not solids:
        return None, None
    best = None
    best_h = 0.0
    for s in solids:
        zr = _solid_z(s, ctx)
        if not zr:
            continue
        sh = zr[1] - zr[0]
        if sh < 200.0:
            continue
        bp = _flat_poly(s, ctx, True) or _flat_poly(s, ctx, False)
        if not bp or len(bp) < 3:
            continue
        mbr = min_area_rect(bp)
        d_est = max(mbr["B"], mbr["L"])
        if 80.0 <= d_est <= 2500.0 and sh >= best_h:
            best_h = sh
            is_sq = is_rect_poly(bp) and abs(mbr["B"] - mbr["L"]) <= max(40.0, d_est * 0.25)
            best = (d_est, "square" if is_sq else "circle")
    return best if best else (None, None)


def _split_cap_nested_piles(solids, ctx):
    """
    Detect nested pile shafts modeled inside a Pile Cap family.
    Separates slender vertical shafts extending >= 350 mm below the cap body from cap body solids.
    """
    if len(solids) < 2:
        return solids, []
    entries = []
    for s in solids:
        zr = _solid_z(s, ctx)
        if not zr:
            continue
        bp = _flat_poly(s, ctx, True) or _flat_poly(s, ctx, False)
        if not bp or len(bp) < 3:
            continue
        mbr = min_area_rect(bp)
        w = max(mbr["B"], mbr["L"])
        h = zr[1] - zr[0]
        entries.append((s, zr, bp, mbr, w, h))
    if len(entries) < 2:
        return solids, []
    # Main cap body candidate: highest top Z & largest horizontal area
    entries_sorted = sorted(entries, key=lambda e: (-round(e[1][1] / 10.0), -polygon_area(e[2])))
    cap_top_z = entries_sorted[0][1][1]
    cap_candidates = [e for e in entries if e[1][1] >= cap_top_z - 150.0 and e[5] <= 2500.0]
    if not cap_candidates:
        return solids, []
    cap_bot_z = min(e[1][0] for e in cap_candidates)

    body_solids = []
    nested_piles = []
    for s, zr, bp, mbr, w, h in entries:
        is_nested_pile = (
            80.0 <= w <= 1200.0
            and h >= max(800.0, 2.0 * w)
            and zr[0] < cap_bot_z - 300.0
            and zr[1] <= cap_top_z + 10.0
        )
        if is_nested_pile:
            is_sq = is_rect_poly(bp) and abs(mbr["B"] - mbr["L"]) <= max(40.0, w * 0.25)
            nested_piles.append({
                "x": mbr["cx"],
                "y": mbr["cy"],
                "d": _round5(w),
                "dai": _round5(h),
                "ztop": zr[1],
                "zbot": zr[0],
                "shape": "square" if is_sq else "circle",
            })
        else:
            body_solids.append(s)
    if not nested_piles or not body_solids:
        return solids, []
    return body_solids, nested_piles


def _zrange(el, ctx):
    bb = el.get_BoundingBox(None)
    if bb is None:
        return None
    return (ctx.z(bb.Min.Z), ctx.z(bb.Max.Z))


def _bbox_poly(el, ctx):
    bb = el.get_BoundingBox(None)
    if bb is None:
        return None
    a = ctx.xy(bb.Min)
    b = ctx.xy(bb.Max)
    x0, x1 = min(a["x"], b["x"]), max(a["x"], b["x"])
    y0, y1 = min(a["y"], b["y"]), max(a["y"], b["y"])
    return [{"x": x0, "y": y0}, {"x": x1, "y": y0}, {"x": x1, "y": y1}, {"x": x0, "y": y1}]


def _location_xy(el, ctx):
    try:
        loc = el.Location
        if _tname(loc) == "LocationPoint":
            return ctx.xy(loc.Point)
    except Exception:
        pass
    return None


def _slice_faces_all(solids, a, b, d, return_indexed=False):
    """Slice EVERY solid in `solids` at mid-span perpendicular to `d` and return all section PlanarFaces."""
    from Autodesk.Revit.DB import (
        BooleanOperationsType,
        BooleanOperationsUtils,
        CurveLoop,
        GeometryCreationUtilities,
        Line as RevitLine,
        XYZ,
    )
    from System.Collections.Generic import List

    up = XYZ.BasisZ
    side = d.CrossProduct(up)
    if side.GetLength() < 1e-6:
        return []
    side = side.Normalize()
    mx, my, mz = (a.X + b.X) / 2.0, (a.Y + b.Y) / 2.0, (a.Z + b.Z) / 2.0
    W = 100.0
    corners = [
        XYZ(mx + side.X * W * sx + up.X * W * sz, my + side.Y * W * sx + up.Y * W * sz, mz + side.Z * W * sx + up.Z * W * sz)
        for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))
    ]
    loop = CurveLoop()
    for i in range(4):
        loop.Append(RevitLine.CreateBound(corners[i], corners[(i + 1) % 4]))
    loops = List[CurveLoop]()
    loops.Add(loop)
    box = GeometryCreationUtilities.CreateExtrusionGeometry(loops, d, 0.02)
    faces = []
    for idx, sol in enumerate(solids):
        sol_best = None
        try:
            r = BooleanOperationsUtils.ExecuteBooleanOperation(sol, box, BooleanOperationsType.Intersect)
            for f in r.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                n = f.FaceNormal
                if abs(n.X * d.X + n.Y * d.Y + n.Z * d.Z) < 0.98:
                    continue
                if sol_best is None or f.Area > sol_best.Area:
                    sol_best = f
        except Exception:
            sol_best = None
        if sol_best is not None:
            faces.append((idx, sol_best) if return_indexed else sol_best)
    return faces


def _slice_face(solids, a, b, d):
    faces = _slice_faces_all(solids, a, b, d)
    if not faces:
        return None
    return max(faces, key=lambda f: f.Area)


def _face_to_prof_pts(face, p0, nx, ny, zmin, ctx):
    best = None
    for loop in face.GetEdgesAsCurveLoops():
        pts = []
        for c in loop:
            q_list = [c.GetEndPoint(0)] if _tname(c) == "Line" else list(c.Tessellate())[:-1]
            for q in q_list:
                xy = ctx.xy(q)
                pts.append({"x": (xy["x"] - p0["x"]) * nx + (xy["y"] - p0["y"]) * ny, "y": ctx.z(q.Z) - zmin})
        pts = clean_polygon(pts, 1.0)
        if len(pts) >= 3:
            ar = polygon_area(pts)
            if best is None or ar > best[0]:
                best = (ar, pts)
    return best[1] if best else None


def _beam_profile(el, crv, p0, p1, zmin, ctx, solids=None):
    """
    Extract true cross-section polygon(s) [(v, z)] mm of Structural Framing or curve Foundation.
    Combines ALL non-lot solids (handling unjoined multi-solid families and 45-deg mitered ends)
    so a 600mm strip footing with a 300mm flange + 300mm stem never collapses to 300mm.
    """
    try:
        if _tname(crv) != "Line":
            return None
        a, b = crv.GetEndPoint(0), crv.GetEndPoint(1)
        d = b.Subtract(a)
        if d.GetLength() < 1e-9:
            return None
        d = d.Normalize()
        L = math.hypot(p1["x"] - p0["x"], p1["y"] - p0["y"])
        if L < 1e-6:
            return None
        nx, ny = -(p1["y"] - p0["y"]) / L, (p1["x"] - p0["x"]) / L
        if solids is None:
            solids = _drop_lot(_revit_solids(el), ctx)
        if not solids:
            return None

        # 1) Prefer mid-span boolean slice across ALL solids (immune to mitered/cutback ends!)
        sliced_pairs = []
        try:
            sliced_pairs = _slice_faces_all(solids, a, b, d, return_indexed=True)
        except Exception:
            sliced_pairs = []
        sliced_idxs = set(idx for idx, _ in sliced_pairs)
        faces = [fc for _, fc in sliced_pairs]

        # 2) Fallback only for solids that did not produce a mid-span slice
        for idx, sol in enumerate(solids):
            if idx in sliced_idxs:
                continue
            sol_face = None
            for f in sol.Faces:
                if _tname(f) != "PlanarFace":
                    continue
                n = f.FaceNormal
                if abs(n.X * d.X + n.Y * d.Y + n.Z * d.Z) < 0.98:
                    continue
                if sol_face is None or f.Area > sol_face.Area:
                    sol_face = f
            if sol_face is not None:
                faces.append(sol_face)

        if not faces:
            return None

        polys = []
        for fc in faces:
            pts = _face_to_prof_pts(fc, p0, nx, ny, zmin, ctx)
            if pts:
                polys.append(pts)
        if not polys:
            return None

        is_rect = (len(polys) == 1) and _is_rect_prof(polys[0])
        return polys, is_rect
    except Exception:
        return None


def scan_revit_foundations(doc, options=None):
    """
    Scan active Revit 2025 Document with professional foundation recognition rules.
    options: optional dict {
        "level_ids": [int, ...] (empty/None = all levels),
        "pile_families": [str, ...],
        "d_param": str,
        "l_param": str,
        "shape": "Tròn" | "Vuông" | "circle" | "square",
        "dai_fams": [str, ...],
        "shared": bool,
        "bang_b": float (default 800.0),
    }
    """
    from Autodesk.Revit.DB import FilteredElementCollector, Level

    opts = dict(options or {})
    levels = list(FilteredElementCollector(doc).OfClass(Level))
    levels.sort(key=lambda lv: lv.Elevation)
    if not levels:
        return {"candidates": [], "messages": [u"Mô hình Revit chưa có Level nào."]}

    req_lids = set(int(x) for x in (opts.get("level_ids") or []) if x is not None)
    if req_lids:
        chosen_levels = [lv for lv in levels if _eid_value(lv.Id) in req_lids]
        if not chosen_levels:
            chosen_levels = levels
    else:
        chosen_levels = levels

    lv_ids = set(_eid_value(lv.Id) for lv in chosen_levels)
    lv_names = {_eid_value(lv.Id): lv.Name for lv in chosen_levels}
    lvl_z = [(_eid_value(lv.Id), float(lv.Elevation)) for lv in chosen_levels]

    base_lv = chosen_levels[0]
    # Correct sign: z_mm = z_ft*FT_TO_MM - (ProjectElevation - Elevation)*FT_TO_MM
    # so a point at base_lv.ProjectElevation evaluates to base_lv.Elevation (matching Revit level cote!)
    zoff = (float(base_lv.ProjectElevation) - float(base_lv.Elevation)) * FT_TO_MM
    shared = bool(opts.get("shared", False))
    bang_b = float(opts.get("bang_b") or 800.0)
    ctx = _RevitCtx(doc, shared, zoff)

    fam_set = set(opts.get("pile_families") or [])
    excluded_pile_fams = set(opts.get("excluded_pile_families") or [])
    dai_set = set(opts.get("dai_fams") or [])
    notes = []

    def lid_of(el):
        lid = _level_id(el)
        if lid > 0 and (not req_lids or lid in lv_ids):
            return lid
        if lid > 0 and req_lids and lid not in lv_ids:
            return -1
        # Fallback for WallFoundation / Slab without explicit LevelId
        try:
            bb = el.get_BoundingBox(None)
            if bb is not None:
                for i, z in lvl_z:
                    if bb.Min.Z - 1.5 <= z <= bb.Max.Z + 1.5:
                        return i
        except Exception:
            pass
        return -1

    def is_curve_loc(el):
        try:
            return _tname(el.Location) == "LocationCurve"
        except Exception:
            return False

    bic_gm, bic_sf, bic_sc, bic_fr = _revit_categories()

    foots = []
    strips = []
    dams = []
    lot_count = 0
    hdiff_count = 0

    def make_strip(el, lid, override_crv=None):
        nonlocal hdiff_count, lot_count
        zr = _zrange(el, ctx)
        if zr is None:
            return None
        all_sol = _revit_solids(el)
        solids = _drop_lot(all_sol, ctx, doc=doc) if all_sol else []
        if len(all_sol) - len(solids) > 0:
            lot_count += 1
        poly = _bottom_polygon(solids, ctx) if solids else None
        if poly is None:
            poly = _bbox_poly(el, ctx)
        if poly is None or len(poly) < 3:
            return None
        crv = override_crv if override_crv is not None else el.Location.Curve
        p0 = ctx.xy(crv.GetEndPoint(0))
        p1 = ctx.xy(crv.GetEndPoint(1))
        sp = strip_params_from_poly(poly, p0, p1)
        if sp is None:
            return None
        fam, typ = _fam_type(el, doc)
        zmin, zmax = zr
        if solids:
            zrs = [q for q in (_solid_z(x, ctx) for x in solids) if q]
            if zrs:
                zmin = min(q[0] for q in zrs)
                zmax = max(q[1] for q in zrs)
        sol_zmin, sol_zmax = zmin, zmax
        prof = None
        section_dims = None
        pr = _beam_profile(el, crv, p0, p1, sol_zmin, ctx, solids=solids)
        if pr is not None:
            polys, is_rect = pr
            all_prof_pts = [pt for poly_p in polys for pt in poly_p]
            vs = [q["x"] for q in all_prof_pts]
            zs = [q["y"] for q in all_prof_pts]
            if vs and zs and max(vs) - min(vs) > 1.0 and max(zs) - min(zs) > 1.0:
                sp["b"] = max(vs) - min(vs)
                sp["offset"] = (max(vs) + min(vs)) / 2.0
                zlo, zhi = min(zs), max(zs)
                # Guard: for horizontal elements, never shrink below true solid Z span
                is_horiz = True
                try:
                    if _tname(crv) == "Line":
                        is_horiz = abs(crv.GetEndPoint(0).Z - crv.GetEndPoint(1).Z) < 1e-3
                except Exception:
                    pass
                if is_horiz:
                    zmin = min(sol_zmin, sol_zmin + zlo)
                    zmax = max(sol_zmax, sol_zmin + zhi)
                else:
                    if abs((zhi - zlo) - (sol_zmax - sol_zmin)) > 1.0:
                        hdiff_count += 1
                    zmax = sol_zmin + zhi
                    zmin = sol_zmin + zlo
                if not is_rect:
                    prof = [[{"x": q["x"], "y": q["y"] - zlo} for q in poly_p] for poly_p in polys]
                    section_dims = extract_strip_section_dims(prof, sp["b"], zmax - zmin, default_b_dam=int(opts.get("bang_b_dam") or 300))
        return {
            "id": _eid_value(el.Id),
            "level": lv_names.get(lid, ""),
            "mark": _mark(el),
            "fam": fam,
            "type": typ or fam,
            "poly": poly,
            "bbox": _bbox_pts(poly),
            "zmin": zmin,
            "zmax": zmax,
            "p0": p0,
            "p1": p1,
            "sp": sp,
            "cong": 0 if _tname(crv) == "Line" else 1,
            "cots": [],
            "reach": sp["b"] / 2.0 + abs(sp["offset"]),
            "prof": prof,
            "sectionDims": section_dims,
        }

    # 1) Structural Foundation
    if bic_sf is not None:
        for el in FilteredElementCollector(doc).OfCategory(bic_sf).WhereElementIsNotElementType():
            tn = _tname(el)
            if tn not in ("FamilyInstance", "WallFoundation") and not _is_slab(el):
                continue
            lid = lid_of(el)
            if lid not in lv_ids:
                continue
            fam, typ = _fam_type(el, doc)
            if fam in fam_set:
                continue
            if tn in ("FamilyInstance", "WallFoundation") and is_curve_loc(el):
                it = make_strip(el, lid)
                if it is not None:
                    it["forced"] = True
                    strips.append(it)
                continue
            if tn == "WallFoundation":
                # Hosted WallFoundation without LocationCurve: try hosted Wall's curve
                wall_crv = None
                try:
                    wid = getattr(el, "WallId", None)
                    if wid is not None:
                        w_el = doc.GetElement(wid)
                        if w_el is not None and is_curve_loc(w_el):
                            wall_crv = w_el.Location.Curve
                except Exception:
                    wall_crv = None
                if wall_crv is not None:
                    it = make_strip(el, lid, override_crv=wall_crv)
                    if it is not None:
                        it["forced"] = True
                        strips.append(it)
                    continue

            zr = _zrange(el, ctx)
            if zr is None:
                continue
            all_sol = _revit_solids(el)
            solids = _drop_lot(all_sol, ctx, doc=doc) if all_sol else []
            lot_dropped = len(all_sol) - len(solids)
            if lot_dropped > 0:
                lot_count += 1
            body_solids, nested_piles = _split_cap_nested_piles(solids, ctx) if solids else ([], [])
            zmin, zmax = zr
            if body_solids:
                zrs = [q for q in (_solid_z(x, ctx) for x in body_solids) if q]
                if zrs:
                    zmin = min(q[0] for q in zrs)
                    zmax = max(q[1] for q in zrs)
            note = ""
            poly = _bottom_polygon(body_solids, ctx) if body_solids else None
            if poly is None:
                poly = _bbox_poly(el, ctx)
                note = "bbox"
            if poly is None or len(poly) < 3:
                continue
            mbr = min_area_rect(poly)
            rad_f = math.radians(mbr["angleDeg"])
            ux_f, uy_f = math.cos(rad_f), math.sin(rad_f)
            vx_f, vy_f = -uy_f, ux_f
            plan_det = _extract_pad_plan_details(
                body_solids, zmin, zmax, mbr["cx"], mbr["cy"], ux_f, uy_f, vx_f, vy_f, ctx
            ) if body_solids else {"topPoly": None, "chamferLines": None}
            foots.append({
                "id": _eid_value(el.Id),
                "level": lv_names.get(lid, ""),
                "mark": _mark(el),
                "fam": fam,
                "type": typ,
                "is_slab": _is_slab(el),
                "is_wall_fnd": (tn == "WallFoundation"),
                "poly": poly,
                "localPoly": mbr["localPoly"] if not is_rect_poly(mbr["localPoly"]) else None,
                "topPoly": plan_det["topPoly"],
                "chamferLines": plan_det["chamferLines"],
                "zmin": zmin,
                "zmax": zmax,
                "hMep": _extract_pad_edge_height(body_solids, zmin, zmax, ctx),
                "ang": mbr["angleDeg"],
                "B": mbr["B"],
                "L": mbr["L"],
                "cx": mbr["cx"],
                "cy": mbr["cy"],
                "bbox": _bbox_pts(poly),
                "note": note,
                "lot": lot_dropped,
                "piles": [],
                "nestedPiles": nested_piles,
                "cots": [],
            })

    # 2) Piles across 3 categories (selected families + auto-detected fallback if fam_set is empty or missed)
    piles = []
    seen_pile_ids = set()
    auto_pile_fams = set()
    d_pname = opts.get("d_param") or ""
    l_pname = opts.get("l_param") or ""
    p_shape = opts.get("shape") or u"Tròn"

    # Build quick XY+Z envelopes of extracted pads for geometry-based auto-pile fallback
    pad_zones = [
        (f["bbox"][0] - BBOX_PAD, f["bbox"][1] - BBOX_PAD, f["bbox"][2] + BBOX_PAD, f["bbox"][3] + BBOX_PAD, f["zmin"], f["zmax"])
        for f in foots
    ]

    for bic in (bic_gm, bic_sf, bic_sc):
        if bic is None:
            continue
        for el in FilteredElementCollector(doc).OfCategory(bic).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance":
                continue
            eid_val = _eid_value(el.Id)
            if eid_val in seen_pile_ids:
                continue
            fam, typ = _fam_type(el, doc)
            in_selected = fam in fam_set
            if fam in excluded_pile_fams and not in_selected:
                continue
            is_name_pile = guess_pile_family(fam) or guess_pile_family(typ)

            bb = el.get_BoundingBox(None)
            if bb is None:
                continue
            pos = _location_xy(el, ctx)
            a, b = ctx.xy(bb.Min), ctx.xy(bb.Max)
            ex, ey = abs(b["x"] - a["x"]), abs(b["y"] - a["y"])
            if pos is None:
                pos = {"x": (a["x"] + b["x"]) / 2.0, "y": (a["y"] + b["y"]) / 2.0}
            ztop = ctx.z(bb.Max.Z)
            zbot = ctx.z(bb.Min.Z)
            h_mm = ztop - zbot

            if not in_selected:
                # Auto-detect piles by name OR slender vertical geometry touching underneath a foundation pad
                if not is_name_pile:
                    if not pad_zones:
                        continue
                    slender = (100.0 <= max(ex, ey) <= 1300.0) and (h_mm >= max(800.0, 1.8 * max(ex, ey)))
                    if not slender:
                        continue
                    under_pad = any(
                        px0 <= pos["x"] <= px1 and py0 <= pos["y"] <= py1
                        and ztop >= pzmin - PILE_Z_TOL and zbot <= pzmax + PILE_Z_TOL and zbot < pzmin - 200.0
                        for px0, py0, px1, py1, pzmin, pzmax in pad_zones
                    )
                    if not under_pad:
                        continue
                # Never steal an already-extracted foundation pad or column extending way above foundation
                if any(f["id"] == eid_val for f in foots):
                    continue
                if bic == bic_sc and not is_name_pile:
                    # For columns category without pile keyword, require ztop <= pad zmax + 50mm
                    if not any(
                        px0 <= pos["x"] <= px1 and py0 <= pos["y"] <= py1 and ztop <= pzmax + 50.0 and zbot < pzmin - 400.0
                        for px0, py0, px1, py1, pzmin, pzmax in pad_zones
                    ):
                        continue
                auto_pile_fams.add(fam)

            d_val = _param_mm(el, d_pname, 80.0, 3000.0)
            if d_val is not None and _is_radius_param(d_pname):
                d_val *= 2.0
            if d_val is None:
                # Auto-probe common diameter / width / radius parameters before bounding box
                el_params = _list_numeric_params(el)
                gd_auto, gl_auto = guess_pile_params(el_params)
                if gd_auto:
                    pv = _param_mm(el, gd_auto, 50.0, 3000.0)
                    if pv is not None:
                        d_val = (pv * 2.0) if _is_radius_param(gd_auto) else pv
                if d_val is None and not l_pname and gl_auto:
                    l_pname_el = gl_auto
                else:
                    l_pname_el = l_pname
            else:
                l_pname_el = l_pname

            sol_d, sol_sh = _extract_pile_solid_diam(el, ctx)
            if d_val is None or (80.0 <= d_val <= 2500.0 and sol_d is not None and abs(d_val - sol_d) > 20.0):
                # Prefer actual measured shaft solid cross-section when available (prevents stale type params / cap bbox bloat)
                if sol_d is not None:
                    d_val = sol_d
            if d_val is None:
                d_val = _parse_diam_from_name(u"%s %s" % (fam, typ)) or max(ex, ey) or 300.0

            l_val = _param_mm(el, l_pname_el, 500.0, 120000.0) or h_mm
            eff_shape = p_shape if in_selected else (sol_sh or guess_pile_shape(u"%s %s" % (fam, typ)))
            seen_pile_ids.add(eid_val)
            piles.append({
                "id": eid_val,
                "fam": fam,
                "type": typ,
                "x": pos["x"],
                "y": pos["y"],
                "d": d_val,
                "dai": l_val,
                "ztop": ztop,
                "zbot": zbot,
                "shape": eff_shape,
                "autoDetected": not in_selected,
            })

    if auto_pile_fams:
        notes.append(u"Tự động nhận diện thêm Family cọc: %s." % u", ".join(sorted(auto_pile_fams)))

    # 3) Structural Framing (DamMong vs MongBang)
    if bic_fr is not None:
        for el in FilteredElementCollector(doc).OfCategory(bic_fr).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance":
                continue
            lid = lid_of(el)
            if lid not in lv_ids:
                continue
            if not is_curve_loc(el):
                continue
            it = make_strip(el, lid)
            if it is None:
                continue
            sig = classify_name_signals(it.get("mark", ""), it.get("fam", ""), it.get("type", ""))
            is_stepped = bool(it.get("prof"))
            if sig == "mong_bang" or is_stepped:
                strips.append(it)
            elif sig == "dam_mong" and it["sp"]["b"] <= max(bang_b, 1000.0):
                dams.append(it)
            elif it["sp"]["b"] >= bang_b:
                strips.append(it)
            else:
                dams.append(it)

    # 4) Structural Columns (excluding selected or auto-detected pile families)
    cols = []
    if bic_sc is not None:
        excl_pile_fams = fam_set | auto_pile_fams
        for el in FilteredElementCollector(doc).OfCategory(bic_sc).WhereElementIsNotElementType():
            if _tname(el) != "FamilyInstance":
                continue
            eid_val = _eid_value(el.Id)
            if eid_val in seen_pile_ids:
                continue
            fam, typ = _fam_type(el, doc)
            if fam in excl_pile_fams:
                continue
            bb = el.get_BoundingBox(None)
            if bb is None:
                continue
            sols = _revit_solids(el)
            poly = _bottom_polygon(sols, ctx) if sols else _bbox_poly(el, ctx)
            if not poly or len(poly) < 3:
                poly = _bbox_poly(el, ctx)
            if not poly:
                continue
            mbr = min_area_rect(poly)
            cols.append({
                "id": eid_val,
                "mark": _mark(el),
                "type": typ or fam,
                "cx": mbr["cx"],
                "cy": mbr["cy"],
                "b": mbr["B"],
                "h": mbr["L"],
                "zmin": ctx.z(bb.Min.Z),
                "zmax": ctx.z(bb.Max.Z),
                "poly": poly,
            })

    # 5) Collect Revit Structural Grids for Dầm Móng & Móng Băng axis labeling
    grids = []
    try:
        from Autodesk.Revit.DB import Grid as RevitGrid
        for g in FilteredElementCollector(doc).OfClass(RevitGrid):
            try:
                g_name = (getattr(g, "Name", None) or "").strip()
                crv = getattr(g, "Curve", None)
                if crv is None or not g_name:
                    continue
                gp0 = ctx.xy(crv.GetEndPoint(0))
                gp1 = ctx.xy(crv.GetEndPoint(1))
                if math.hypot(gp1["x"] - gp0["x"], gp1["y"] - gp0["y"]) >= 50.0:
                    grids.append({"name": g_name, "p0": gp0, "p1": gp1})
            except Exception:
                continue
    except Exception:
        pass

    if lot_count:
        notes.append(u"Đã tự động tách bỏ lớp BT lót (≤ %g mm) nằm trong Family ở %d móng." % (LOT_MAX, lot_count))
    if hdiff_count:
        notes.append(u"%d cấu kiện dầm/móng băng được đo chiều cao và độ lệch tâm theo MẶT CẮT THỰC." % hdiff_count)
    if grids:
        notes.append(u"Đã đọc %d đường lưới trục (Grids) từ Revit." % len(grids))

    return build_revit_candidates(foots, piles, strips, dams, cols, {"pile_families": fam_set | auto_pile_fams, "dai_fams": dai_set, "bang_b": bang_b}, notes, grids=grids)

