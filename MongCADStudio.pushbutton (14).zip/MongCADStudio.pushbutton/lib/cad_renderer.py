# -*- coding: utf-8 -*-
"""
Unified CAD Vector Scene Builder & WPF Canvas Renderer for all 4 foundation modules:
- mong_don (Móng Đơn)
- mong_bang (Móng Băng)
- mong_coc (Móng Cọc)
- dam_mong (Dầm Móng)

Builds world-coordinate vector primitives once so WPF Canvas and AutoCAD DXF export
render the exact same engineering drawing.
"""

import math
from calc_engine import (
    build_project_rebar_summary,
    compute_footing,
    compute_foundation_beam,
    compute_pile_cap,
    compute_strip_footing,
    format_elevation,
)
from poly_geom import clip_line_to_poly, offset_polygon

CAD = {
    "bg": "#14171C",
    "frame": "#E5E7EB",
    "concrete": "#00F0FF",
    "capPlanEdge": "#94A3B8",
    "colPlanMagenta": "#E84393",
    "pileYellow": "#FACC15",
    "axisGreen": "#22E559",
    "zigzag": "#38BDF8",
    "hatch": "#727B88",
    "rebar": "#FF2B2B",
    "stirrup": "#E84393",
    "dimLine": "#8D97A5",
    "dimText": "#22E559",
    "calloutCircle": "#94A3B8",
    "calloutNum": "#F87171",
    "titleText": "#FFFFFF",
    "axisLabel": "#EAB308",
}


class SceneBuilder(object):
    def __init__(self, layers):
        self.layers = layers
        self.prims = []
        self.min_x = float("inf")
        self.min_y = float("inf")
        self.max_x = float("-inf")
        self.max_y = float("-inf")

    def _expand(self, x, y):
        if x < self.min_x:
            self.min_x = x
        if y < self.min_y:
            self.min_y = y
        if x > self.max_x:
            self.max_x = x
        if y > self.max_y:
            self.max_y = y

    def line(self, x1, y1, x2, y2, color, width=3.5, layer="DCE_BaoBeTong", dash=None):
        x1, y1, x2, y2 = float(x1), float(y1), float(x2), float(y2)
        self._expand(x1, y1)
        self._expand(x2, y2)
        self.prims.append({
            "kind": "line",
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
            "color": color, "width": float(width), "layer": layer, "dash": dash,
        })

    def rect(self, x, y, w, h, stroke=None, fill=None, width=3.5, layer="DCE_BaoBeTong", dash=None):
        x, y, w, h = float(x), float(y), float(w), float(h)
        self._expand(x, y)
        self._expand(x + w, y + h)
        self.prims.append({
            "kind": "rect",
            "x": x, "y": y, "w": w, "h": h,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def polygon(self, pts, stroke=None, fill=None, width=3.5, layer="DCE_BaoBeTong", dash=None):
        if not pts or len(pts) < 3:
            return
        norm_pts = [(float(p[0]), float(p[1])) for p in pts]
        for px, py in norm_pts:
            self._expand(px, py)
        self.prims.append({
            "kind": "polygon",
            "pts": norm_pts,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def polyline(self, pts, color, width=3.5, layer="DCE_BaoBeTong", closed=False, dash=None):
        if not pts or len(pts) < 2:
            return
        norm_pts = [(float(p[0]), float(p[1])) for p in pts]
        for px, py in norm_pts:
            self._expand(px, py)
        self.prims.append({
            "kind": "polyline",
            "pts": norm_pts,
            "color": color, "width": float(width), "layer": layer, "closed": closed, "dash": dash,
        })

    def circle(self, cx, cy, r, stroke=None, fill=None, width=3.5, layer="DCE_Block", dash=None):
        cx, cy, r = float(cx), float(cy), float(r)
        self._expand(cx - r, cy - r)
        self._expand(cx + r, cy + r)
        self.prims.append({
            "kind": "circle",
            "cx": cx, "cy": cy, "r": r,
            "color": stroke, "fill": fill, "width": float(width), "layer": layer, "dash": dash,
        })

    def text(self, x, y, txt, color, size=48.0, anchor="middle", layer="DCE_Dim", bold=False, rotate=0.0, underline=False):
        x, y = float(x), float(y)
        self._expand(x - size, y - size)
        self._expand(x + size, y + size)
        self.prims.append({
            "kind": "text",
            "x": x, "y": y, "text": str(txt),
            "color": color, "size": float(size), "anchor": anchor,
            "layer": layer, "bold": bool(bold), "rotate": float(rotate),
            "underline": bool(underline),
        })

    def arch_tick(self, x, y, size=18.0, width=5.0):
        self.line(x - size, y + size, x + size, y - size, CAD["dimLine"], width, layer="DCE_Dim")

    def dim_h(self, x1, x2, y_dim, y_ext1, text, y_ext2=None, font_size=48.0, tick_size=18.0, overshoot=35.0, text_above=True):
        if not self.layers.get("DCE_Dim", True):
            return
        if y_ext2 is None:
            y_ext2 = y_ext1
        min_x = min(x1, x2)
        max_x = max(x1, x2)
        if max_x - min_x < 1.0:
            return
        dir1 = 1.0 if y_dim > y_ext1 else -1.0
        dir2 = 1.0 if y_dim > y_ext2 else -1.0
        mid_x = (min_x + max_x) / 2.0
        sw = max(2.2, font_size * 0.048)
        text_y = (y_dim - font_size * 0.45) if text_above else (y_dim + font_size * 1.1)
        self.line(min_x, y_ext1, min_x, y_dim + dir1 * overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.line(max_x, y_ext2, max_x, y_dim + dir2 * overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.line(min_x - overshoot, y_dim, max_x + overshoot, y_dim, CAD["dimLine"], sw, "DCE_Dim")
        self.arch_tick(min_x, y_dim, tick_size, sw * 1.7)
        self.arch_tick(max_x, y_dim, tick_size, sw * 1.7)
        self.text(mid_x, text_y, text, CAD["dimText"], font_size, "middle", "DCE_Dim", bold=True)

    def dim_v(self, y1, y2, x_dim, x_ext1, text, x_ext2=None, font_size=48.0, tick_size=18.0, overshoot=35.0, text_side="left", rotate_text=False):
        if not self.layers.get("DCE_Dim", True):
            return
        if x_ext2 is None:
            x_ext2 = x_ext1
        min_y = min(y1, y2)
        max_y = max(y1, y2)
        if max_y - min_y < 1.0:
            return
        dir1 = 1.0 if x_dim > x_ext1 else -1.0
        dir2 = 1.0 if x_dim > x_ext2 else -1.0
        mid_y = (min_y + max_y) / 2.0
        sw = max(2.2, font_size * 0.048)
        self.line(x_ext1, min_y, x_dim + dir1 * overshoot, min_y, CAD["dimLine"], sw, "DCE_Dim")
        self.line(x_ext2, max_y, x_dim + dir2 * overshoot, max_y, CAD["dimLine"], sw, "DCE_Dim")
        self.line(x_dim, min_y - overshoot, x_dim, max_y + overshoot, CAD["dimLine"], sw, "DCE_Dim")
        self.arch_tick(x_dim, min_y, tick_size, sw * 1.7)
        self.arch_tick(x_dim, max_y, tick_size, sw * 1.7)
        if rotate_text:
            tx = x_dim - font_size * 0.85 if text_side == "left" else x_dim + font_size * 0.25
            self.text(tx, mid_y, text, CAD["dimText"], font_size, "middle", "DCE_Dim", bold=True, rotate=-90.0)
        elif text_side == "right":
            self.text(x_dim + font_size * 0.55, mid_y, text, CAD["dimText"], font_size, "start", "DCE_Dim", bold=True)
        else:
            self.text(x_dim - font_size * 0.55, mid_y, text, CAD["dimText"], font_size, "end", "DCE_Dim", bold=True)

    def callout(self, cx, cy, mark, spec_text, leader_pts, text_side="right", r=54.0, font_size=48.0, ox=0.0, oy=0.0, rotate=0.0):
        if not self.layers.get("DCE_Block", True):
            return
        shifted = [(px + ox, py + oy) for (px, py) in leader_pts]
        self.polyline(shifted, CAD["dimLine"], max(2.5, font_size * 0.055), "DCE_Block")
        acx, acy = cx + ox, cy + oy
        self.circle(acx, acy, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(3.0, font_size * 0.065), layer="DCE_Block")
        self.text(acx, acy + font_size * 0.1, mark, CAD["calloutNum"], font_size, "middle", "DCE_Block", bold=True)
        if abs(rotate) > 1.0:
            self.text(acx, acy - r - font_size * 0.55, spec_text, CAD["dimText"], font_size, "start", "DCE_Block", bold=True, rotate=rotate)
        else:
            tx = (acx - r - font_size * 0.35) if text_side == "left" else (acx + r + font_size * 0.35)
            anchor = "end" if text_side == "left" else "start"
            self.text(tx, acy - font_size * 0.55, spec_text, CAD["dimText"], font_size, anchor, "DCE_Block", bold=True)

    def plan_callout(self, cx, cy, mark, spec_text, r=62.5, font_size=50.0, ox=0.0, oy=0.0, rotate=0.0):
        """DcePro *U12 plan rebar callout: circle + bar number + green spec text, no leader."""
        if not self.layers.get("DCE_Block", True):
            return
        acx, acy = cx + ox, cy + oy
        self.circle(acx, acy, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(2.6, font_size * 0.06), layer="DCE_Block")
        if abs(rotate) > 1.0:
            self.text(acx, acy, mark, CAD["calloutNum"], font_size, "middle", "DCE_Block", bold=True, rotate=rotate)
            self.text(acx - font_size * 0.35, acy - r - font_size * 0.35, spec_text, CAD["dimText"], font_size, "start", "DCE_Block", bold=True, rotate=rotate)
        else:
            self.text(acx, acy + font_size * 0.08, mark, CAD["calloutNum"], font_size, "middle", "DCE_Block", bold=True)
            self.text(acx + r + font_size * 0.35, acy + font_size * 0.05, spec_text, CAD["dimText"], font_size, "start", "DCE_Block", bold=True)

    def section_rebar_callout(self, bar_x, bar_y, shoulder_y, shoulder_len, side, mark, spec_text, r=62.5, font_size=50.0, ox=0.0, oy=0.0):
        """DcePro *U1 / *U2 section rebar callout: vertical leader drop from bar to horizontal shoulder + outer tip circle."""
        if not self.layers.get("DCE_Block", True):
            return
        bx, by = bar_x + ox, bar_y + oy
        sy = shoulder_y + oy
        sx = bx + (shoulder_len if side == "right" else -shoulder_len)
        self.polyline([(bx, by), (bx, sy), (sx, sy)], CAD["dimLine"], max(2.4, font_size * 0.05), "DCE_Dim")
        cx = sx + (r if side == "right" else -r)
        self.circle(cx, sy, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(2.6, font_size * 0.06), layer="DCE_Block")
        self.text(cx, sy + font_size * 0.08, mark, CAD["calloutNum"], font_size, "middle", "DCE_Block", bold=True)
        if side == "right":
            self.text(sx - font_size * 0.25, sy - font_size * 0.55, spec_text, CAD["dimText"], font_size, "end", "DCE_Block", bold=True)
        else:
            self.text(sx + font_size * 0.25, sy - font_size * 0.55, spec_text, CAD["dimText"], font_size, "start", "DCE_Block", bold=True)

    def callout_u12(self, tip_x, tip_y, mark, spec_text, leader_branches, circle_side="left", s=25.0, ox=0.0, oy=0.0):
        """Exact DcePro *U1 (circle_side='left') / *U2 (circle_side='right') rebar callout with multi-branch leaders and text sitting above the horizontal shoulder."""
        if not self.layers.get("DCE_Block", True):
            return
        tx, ty = tip_x + ox, tip_y + oy
        r = 2.5 * float(s)
        fs = 2.0 * float(s)
        sw_l = max(2.2, 0.08 * float(s))
        for br in (leader_branches or []):
            if len(br) >= 2:
                self.polyline([(px + ox, py + oy) for (px, py) in br], CAD["dimLine"], sw_l, "DCE_Dim")
        if circle_side == "left":
            cx = tx - r
            self.circle(cx, ty, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(2.4, 0.1 * float(s)), layer="DCE_Block")
            self.text(cx, ty + 0.08 * float(s), mark, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)
            self.text(tx + 0.54 * float(s), ty - 0.95 * float(s), spec_text, CAD["dimText"], fs, "start", "DCE_Block", bold=True)
        else:
            cx = tx + r
            self.circle(cx, ty, r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=max(2.4, 0.1 * float(s)), layer="DCE_Block")
            self.text(cx, ty + 0.08 * float(s), mark, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)
            self.text(tx - 0.54 * float(s), ty - 0.95 * float(s), spec_text, CAD["dimText"], fs, "end", "DCE_Block", bold=True)

    def axis_bubble(self, axis_x, top_y, label, s=60.0, ox=0.0, oy=0.0):
        """Exact Dce_KhTenTruc grid axis bubble: top/bottom/left/right ticks + double circle + bold label."""
        if not self.layers.get("DCE_Block", True):
            return
        ax, ty = axis_x + ox, top_y + oy
        sc = float(s)
        cy = ty + 3.5 * sc
        r = 2.5 * sc
        sw = max(2.8, 0.065 * sc)
        # Crosshair ticks on Layer '3'
        self.line(ax, ty, ax, ty + 1.0 * sc, CAD["axisGreen"], sw, "3")
        self.line(ax, cy + r, ax, cy + r + 1.0 * sc, CAD["axisGreen"], sw, "3")
        self.line(ax - r - 1.0 * sc, cy, ax - r, cy, CAD["axisGreen"], sw, "3")
        self.line(ax + r, cy, ax + r + 1.0 * sc, cy, CAD["axisGreen"], sw, "3")
        # Double concentric ring + label
        self.circle(ax, cy, r * 1.08, stroke=CAD["axisGreen"], fill=CAD["bg"], width=sw, layer="DCE_Block")
        self.circle(ax, cy, r, stroke=CAD["axisGreen"], fill=None, width=sw * 0.7, layer="DCE_Block")
        self.text(ax, cy + 0.1 * sc, label, CAD["axisLabel"], 2.0 * sc, "middle", "DCE_Block", bold=True)

    def section_marker(self, x, y, direction="up", label="1", size=46.0, line_len=110.0, ox=0.0, oy=0.0, label_side="left"):
        """Draw filled green section-cut triangle arrow + red label '1' matching sample DXF."""
        if not self.layers.get("DCE_Block", True):
            return
        ax, ay = x + ox, y + oy
        s = float(size)
        ll = float(line_len)
        fs = max(46.0, s * 1.15)
        if direction == "up":
            self.line(ax - ll * 0.5, ay, ax + ll * 0.5, ay, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax, ay - s), (ax - s * 0.65, ay), (ax + s * 0.65, ay)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            if label_side == "bottom":
                self.text(ax, ay + s * 1.1, label, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)
            else:
                self.text(ax - s * 1.15, ay - s * 0.1, label, CAD["calloutNum"], fs, "end", "DCE_Block", bold=True)
        elif direction == "down":
            self.line(ax - ll * 0.5, ay, ax + ll * 0.5, ay, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax, ay + s), (ax - s * 0.65, ay), (ax + s * 0.65, ay)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax - s * 1.15, ay + s * 0.65, label, CAD["calloutNum"], fs, "end", "DCE_Block", bold=True)
        elif direction == "right":
            if label_side == "left":
                # Exact DCE_MatCatA block: vertical cut bar + filled right-pointing triangle + red label on left
                self.line(ax, ay - ll * 0.5, ax, ay + ll * 0.5, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
                self.polygon([(ax + s * 1.18, ay), (ax, ay - ll * 0.5), (ax, ay + ll * 0.5)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
                self.text(ax - s * 2.4, ay + s * 0.1, label, CAD["calloutNum"], 2.0 * s, "middle", "DCE_Block", bold=True)
            else:
                self.line(ax, ay - ll * 0.5, ax, ay + ll * 0.5, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
                self.polygon([(ax + s, ay), (ax, ay - s * 0.65), (ax, ay + s * 0.65)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
                self.text(ax + s * 0.5, ay + s * 1.3, label, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)
        else:
            self.line(ax, ay - ll * 0.5, ax, ay + ll * 0.5, CAD["axisGreen"], max(4.0, s * 0.1), "DCE_Block")
            self.polygon([(ax - s, ay), (ax, ay - s * 0.65), (ax, ay + s * 0.65)], stroke=CAD["axisGreen"], fill=CAD["axisGreen"], width=2.0, layer="DCE_Block")
            self.text(ax - s * 0.5, ay + s * 1.3, label, CAD["calloutNum"], fs, "middle", "DCE_Block", bold=True)

    def elevation_flag(self, x_tip, y_tip, text, scale=25.0, side="left", ox=0.0, oy=0.0):
        if not self.layers.get("DCE_Block", True):
            return
        s = float(scale)
        xt, yt = x_tip + ox, y_tip + oy
        xa = (xt - 4.5 * s) if side == "left" else (xt + 4.5 * s)
        h_tri = 1.6 * s
        w_tri = 1.4 * s
        stem_h = 3.2 * s
        fs = 2.0 * s
        sw = max(2.4, 0.09 * s)
        l_start = (xa - 2.0 * s) if side == "left" else xt
        l_end = xt if side == "left" else (xa + 2.2 * s)
        self.line(l_start, yt, l_end, yt, CAD["hatch"], sw, "DCE_Block")
        self.polygon([(xa, yt), (xa - w_tri, yt - h_tri), (xa, yt - h_tri)], stroke=CAD["hatch"], fill=CAD["hatch"], width=sw, layer="DCE_Block")
        self.polygon([(xa, yt), (xa + w_tri, yt - h_tri), (xa, yt - h_tri)], stroke=CAD["hatch"], fill=None, width=sw, layer="DCE_Block")
        self.line(xa, yt, xa, yt - stem_h, CAD["hatch"], sw, "DCE_Block")
        self.line(xa - 1.5 * s, yt - stem_h, xa + 8.6 * s, yt - stem_h, CAD["hatch"], sw, "DCE_Block")
        self.text(xa + 0.4 * s, yt - stem_h - 0.55 * s, text, CAD["dimText"], fs, "start", "DCE_Block", bold=True)

    def title_block(self, x, y, title, scale_text, font_title=76.0, font_scale=48.0, ox=0.0, oy=0.0, underline_dxf=False, underline_scale_dxf=False):
        if not self.layers.get("DCE_Block", True):
            return
        ax, ay = x + ox, y + oy
        est_w = max(240.0, len(title) * font_title * 0.6)
        self.text(ax, ay, title, CAD["titleText"], font_title, "middle", "DCE_Block", bold=True, underline=underline_dxf)
        if not underline_dxf:
            self.line(ax - est_w / 2.0, ay + font_title * 0.45, ax + est_w / 2.0, ay + font_title * 0.45, CAD["titleText"], max(3.5, font_title * 0.06), "DCE_Block")
        self.text(ax, ay + font_title * 1.15, scale_text, CAD["calloutNum"], font_scale, "middle", "DCE_Block", bold=True, underline=underline_scale_dxf)

    def zigzag_v(self, x, y, length, ox=0.0, oy=0.0, layer="DCE_BaoBeTong"):
        half = length / 2.0
        zig = 35.0
        pts = [(x + ox, y - half + oy), (x + ox, y - zig + oy), (x - zig + ox, y + oy), (x + zig + ox, y + oy), (x + ox, y + zig + oy), (x + ox, y + half + oy)]
        self.polyline(pts, CAD["zigzag"], 3.5, layer)

    def zigzag_h(self, x1, x2, y, zig_w=70.0, zig_h=55.0, ox=0.0, oy=0.0, layer="DCE_BaoBeTong"):
        mid = (x1 + x2) / 2.0
        pts = [
            (x1 + ox, y + oy),
            (mid - zig_w + ox, y + oy),
            (mid - zig_w / 3.0 + ox, y - zig_h + oy),
            (mid + zig_w / 3.0 + ox, y + zig_h + oy),
            (mid + zig_w + ox, y + oy),
            (x2 + ox, y + oy),
        ]
        self.polyline(pts, CAD["zigzag"], 4.0, layer)

    def hatch_diagonal(self, x, y, w, h, step=90.0, ox=0.0, oy=0.0):
        if not self.layers.get("DCE_Hatch", True) or w <= 0 or h <= 0:
            return
        step = max(40.0, float(step))
        ax, ay = x + ox, y + oy
        self.rect(ax, ay, w, h, stroke=None, fill="#171B22", width=0.0, layer="DCE_Hatch")
        span = w + h
        d = step * 0.5
        while d < span:
            x1 = ax + max(0.0, d - h)
            y1 = ay + min(h, d)
            x2 = ax + min(w, d)
            y2 = ay + max(0.0, d - w)
            if math.hypot(x2 - x1, y2 - y1) > 4.0:
                self.line(x1, y1, x2, y2, "#2A3240", 1.8, "DCE_Hatch")
            d += step

    def hatch_concrete(self, outer_pts, hole_pts=None, ox=0.0, oy=0.0, scale=15.0, pattern="AR-CONC"):
        if not self.layers.get("DCE_Hatch", True) or not outer_pts or len(outer_pts) < 3:
            return
        norm_outer = [(float(p[0]) + ox, float(p[1]) + oy) for p in outer_pts]
        norm_hole = [(float(p[0]) + ox, float(p[1]) + oy) for p in hole_pts] if (hole_pts and len(hole_pts) >= 3) else None
        for px, py in norm_outer:
            self._expand(px, py)
        self.prims.append({
            "kind": "hatch_conc",
            "outer": norm_outer,
            "hole": norm_hole,
            "pattern": pattern,
            "scale": float(scale),
            "color": CAD["hatch"],
            "fill": "#171B22",
            "layer": "DCE_Hatch",
        })

    def draw_rebar_table(self, x, y, title, rows, by_diam=None, scale=1.0, show_kind=False):
        """Draw a CAD vector Rebar Schedule Table + optional diameter summary (AutoCAD + WPF safe)."""
        s = max(0.45, float(scale))
        if show_kind:
            cols = [
                ("Cấu kiện", 480.0 * s, "start"),
                ("SH", 210.0 * s, "middle"),
                ("Tên thanh thép", 860.0 * s, "start"),
                ("Ø", 200.0 * s, "middle"),
                ("L (mm)", 300.0 * s, "end"),
                ("Tổng SL", 270.0 * s, "end"),
                ("Tổng L(m)", 340.0 * s, "end"),
                ("KL (kg)", 340.0 * s, "end"),
            ]
        else:
            cols = [
                ("SH", 230.0 * s, "middle"),
                ("Tên thanh thép", 960.0 * s, "start"),
                ("Ø", 210.0 * s, "middle"),
                ("L (mm)", 320.0 * s, "end"),
                ("SL/CK", 260.0 * s, "end"),
                ("Tổng SL", 280.0 * s, "end"),
                ("Tổng L(m)", 360.0 * s, "end"),
                ("KL (kg)", 360.0 * s, "end"),
            ]

        tbl_w = sum(c[1] for c in cols)
        title_h = 155.0 * s
        hdr_h = 140.0 * s
        row_h = 122.0 * s
        fs_title = 64.0 * s
        fs_hdr = 44.0 * s
        fs_cell = 42.0 * s
        pad_x = 22.0 * s

        safe_rows = list(rows or [])
        n_rows = len(safe_rows)
        main_h = title_h + hdr_h + (n_rows + 1) * row_h

        # Outer border + title divider
        self.rect(x, y, tbl_w, main_h, stroke=CAD["frame"], fill=None, width=4.2, layer="DCE_Khung")
        self.text(x + tbl_w / 2.0, y + title_h * 0.54, title, CAD["titleText"], fs_title, "middle", "DCE_Block", bold=True)
        y_hdr = y + title_h
        self.line(x, y_hdr, x + tbl_w, y_hdr, CAD["frame"], 3.8, "DCE_Khung")
        y_body = y_hdr + hdr_h
        self.line(x, y_body, x + tbl_w, y_body, CAD["frame"], 3.8, "DCE_Khung")

        # Column vertical gridlines & column headers
        cx = x
        for ci, (cname, cw, _align) in enumerate(cols):
            if ci > 0:
                self.line(cx, y_hdr, cx, y + main_h, CAD["dimLine"], 2.4, "DCE_Khung")
            self.text(cx + cw / 2.0, y_hdr + hdr_h * 0.54, cname, CAD["titleText"], fs_hdr, "middle", "DCE_Block", bold=True)
            cx += cw

        # Data rows
        total_kg = 0.0
        total_m = 0.0
        for ri, r in enumerate(safe_rows):
            ry = y_body + ri * row_h
            self.line(x, ry + row_h, x + tbl_w, ry + row_h, CAD["dimLine"], 2.0, "DCE_Khung")
            total_kg += float(r.get("massTotal", 0.0))
            total_m += float(r.get("totalLenM", 0.0))
            if show_kind:
                ck_name = ("%s %s" % (r.get("kindLabel", ""), r.get("ten", ""))).strip()[:22]
                vals = [
                    ck_name,
                    str(r.get("mark", "")),
                    str(r.get("name", ""))[:30],
                    "Ø%g" % float(r.get("d", 0)),
                    "%d" % int(round(float(r.get("lenMm", 0)))),
                    "%d" % int(round(float(r.get("totalQty", 0)))),
                    "%.2f" % float(r.get("totalLenM", 0.0)),
                    "%.2f" % float(r.get("massTotal", 0.0)),
                ]
            else:
                vals = [
                    str(r.get("mark", "")),
                    str(r.get("name", ""))[:34],
                    "Ø%g" % float(r.get("d", 0)),
                    "%d" % int(round(float(r.get("lenMm", 0)))),
                    "%d" % int(round(float(r.get("qtyPerUnit", 0)))),
                    "%d" % int(round(float(r.get("totalQty", 0)))),
                    "%.2f" % float(r.get("totalLenM", 0.0)),
                    "%.2f" % float(r.get("massTotal", 0.0)),
                ]
            cx = x
            for ci, (_cname, cw, align) in enumerate(cols):
                if align == "start":
                    tx = cx + pad_x
                elif align == "end":
                    tx = cx + cw - pad_x
                else:
                    tx = cx + cw / 2.0
                col_hex = CAD["calloutNum"] if (ci == (1 if show_kind else 0)) else (CAD["pileYellow"] if ci == len(cols) - 1 else CAD["dimText"])
                self.text(tx, ry + row_h * 0.55, vals[ci], col_hex, fs_cell, align, "DCE_Dim", bold=(ci in (0, len(cols) - 1)))
                cx += cw

        # Total row
        ty_tot = y_body + n_rows * row_h
        self.text(x + pad_x, ty_tot + row_h * 0.55, "TỔNG CỘNG THÉP", CAD["titleText"], fs_hdr, "start", "DCE_Block", bold=True)
        cx_len_r = tbl_w - cols[-1][1] - pad_x
        self.text(x + cx_len_r, ty_tot + row_h * 0.55, "%.2f m" % total_m, CAD["dimText"], fs_hdr, "end", "DCE_Dim", bold=True)
        self.text(x + tbl_w - pad_x, ty_tot + row_h * 0.55, "%.1f kg" % total_kg, CAD["pileYellow"], fs_hdr, "end", "DCE_Block", bold=True)

        total_h = main_h
        if by_diam:
            gap_y = 65.0 * s
            sub_y = y + main_h + gap_y
            d_cols = [
                ("Đường kính", 460.0 * s, "middle"),
                ("Số thanh", 460.0 * s, "end"),
                ("Tổng dài (m)", 520.0 * s, "end"),
                ("KL riêng (kg/m)", 500.0 * s, "end"),
                ("Cây 11.7m", 500.0 * s, "end"),
                ("Khối lượng (kg)", max(540.0 * s, tbl_w - 2440.0 * s), "end"),
            ]
            d_list = list(by_diam)
            sub_h = hdr_h + hdr_h + (len(d_list) + 1) * row_h
            self.rect(x, sub_y, tbl_w, sub_h, stroke=CAD["frame"], fill=None, width=4.0, layer="DCE_Khung")
            self.text(x + tbl_w / 2.0, sub_y + hdr_h * 0.54, "TỔNG HỢP THÉP THEO ĐƯỜNG KÍNH (CÂY 11.7m)", CAD["titleText"], fs_hdr * 1.12, "middle", "DCE_Block", bold=True)
            sy_hdr = sub_y + hdr_h
            self.line(x, sy_hdr, x + tbl_w, sy_hdr, CAD["frame"], 3.5, "DCE_Khung")
            sy_body = sy_hdr + hdr_h
            self.line(x, sy_body, x + tbl_w, sy_body, CAD["frame"], 3.5, "DCE_Khung")
            cx = x
            for ci, (cname, cw, _align) in enumerate(d_cols):
                if ci > 0:
                    self.line(cx, sy_hdr, cx, sub_y + sub_h, CAD["dimLine"], 2.2, "DCE_Khung")
                self.text(cx + cw / 2.0, sy_hdr + hdr_h * 0.54, cname, CAD["titleText"], fs_cell, "middle", "DCE_Block", bold=True)
                cx += cw

            sub_kg = 0.0
            for di, item_d in enumerate(d_list):
                ry = sy_body + di * row_h
                self.line(x, ry + row_h, x + tbl_w, ry + row_h, CAD["dimLine"], 2.0, "DCE_Khung")
                sub_kg += float(item_d.get("massTotal", 0.0))
                d_vals = [
                    "Ø%g" % float(item_d.get("d", 0)),
                    "%d" % int(item_d.get("totalQty", 0)),
                    "%.2f" % float(item_d.get("totalLenM", 0.0)),
                    "%.3f" % float(item_d.get("unitMass", 0.0)),
                    "%.2f" % float(item_d.get("bars117", 0.0)),
                    "%.2f" % float(item_d.get("massTotal", 0.0)),
                ]
                cx = x
                for ci, (_cname, cw, align) in enumerate(d_cols):
                    tx = (cx + pad_x) if align == "start" else ((cx + cw - pad_x) if align == "end" else (cx + cw / 2.0))
                    col_hex = CAD["pileYellow"] if ci == len(d_cols) - 1 else CAD["dimText"]
                    self.text(tx, ry + row_h * 0.55, d_vals[ci], col_hex, fs_cell, align, "DCE_Dim", bold=(ci in (0, 5)))
                    cx += cw

            ty_sub_tot = sy_body + len(d_list) * row_h
            self.text(x + pad_x, ty_sub_tot + row_h * 0.55, "TỔNG KHỐI LƯỢNG THÉP", CAD["titleText"], fs_hdr, "start", "DCE_Block", bold=True)
            self.text(x + tbl_w - pad_x, ty_sub_tot + row_h * 0.55, "%.1f kg" % sub_kg, CAD["pileYellow"], fs_hdr, "end", "DCE_Block", bold=True)
            total_h = main_h + gap_y + sub_h

        return tbl_w, total_h

    def build_result(self):
        if self.min_x == float("inf"):
            return {"bounds": (0.0, 0.0, 1000.0, 1000.0), "primitives": []}
        return {
            "bounds": (self.min_x, self.min_y, self.max_x, self.max_y),
            "primitives": self.prims,
        }


def _poly_svg_pts(poly, ox=0.0, oy=0.0):
    return [(p["x"] + ox, -p["y"] + oy) for p in poly]


# ==================== 1. MÓNG ĐƠN SCENE ====================

def _draw_single_footing(sb, cfg, view_mode="sheet", ox=0.0, include_schedule=False):
    comp = compute_footing(cfg)
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    h_mep = float(cfg["hMep"])
    half_b = B / 2.0
    half_l = L / 2.0
    lean_mb = float(cfg["lotChiaMatBang"])
    lean_mc = float(cfg["lotChiaMatCat"])
    sc = max(0.6, float(cfg.get("tiLe", 25)) / 25.0)

    col_cx = comp["colCx"]
    col_cy = -comp["colCy"]
    col_left = col_cx - float(cfg["cotB"]) / 2.0
    col_right = col_cx + float(cfg["cotB"]) / 2.0
    col_top = col_cy - float(cfg["cotH"]) / 2.0
    col_bot = col_cy + float(cfg["cotH"]) / 2.0

    ped_left = comp["pedLeft"]
    ped_right = comp["pedRight"]
    ped_top = -comp["pedTop"]
    ped_bot = -comp["pedBot"]

    # Sample DXF plan dim chain offsets: 225mm & 350mm from footing pad boundary
    d_off1 = max(225.0, lean_mb + 95.0)
    d_off2 = d_off1 + 125.0
    top_dim1 = -half_l - d_off1
    top_dim2 = -half_l - d_off2
    bot_dim1 = half_l + d_off1
    bot_dim2 = half_l + d_off2
    left_dim1 = -half_b - d_off1
    left_dim2 = -half_b - d_off2
    right_dim1 = half_b + d_off1
    right_dim2 = half_b + d_off2
    plan_title_y = bot_dim2 + 175.0 * sc

    # Section vertical coordinates matching sample DXF
    sec_origin_y = 350.0 if view_mode == "section" else (plan_title_y + 2065.0)
    sec_bot_y = sec_origin_y
    sec_mep_y = sec_bot_y - h_mep
    sec_top_y = sec_bot_y - H
    sec_beam_top_y = sec_top_y - float(cfg["caoTuDinhDaiDenMatGiang"])
    sec_beam_bot_y = sec_beam_top_y + float(cfg["giangH"])
    col_ref_top = sec_beam_top_y if cfg["giangMode"] != "none" else sec_top_y
    sec_col_top_y = col_ref_top - float(cfg["chieuCaoCotVeThem"])
    lean_bot_y = sec_bot_y + float(cfg["lotDay"])
    sec_title_y = lean_bot_y + 625.0

    # Invisible Defpoints sheet bounding box (matches sample DXF; no visible outer white box)
    frame_left = min(-half_b - 1020.0, -1380.0 * sc)
    frame_right = max(half_b + 1020.0, 1380.0 * sc)
    frame_top = (sec_col_top_y - 160.0) if view_mode == "section" else (top_dim2 - 140.0)
    frame_bot = (plan_title_y + 210.0) if view_mode == "plan" else (sec_title_y + 210.0)
    sb.rect(ox + frame_left, frame_top, frame_right - frame_left, frame_bot - frame_top, stroke=None, fill=None, width=0.0, layer="Defpoints")

    show_plan = view_mode in ("sheet", "plan")
    show_sec = view_mode in ("sheet", "section")

    if show_plan:
        # 1. Lean concrete perimeter & AR-CONC ring hatch (DCE_Hatch, gray)
        if float(cfg["lotDay"]) > 0 and lean_mb > 0 and sb.layers.get("DCE_Hatch", True):
            if comp["isPolygonal"]:
                lean_poly = offset_polygon(comp["outlinePolygon"], lean_mb)
                lean_pts = _poly_svg_pts(lean_poly, ox)
                pad_pts = _poly_svg_pts(comp["outlinePolygon"], ox)
                sb.hatch_concrete(lean_pts, hole_pts=pad_pts, scale=15.0 * sc, pattern="AR-CONC")
                sb.polygon(lean_pts, stroke=CAD["hatch"], fill=None, width=3.2, layer="DCE_Hatch")
            else:
                lean_pts = [
                    (-half_b - lean_mb, -half_l - lean_mb),
                    (half_b + lean_mb, -half_l - lean_mb),
                    (half_b + lean_mb, half_l + lean_mb),
                    (-half_b - lean_mb, half_l + lean_mb),
                ]
                pad_pts = [
                    (-half_b, -half_l),
                    (half_b, -half_l),
                    (half_b, half_l),
                    (-half_b, half_l),
                ]
                sb.hatch_concrete(lean_pts, hole_pts=pad_pts, ox=ox, scale=15.0 * sc, pattern="AR-CONC")
                sb.rect(ox - half_b - lean_mb, -half_l - lean_mb, B + 2 * lean_mb, L + 2 * lean_mb, stroke=CAD["hatch"], fill=None, width=3.2, layer="DCE_Hatch")

        # 2. Footing pad, pedestal / Revit top plateau, chamfer slope lines & concrete-hatched columns
        if sb.layers.get("DCE_BaoBeTong", True):
            if comp["isPolygonal"]:
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            else:
                sb.rect(ox - half_b, -half_l, B, L, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")

            revit_top = comp.get("topPoly")
            revit_chamfers = comp.get("chamferLines")
            if revit_top or revit_chamfers:
                if revit_top and len(revit_top) >= 3:
                    sb.polygon(_poly_svg_pts(revit_top, ox), stroke=CAD["concrete"], fill=None, width=3.5, layer="DCE_BaoBeTong")
                if revit_chamfers:
                    for seg in revit_chamfers:
                        if isinstance(seg, dict):
                            x1, y1, x2, y2 = float(seg["x1"]), float(seg["y1"]), float(seg["x2"]), float(seg["y2"])
                        else:
                            x1, y1, x2, y2 = float(seg[0]), float(seg[1]), float(seg[2]), float(seg[3])
                        sb.line(ox + x1, -y1, ox + x2, -y2, CAD["concrete"], 3.5, "DCE_BaoBeTong")
            elif comp["isPolygonal"]:
                if h_mep < H - 5.0:
                    # Parametric stepped/sloped polygonal pad without Revit ridges: inset top plateau + corner ridges
                    inset_d = min(min(B, L) * 0.25, max(80.0, min(B - float(cfg["cotB"]), L - float(cfg["cotH"])) * 0.35))
                    top_p = offset_polygon(comp["outlinePolygon"], -inset_d) if inset_d > 20.0 else None
                    if top_p and len(top_p) >= 3:
                        sb.polygon(_poly_svg_pts(top_p, ox), stroke=CAD["concrete"], fill=None, width=3.5, layer="DCE_BaoBeTong")
                        if len(top_p) == len(comp["outlinePolygon"]):
                            for p_bot, p_top in zip(comp["outlinePolygon"], top_p):
                                if math.hypot(p_bot["x"] - p_top["x"], p_bot["y"] - p_top["y"]) > 10.0:
                                    sb.line(ox + p_bot["x"], -p_bot["y"], ox + p_top["x"], -p_top["y"], CAD["concrete"], 3.5, "DCE_BaoBeTong")
            else:
                # Pedestal top perimeter (col + goCoCot)
                sb.rect(ox + ped_left, ped_top, ped_right - ped_left, ped_bot - ped_top, stroke=CAD["concrete"], fill=None, width=3.5, layer="DCE_BaoBeTong")
                # Chamfer slope lines only for non-flush corners (exact match to MĐ1/MĐ2/MĐ3)
                if abs(ped_left - (-half_b)) > 1.0 and abs(ped_top - (-half_l)) > 1.0:
                    sb.line(ox - half_b, -half_l, ox + ped_left, ped_top, CAD["concrete"], 3.5, "DCE_BaoBeTong")
                if abs(ped_right - half_b) > 1.0 and abs(ped_top - (-half_l)) > 1.0:
                    sb.line(ox + half_b, -half_l, ox + ped_right, ped_top, CAD["concrete"], 3.5, "DCE_BaoBeTong")
                if abs(ped_left - (-half_b)) > 1.0 and abs(ped_bot - half_l) > 1.0:
                    sb.line(ox - half_b, half_l, ox + ped_left, ped_bot, CAD["concrete"], 3.5, "DCE_BaoBeTong")
                if abs(ped_right - half_b) > 1.0 and abs(ped_bot - half_l) > 1.0:
                    sb.line(ox + half_b, half_l, ox + ped_right, ped_bot, CAD["concrete"], 3.5, "DCE_BaoBeTong")

            # Column section block (*U13 style: crisp light outline + AR-CONC hatch, NO magenta X-cross)
            for col in comp["allColumns"]:
                cl = ox + col["x"] - col["b"] / 2.0
                ct = -col["y"] - col["h"] / 2.0
                cw_c = float(col["b"])
                ch_c = float(col["h"])
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_concrete([(cl, ct), (cl + cw_c, ct), (cl + cw_c, ct + ch_c), (cl, ct + ch_c)], scale=6.0 * sc, pattern="AR-CONC")
                sb.rect(cl, ct, cw_c, ch_c, stroke="#CBD5E1", fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 3. Plan rebar bars 1 (horizontal) & 2 (vertical) + *U12 callouts directly on bars
        cover_c = float(cfg["coverCanh"])
        bar1_y = (-half_l + 100.0) if col_bot > half_l - 220.0 else (half_l - 100.0)
        bar2_x = (-half_b + 100.0) if col_right > half_b - 220.0 else (half_b - 100.0)
        bar1_s, bar1_e = -half_b + cover_c, half_b - cover_c
        bar2_s, bar2_e = -half_l + cover_c, half_l - cover_c
        if comp["isPolygonal"]:
            inner_p = offset_polygon(comp["outlinePolygon"], -max(25.0, cover_c))
            if len(inner_p) >= 3:
                best_len = -1.0
                for cy_cand in (half_l - 120.0, -half_l + 120.0, half_l * 0.45, -half_l * 0.45, 0.0):
                    for s, e in clip_line_to_poly(inner_p, "x", -cy_cand):
                        if e - s > best_len:
                            best_len = e - s
                            bar1_y, bar1_s, bar1_e = cy_cand, s, e
                best_len2 = -1.0
                for cx_cand in (half_b - 120.0, -half_b + 120.0, half_b * 0.45, -half_b * 0.45, 0.0):
                    for s, e in clip_line_to_poly(inner_p, "y", cx_cand):
                        if e - s > best_len2:
                            best_len2 = e - s
                            bar2_x, bar2_s, bar2_e = cx_cand, -e, -s

        if sb.layers.get("DCE_ThepChu", True):
            sb.line(ox + bar1_s, bar1_y, ox + bar1_e, bar1_y, CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.line(ox + bar2_x, bar2_s, ox + bar2_x, bar2_e, CAD["rebar"], 6.0, "DCE_ThepChu")
            bx = cfg["thepPhuongX"]
            by = cfg["thepPhuongY"]
            b1_r = 62.5 * sc
            b1_cx = max(bar1_s + b1_r + 40.0, min(bar1_e - 360.0 * sc, col_cx - 112.5 * sc))
            b1_cy = (bar1_y - 75.0 * sc) if bar1_y > 0 else (bar1_y + 75.0 * sc)
            sb.plan_callout(b1_cx, b1_cy, "1", "Ø%da%d" % (bx["d"], bx["a"]), r=b1_r, font_size=50.0 * sc, ox=ox)

            b2_cx = (bar2_x - 75.0 * sc) if bar2_x > 0 else (bar2_x + 75.0 * sc)
            b2_cy = max(bar2_s + 360.0 * sc, min(bar2_e - b1_r - 40.0, col_cy + 162.5 * sc))
            sb.plan_callout(b2_cx, b2_cy, "2", "Ø%da%d" % (by["d"], by["a"]), r=b1_r, font_size=50.0 * sc, ox=ox, rotate=-90.0)

        # 4. Green filled section cut arrows 1 - 1 on left & right of plan (centered vertically on pad)
        sb.section_marker(-half_b - 520.0, 0.0, "up", "1", size=46.0 * sc, line_len=135.0 * sc, ox=ox, label_side="bottom")
        sb.section_marker(half_b + 520.0, 0.0, "up", "1", size=46.0 * sc, line_len=135.0 * sc, ox=ox, label_side="bottom")

        # 5. Full 4-side Plan Dimension Chains (exact match: 650|200|650 & 1500; omits 0 when flush)
        sb.dim_h(ox - half_b, ox + half_b, top_dim2, -half_l, str(int(round(B))), text_above=True)
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, top_dim1, -half_l, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, top_dim1, -half_l, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, top_dim1, -half_l, str(comp["dxRight"]), text_above=True)

        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, bot_dim1, half_l, str(comp["dxLeft"]), text_above=False)
        sb.dim_h(ox + col_left, ox + col_right, bot_dim1, half_l, str(int(round(cfg["cotB"]))), text_above=False)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, bot_dim1, half_l, str(comp["dxRight"]), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, bot_dim2, half_l, str(int(round(B))), text_above=False)

        sb.dim_v(-half_l, half_l, ox + left_dim2, -half_b, str(int(round(L))), text_side="left", rotate_text=True)
        if comp["dyTop"] > 0:
            sb.dim_v(-half_l, col_top, ox + left_dim1, -half_b, str(comp["dyTop"]), text_side="left", rotate_text=True)
        sb.dim_v(col_top, col_bot, ox + left_dim1, -half_b, str(int(round(cfg["cotH"]))), text_side="left", rotate_text=True)
        if comp["dyBot"] > 0:
            sb.dim_v(col_bot, half_l, ox + left_dim1, -half_b, str(comp["dyBot"]), text_side="left", rotate_text=True)

        if comp["dyTop"] > 0:
            sb.dim_v(-half_l, col_top, ox + right_dim1, half_b, str(comp["dyTop"]), text_side="right", rotate_text=True)
        sb.dim_v(col_top, col_bot, ox + right_dim1, half_b, str(int(round(cfg["cotH"]))), text_side="right", rotate_text=True)
        if comp["dyBot"] > 0:
            sb.dim_v(col_bot, half_l, ox + right_dim1, half_b, str(comp["dyBot"]), text_side="right", rotate_text=True)
        sb.dim_v(-half_l, half_l, ox + right_dim2, half_b, str(int(round(L))), text_side="right", rotate_text=True)

        sub_parts = []
        if comp["isPolygonal"]:
            sub_parts.append("%d ĐỈNH" % len(comp["outlinePolygon"]))
        if cfg.get("gocXoay") and abs(float(cfg["gocXoay"])) > 1:
            sub_parts.append("%g°" % cfg["gocXoay"])
        title_str = "MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"])
        if sub_parts:
            title_str += " · " + " · ".join(sub_parts)
        sb.title_block(0, plan_title_y, title_str, "TL: 1/%d" % cfg["tiLe"], font_title=95.0 * sc, font_scale=50.0 * sc, ox=ox, underline_dxf=True)

    if show_sec:
        # 1. Green dashed center axis line through column centerline (Layer '3' HIDDEN2)
        sb.line(ox + col_cx, sec_col_top_y - 50.0, ox + col_cx, lean_bot_y + 275.0, CAD["axisGreen"], 2.8, layer="3", dash=(90, 45))

        # 2. Lean concrete in section (AR-CONC hatch + cyan outline)
        if float(cfg["lotDay"]) > 0:
            lw = B + 2 * lean_mc
            if sb.layers.get("DCE_Hatch", True):
                sb.hatch_concrete([
                    (-half_b - lean_mc, sec_bot_y),
                    (half_b + lean_mc, sec_bot_y),
                    (half_b + lean_mc, lean_bot_y),
                    (-half_b - lean_mc, lean_bot_y),
                ], ox=ox, scale=15.0 * sc, pattern="AR-CONC")
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(ox - half_b - lean_mc, sec_bot_y, lw, float(cfg["lotDay"]), stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 3. Footing wings + column shaft + tie beams + zigzag break lines
        if sb.layers.get("DCE_BaoBeTong", True):
            # Left footing wing & right footing wing (matches sample DXF open-top monolithic joint)
            sb.polyline([
                (ox - half_b, sec_bot_y),
                (ox - half_b, sec_mep_y),
                (ox + ped_left, sec_top_y),
                (ox + col_left, sec_top_y),
            ], CAD["concrete"], 4.5, "DCE_BaoBeTong")
            sb.polyline([
                (ox + half_b, sec_bot_y),
                (ox + half_b, sec_mep_y),
                (ox + ped_right, sec_top_y),
                (ox + col_right, sec_top_y),
            ], CAD["concrete"], 4.5, "DCE_BaoBeTong")

            show_left_b = cfg["giangMode"] in ("both", "left")
            show_right_b = cfg["giangMode"] in ("both", "right")
            stub = 900.0
            if show_left_b:
                sb.line(ox + col_left, sec_top_y, ox + col_left, sec_beam_bot_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + col_left, sec_beam_top_y, ox + col_left, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + col_left - stub, sec_beam_top_y, ox + col_left, sec_beam_top_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(ox + col_left - stub, sec_beam_bot_y, ox + col_left, sec_beam_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.zigzag_v(col_left - stub, (sec_beam_top_y + sec_beam_bot_y) / 2.0, float(cfg["giangH"]) + 70.0, ox, layer="DCE_MCZiCZac")
            else:
                sb.line(ox + col_left, sec_top_y, ox + col_left, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")

            if show_right_b:
                sb.line(ox + col_right, sec_top_y, ox + col_right, sec_beam_bot_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + col_right, sec_beam_top_y, ox + col_right, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + col_right, sec_beam_top_y, ox + col_right + stub, sec_beam_top_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.line(ox + col_right, sec_beam_bot_y, ox + col_right + stub, sec_beam_bot_y, CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.zigzag_v(col_right + stub, (sec_beam_top_y + sec_beam_bot_y) / 2.0, float(cfg["giangH"]) + 70.0, ox, layer="DCE_MCZiCZac")
            else:
                sb.line(ox + col_right, sec_top_y, ox + col_right, sec_col_top_y, CAD["concrete"], 4.5, "DCE_BaoBeTong")

            sb.zigzag_h(col_left - 85.0, col_right + 85.0, sec_col_top_y, 35.0, 35.0, ox, layer="DCE_MCZiCZac")

        # 4. Rebar in section
        rebar_bot_y = sec_bot_y - float(cfg["coverDay"])
        rebar_l_x = -half_b + float(cfg["coverCanh"])
        rebar_r_x = half_b - float(cfg["coverCanh"])
        dot_r = max(6.0, float(cfg["thepPhuongY"]["d"]) / 2.0)
        dot_y = rebar_bot_y - dot_r
        dot_count = min(28, max(2, comp["soThanhY"]))
        dots_x = [
            ((rebar_l_x + dot_r) + (rebar_r_x - rebar_l_x - 2 * dot_r) * i / float(dot_count - 1))
            for i in range(dot_count)
        ]

        if sb.layers.get("DCE_ThepChu", True):
            bx = cfg["thepPhuongX"]
            if bx.get("hasHook"):
                hk = min(float(bx.get("hookLen", 150)), H - 80.0)
                sb.polyline([
                    (ox + rebar_l_x, rebar_bot_y - hk),
                    (ox + rebar_l_x, rebar_bot_y),
                    (ox + rebar_r_x, rebar_bot_y),
                    (ox + rebar_r_x, rebar_bot_y - hk),
                ], CAD["rebar"], 6.5, "DCE_ThepChu")
            else:
                sb.line(ox + rebar_l_x, rebar_bot_y, ox + rebar_r_x, rebar_bot_y, CAD["rebar"], 6.5, "DCE_ThepChu")

            for dx in dots_x:
                sb.circle(ox + dx, dot_y, dot_r, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Column starter dowels (inset 50mm for 200mm column; flush at zigzag cut line)
            d_ins = min(50.0, max(20.0, float(cfg["cotB"]) * 0.25))
            dl_x = col_left + d_ins
            dr_x = col_right - d_ins
            d_foot_y = dot_y - dot_r - 20.0
            sb.polyline([
                (ox + dl_x - float(cfg["thepCotChanL"]), d_foot_y),
                (ox + dl_x, d_foot_y),
                (ox + dl_x, sec_col_top_y),
            ], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([
                (ox + dr_x + float(cfg["thepCotChanL"]), d_foot_y),
                (ox + dr_x, d_foot_y),
                (ox + dr_x, sec_col_top_y),
            ], CAD["rebar"], 6.0, "DCE_ThepChu")

            if sb.layers.get("DCE_ThepDai", True):
                sy = d_foot_y - 50.0
                step_a = max(80.0, float(cfg["thepDaiA"]))
                while sy >= sec_col_top_y + 15.0:
                    sb.line(ox + dl_x, sy, ox + dr_x, sy, CAD["stirrup"], 4.5, "DCE_ThepDai")
                    sy -= step_a

            # Section callouts *U1 (Bar 2 left) & *U2 (Bar 1 right) matching sample DXF LEADER geometry
            by = cfg["thepPhuongY"]
            call_y = lean_bot_y + 125.0 * sc
            sh_len = 250.0 * sc
            b2_dot_x = dots_x[min(2, len(dots_x) - 1)]
            b1_pick_x = min(rebar_r_x - 160.0, max(col_cx + 120.0, half_b * 0.52))
            sb.section_rebar_callout(b2_dot_x, dot_y, call_y, sh_len, "left", "2", "Ø%da%d" % (by["d"], by["a"]), r=62.5 * sc, font_size=50.0 * sc, ox=ox)
            sb.section_rebar_callout(b1_pick_x, rebar_bot_y, call_y, sh_len, "right", "1", "Ø%da%d" % (bx["d"], bx["a"]), r=62.5 * sc, font_size=50.0 * sc, ox=ox)

        # 5. Elevation flags (bottom footing & tie beam top on left, clear of dims at -half_b - 500)
        elev_x = -half_b - 500.0
        sb.elevation_flag(elev_x, sec_bot_y, format_elevation(cfg["caoTrinhDay"]), scale=float(cfg["tiLe"]), side="left", ox=ox)
        if cfg["giangMode"] != "none":
            sb.elevation_flag(elev_x, sec_beam_top_y, format_elevation(comp["caoTrinhMatGiang"]), scale=float(cfg["tiLe"]), side="left", ox=ox)
        else:
            sb.elevation_flag(elev_x, sec_top_y, format_elevation(comp["caoTrinhDinhDai"]), scale=float(cfg["tiLe"]), side="left", ox=ox)

        # 6. Section Dimensions matching sample DXF 100%
        # Left inner: coverDay (50); Left outer chain: lotDay (100) | H (400) | caoTuDinhDaiDenMatGiang (650)
        sb.dim_v(rebar_bot_y, sec_bot_y, ox - half_b - 275.0, -half_b - lean_mc, str(int(round(cfg["coverDay"]))), text_side="left", rotate_text=True)
        if float(cfg["caoTuDinhDaiDenMatGiang"]) > 0 and cfg["giangMode"] != "none":
            sb.dim_v(sec_beam_top_y, sec_top_y, ox - half_b - 400.0, -half_b - lean_mc, str(int(round(cfg["caoTuDinhDaiDenMatGiang"]))), text_side="left", rotate_text=True)
        sb.dim_v(sec_top_y, sec_bot_y, ox - half_b - 400.0, -half_b - lean_mc, str(int(round(H))), text_side="left", rotate_text=True)
        if float(cfg["lotDay"]) > 0:
            sb.dim_v(sec_bot_y, lean_bot_y, ox - half_b - 400.0, -half_b - lean_mc, str(int(round(cfg["lotDay"]))), text_side="left", rotate_text=True)
        # Right vertical: hMep (200)
        sb.dim_v(sec_mep_y, sec_bot_y, ox + half_b + 175.0, half_b + lean_mc, str(int(round(h_mep))), text_side="right", rotate_text=True)

        # Bottom horizontal chains: inner [750 | 750] at +300; outer [50 | 1500 | 50] at +425
        mc_dim1 = lean_bot_y + 300.0
        mc_dim2 = lean_bot_y + 425.0
        left_span = col_cx - (-half_b)
        right_span = half_b - col_cx
        if left_span > 1.0:
            sb.dim_h(ox - half_b, ox + col_cx, mc_dim1, lean_bot_y, str(int(round(left_span))), text_above=True)
        if right_span > 1.0:
            sb.dim_h(ox + col_cx, ox + half_b, mc_dim1, lean_bot_y, str(int(round(right_span))), text_above=True)

        if lean_mc > 0:
            sb.dim_h(ox - half_b - lean_mc, ox - half_b, mc_dim2, lean_bot_y, str(int(round(lean_mc))), text_above=True)
        sb.dim_h(ox - half_b, ox + half_b, mc_dim2, lean_bot_y, str(int(round(B))), text_above=True)
        if lean_mc > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mc, mc_dim2, lean_bot_y, str(int(round(lean_mc))), text_above=True)

        sb.title_block(0, sec_title_y, "MC 1-1", "TL: 1/%d" % cfg["tiLe"], font_title=95.0 * sc, font_scale=50.0 * sc, ox=ox, underline_dxf=True)

    if view_mode == "sheet" and include_schedule:
        tbl_sc = max(0.85, min(1.2, (B + 1400.0) / 2980.0))
        tbl_w = 2980.0 * tbl_sc
        sb.draw_rebar_table(
            ox - tbl_w / 2.0,
            sec_title_y + 340.0,
            "BẢNG THỐNG KÊ THÉP - MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"]),
            comp.get("rebarSchedule"),
            by_diam=comp.get("rebarByDiameter"),
            scale=tbl_sc,
        )


# ==================== 2. MÓNG CỌC SCENE ====================

def _draw_pile_cap(sb, cfg, view_mode="sheet", ox=0.0, include_schedule=False):
    comp = compute_pile_cap(cfg)
    B = float(cfg["B"])
    L = float(cfg["L"])
    H = float(cfg["H"])
    half_b = B / 2.0
    half_l = L / 2.0
    lean_mb = float(cfg["lotChiaMatBang"])
    lean_mc = float(cfg["lotChiaMatCat"])
    sc = max(0.6, float(cfg.get("tiLe", 25)) / 25.0)

    col_cx = comp["colCx"]
    col_cy = -comp["colCy"]
    col_left = col_cx - float(cfg["cotB"]) / 2.0
    col_right = col_cx + float(cfg["cotB"]) / 2.0
    col_top = col_cy - float(cfg["cotH"]) / 2.0
    col_bot = col_cy + float(cfg["cotH"]) / 2.0

    # Sample DXF plan dim chain offsets: 225mm & 350mm from cap boundary (outside 100mm lean concrete)
    d_off1 = max(225.0, lean_mb + 125.0)
    d_off2 = d_off1 + 125.0
    top_dim1 = -half_l - d_off1
    top_dim2 = -half_l - d_off2
    bot_dim1 = half_l + d_off1
    bot_dim2 = half_l + d_off2
    left_dim1 = -half_b - d_off1
    left_dim2 = -half_b - d_off2
    right_dim1 = half_b + d_off1
    right_dim2 = half_b + d_off2
    plan_title_y = bot_dim2 + 250.0 * sc

    sec_origin_y = 350.0 if view_mode == "section" else (plan_title_y + 2050.0)
    sec_bot_y = sec_origin_y
    sec_top_y = sec_bot_y - H
    sec_col_top_y = sec_top_y - float(cfg["chieuCaoCotVeThem"])
    lean_bot_y = sec_bot_y + float(cfg["lotDay"])
    pile_bot_y = lean_bot_y + float(cfg["cocVeThem"])
    pile_head_y = sec_bot_y - float(cfg["ngamCoc"])
    sec_title_y = lean_bot_y + 625.0

    # Invisible Defpoints sheet bounding box (matches sample DXF; no outer white box)
    frame_left = min(-half_b - 1150.0, -1420.0 * sc)
    frame_right = max(half_b + 1050.0, 1420.0 * sc)
    frame_top = (sec_col_top_y - 250.0) if view_mode == "section" else (top_dim2 - 150.0)
    frame_bot = (plan_title_y + 220.0) if view_mode == "plan" else (sec_title_y + 220.0)
    sb.rect(ox + frame_left, frame_top, frame_right - frame_left, frame_bot - frame_top, stroke=None, fill=None, width=0.0, layer="Defpoints")

    unique_xs = []
    for x in sorted(p["x"] for p in comp["piles"]):
        if not unique_xs or abs(x - unique_xs[-1]) >= 25:
            unique_xs.append(x)
    unique_ys = []
    for y in sorted(-p["y"] for p in comp["piles"]):
        if not unique_ys or abs(y - unique_ys[-1]) >= 25:
            unique_ys.append(y)

    if view_mode in ("sheet", "plan"):
        # 1. Lean concrete perimeter & AR-CONC ring hatch (4 sides around cap, matching sample DXF)
        if float(cfg["lotDay"]) > 0 and lean_mb > 0 and sb.layers.get("DCE_Hatch", True):
            if comp["isPolygonal"]:
                lean_p = offset_polygon(comp["outlinePolygon"], lean_mb)
                lean_pts = _poly_svg_pts(lean_p, ox)
                pad_pts = _poly_svg_pts(comp["outlinePolygon"], ox)
                sb.hatch_concrete(lean_pts, hole_pts=pad_pts, scale=15.0 * sc, pattern="AR-CONC")
                sb.polygon(lean_pts, stroke=CAD["hatch"], fill=None, width=3.2, layer="DCE_Hatch")
            else:
                lean_pts = [
                    (-half_b - lean_mb, -half_l - lean_mb),
                    (half_b + lean_mb, -half_l - lean_mb),
                    (half_b + lean_mb, half_l + lean_mb),
                    (-half_b - lean_mb, half_l + lean_mb),
                ]
                pad_pts = [
                    (-half_b, -half_l),
                    (half_b, -half_l),
                    (half_b, half_l),
                    (-half_b, half_l),
                ]
                sb.hatch_concrete(lean_pts, hole_pts=pad_pts, ox=ox, scale=15.0 * sc, pattern="AR-CONC")
                sb.rect(ox - half_b - lean_mb, -half_l - lean_mb, B + 2 * lean_mb, L + 2 * lean_mb, stroke=CAD["hatch"], fill=None, width=3.2, layer="DCE_Hatch")

        # 2. Pile cap concrete outline & *U13 concrete-hatched columns (no magenta X-cross)
        if sb.layers.get("DCE_BaoBeTong", True):
            if comp["isPolygonal"]:
                sb.polygon(_poly_svg_pts(comp["outlinePolygon"], ox), stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            else:
                sb.rect(ox - half_b, -half_l, B, L, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
            for col in comp["allColumns"]:
                cl = ox + col["x"] - col["b"] / 2.0
                ct = -col["y"] - col["h"] / 2.0
                cw_c = float(col["b"])
                ch_c = float(col["h"])
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_concrete([(cl, ct), (cl + cw_c, ct), (cl + cw_c, ct + ch_c), (cl, ct + ch_c)], scale=6.0 * sc, pattern="AR-CONC")
                sb.rect(cl, ct, cw_c, ch_c, stroke="#CBD5E1", fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 3. Pile plan blocks (*U12: 2 diagonal solid quadrants + crosshair 1.67*R)
        if sb.layers.get("DCE_Block", True):
            for pile in comp["piles"]:
                px, py = ox + pile["x"], -pile["y"]
                pd = float(pile.get("d") or cfg["cocD"])
                r = pd / 2.0
                ext = round(r * 0.667)
                if cfg["cocHinh"] == "square":
                    # Opposite diagonal solid quadrants
                    sb.polygon([(px, py), (px + r, py), (px + r, py - r), (px, py - r)], stroke=None, fill="#A16207", width=0.0, layer="DCE_Block")
                    sb.polygon([(px, py), (px - r, py), (px - r, py + r), (px, py + r)], stroke=None, fill="#A16207", width=0.0, layer="DCE_Block")
                    sb.rect(px - r, py - r, pd, pd, stroke=CAD["pileYellow"], fill=None, width=4.0, layer="DCE_Block")
                else:
                    r_in = r * 0.76
                    d_ang = r_in * 0.7071
                    sb.polygon([(px, py), (px + r_in, py), (px + d_ang, py - d_ang), (px, py - r_in)], stroke=None, fill="#A16207", width=0.0, layer="DCE_Block")
                    sb.polygon([(px, py), (px - r_in, py), (px - d_ang, py + d_ang), (px, py + r_in)], stroke=None, fill="#A16207", width=0.0, layer="DCE_Block")
                    sb.circle(px, py, r, stroke=CAD["pileYellow"], fill=None, width=4.0, layer="DCE_Block")
                    sb.circle(px, py, r_in, stroke=CAD["pileYellow"], fill=None, width=2.4, layer="DCE_Block")
                sb.line(px - r - ext, py, px + r + ext, py, CAD["pileYellow"], 2.8, "DCE_Block")
                sb.line(px, py - r - ext, px, py + r + ext, CAD["pileYellow"], 2.8, "DCE_Block")

        # 4. Plan U-bars T1, B1, T2, B2 + *U10 callouts directly on bars (no crooked leaders)
        if sb.layers.get("DCE_ThepChu", True):
            bar_c = max(45.0, float(cfg["coverCanh"]))
            top_y = -half_l + bar_c + 25.0
            bot_y = half_l - bar_c - 25.0
            left_x = -half_b + bar_c + 50.0
            right_x = half_b - bar_c - 50.0
            hk = min(200.0, min(B, L) * 0.15)

            t1_s, t1_e = -half_b + 25.0, half_b - 75.0
            b1_s, b1_e = -half_b + 75.0, half_b - 25.0
            t2_s, t2_e = -half_l + 25.0, half_l - 75.0
            b2_s, b2_e = -half_l + 75.0, half_l - 25.0
            if comp["isPolygonal"]:
                inner_p = offset_polygon(comp["outlinePolygon"], -max(25.0, bar_c))
                if len(inner_p) >= 3:
                    for seg_s, seg_e in clip_line_to_poly(inner_p, "x", -top_y):
                        t1_s, t1_e = seg_s, seg_e
                        break
                    for seg_s, seg_e in clip_line_to_poly(inner_p, "x", -bot_y):
                        b1_s, b1_e = seg_s, seg_e
                        break
                    for seg_s, seg_e in clip_line_to_poly(inner_p, "y", left_x):
                        t2_s, t2_e = -seg_e, -seg_s
                        break
                    for seg_s, seg_e in clip_line_to_poly(inner_p, "y", right_x):
                        b2_s, b2_e = -seg_e, -seg_s
                        break

            # Horizontal top T1 & bottom B1 bars with staggered U-hooks
            sb.polyline([(ox + t1_s, top_y + hk), (ox + t1_s, top_y), (ox + t1_e, top_y), (ox + t1_e, top_y + hk)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + b1_s, bot_y - hk), (ox + b1_s, bot_y), (ox + b1_e, bot_y), (ox + b1_e, bot_y - hk)], CAD["rebar"], 6.0, "DCE_ThepChu")
            # Vertical left T2 & right B2 bars with staggered U-hooks
            sb.polyline([(ox + left_x + hk, t2_s), (ox + left_x, t2_s), (ox + left_x, t2_e), (ox + left_x + hk, t2_e)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + right_x - hk, b2_s), (ox + right_x, b2_s), (ox + right_x, b2_e), (ox + right_x - hk, b2_e)], CAD["rebar"], 6.0, "DCE_ThepChu")

            r_c = 62.5 * sc
            fs_c = 50.0 * sc
            # T1 callout along top bar (above col/below top edge without hitting col)
            t1_cx = max(t1_s + r_c + 40.0, min(t1_e - 360.0 * sc, -half_b * 0.42))
            t1_cy = top_y + 75.0 * sc
            sb.plan_callout(t1_cx, t1_cy, "T1", "Ø%da%d" % (cfg["thepTrenX"]["d"], cfg["thepTrenX"]["a"]), r=r_c, font_size=fs_c, ox=ox)

            # B1 callout along bottom bar
            b1_cx = max(b1_s + r_c + 40.0, min(b1_e - 360.0 * sc, -60.0 * sc))
            b1_cy = bot_y - 75.0 * sc
            sb.plan_callout(b1_cx, b1_cy, "B1", "Ø%da%d" % (cfg["thepDuoiX"]["d"], cfg["thepDuoiX"]["a"]), r=r_c, font_size=fs_c, ox=ox)

            # T2 callout rotated -90 along left vertical bar
            t2_cx = left_x + 75.0 * sc
            t2_cy = max(t2_s + 360.0 * sc, min(t2_e - r_c - 40.0, 140.0 * sc))
            sb.plan_callout(t2_cx, t2_cy, "T2", "Ø%da%d" % (cfg["thepTrenY"]["d"], cfg["thepTrenY"]["a"]), r=r_c, font_size=fs_c, ox=ox, rotate=-90.0)

            # B2 callout rotated -90 along right vertical bar
            b2_cx = right_x - 75.0 * sc
            b2_cy = max(b2_s + 360.0 * sc, min(b2_e - r_c - 40.0, 140.0 * sc))
            sb.plan_callout(b2_cx, b2_cy, "B2", "Ø%da%d" % (cfg["thepDuoiY"]["d"], cfg["thepDuoiY"]["a"]), r=r_c, font_size=fs_c, ox=ox, rotate=-90.0)

        # 5. Green filled section markers 1 - 1 (DCE_MatCatA)
        sb.section_marker(-half_b - lean_mb - 350.0, 0.0, "up", "1", size=46.0 * sc, line_len=135.0 * sc, ox=ox, label_side="bottom")
        sb.section_marker(half_b + lean_mb + 350.0, 0.0, "up", "1", size=46.0 * sc, line_len=135.0 * sc, ox=ox, label_side="bottom")

        # 6. Top Plan Dims: lean | dxLeft | cotB | dxRight | lean & B
        if lean_mb > 0:
            sb.dim_h(ox - half_b - lean_mb, ox - half_b, top_dim1, -half_l - lean_mb, str(int(round(lean_mb))), text_above=True)
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, top_dim1, -half_l, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, top_dim1, -half_l, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, top_dim1, -half_l, str(comp["dxRight"]), text_above=True)
        if lean_mb > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mb, top_dim1, -half_l - lean_mb, str(int(round(lean_mb))), text_above=True)
        sb.dim_h(ox - half_b, ox + half_b, top_dim2, -half_l, str(int(round(B))), text_above=True)

        # Bottom Plan Dims: lean | edge | pileSpacings | edge | lean & B
        if lean_mb > 0:
            sb.dim_h(ox - half_b - lean_mb, ox - half_b, bot_dim1, half_l + lean_mb, str(int(round(lean_mb))), text_above=False)
        if unique_xs:
            sb.dim_h(ox - half_b, ox + unique_xs[0], bot_dim1, half_l, str(int(round(unique_xs[0] - (-half_b)))), text_above=False)
            for k in range(len(unique_xs) - 1):
                sb.dim_h(ox + unique_xs[k], ox + unique_xs[k + 1], bot_dim1, half_l, str(int(round(unique_xs[k + 1] - unique_xs[k]))), text_above=False)
            sb.dim_h(ox + unique_xs[-1], ox + half_b, bot_dim1, half_l, str(int(round(half_b - unique_xs[-1]))), text_above=False)
        if lean_mb > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mb, bot_dim1, half_l + lean_mb, str(int(round(lean_mb))), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, bot_dim2, half_l, str(int(round(B))), text_above=False)

        # Left & Right Vertical Plan Dims (rotated text; outer = L of pile cap matching sample DXF)
        if unique_ys:
            if lean_mb > 0:
                sb.dim_v(-half_l - lean_mb, -half_l, ox + left_dim1, -half_b - lean_mb, str(int(round(lean_mb))), text_side="left", rotate_text=True)
            sb.dim_v(-half_l, unique_ys[0], ox + left_dim1, -half_b, str(int(round(unique_ys[0] - (-half_l)))), text_side="left", rotate_text=True)
            for k in range(len(unique_ys) - 1):
                sb.dim_v(unique_ys[k], unique_ys[k + 1], ox + left_dim1, -half_b, str(int(round(unique_ys[k + 1] - unique_ys[k]))), text_side="left", rotate_text=True)
            sb.dim_v(unique_ys[-1], half_l, ox + left_dim1, -half_b, str(int(round(half_l - unique_ys[-1]))), text_side="left", rotate_text=True)
            if lean_mb > 0:
                sb.dim_v(half_l, half_l + lean_mb, ox + left_dim1, -half_b - lean_mb, str(int(round(lean_mb))), text_side="left", rotate_text=True)
        sb.dim_v(-half_l, half_l, ox + left_dim2, -half_b, str(int(round(L))), text_side="left", rotate_text=True)

        if unique_ys:
            if lean_mb > 0:
                sb.dim_v(-half_l - lean_mb, -half_l, ox + right_dim1, half_b + lean_mb, str(int(round(lean_mb))), text_side="right", rotate_text=True)
            sb.dim_v(-half_l, unique_ys[0], ox + right_dim1, half_b, str(int(round(unique_ys[0] - (-half_l)))), text_side="right", rotate_text=True)
            for k in range(len(unique_ys) - 1):
                sb.dim_v(unique_ys[k], unique_ys[k + 1], ox + right_dim1, half_b, str(int(round(unique_ys[k + 1] - unique_ys[k]))), text_side="right", rotate_text=True)
            sb.dim_v(unique_ys[-1], half_l, ox + right_dim1, half_b, str(int(round(half_l - unique_ys[-1]))), text_side="right", rotate_text=True)
            if lean_mb > 0:
                sb.dim_v(half_l, half_l + lean_mb, ox + right_dim1, half_b + lean_mb, str(int(round(lean_mb))), text_side="right", rotate_text=True)
        sb.dim_v(-half_l, half_l, ox + right_dim2, half_b, str(int(round(L))), text_side="right", rotate_text=True)

        sub_parts = []
        if comp["isPolygonal"]:
            sub_parts.append("%d ĐỈNH" % len(comp["outlinePolygon"]))
        title_str = "MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"])
        if sub_parts:
            title_str += " · " + " · ".join(sub_parts)
        sb.title_block(0, plan_title_y, title_str, "TL: 1/%d" % cfg["tiLe"], font_title=95.0 * sc, font_scale=50.0 * sc, ox=ox, underline_dxf=True)

    if view_mode in ("sheet", "section"):
        # 1. Green dashed center axis line through column centerline (Layer '3' DASHED)
        sb.line(ox + col_cx, sec_col_top_y, ox + col_cx, pile_bot_y + 340.0, CAD["axisGreen"], 2.8, layer="3", dash=(90, 45))

        # 2. Pile shafts + centerlines + zigzag + continuous U/V-flared anchor dowels
        coc_d = float(cfg["cocD"])
        for px in unique_xs:
            pl, pr = ox + px - coc_d / 2.0, ox + px + coc_d / 2.0
            sb.line(ox + px, pile_head_y, ox + px, pile_bot_y, CAD["axisGreen"], 2.6, layer="3", dash=(90, 45))
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.polyline([(pl, pile_bot_y), (pl, pile_head_y), (pr, pile_head_y), (pr, pile_bot_y)], CAD["concrete"], 4.0, "DCE_BaoBeTong")
                sb.zigzag_h(px - coc_d / 2.0 - 35.0, px + coc_d / 2.0 + 35.0, pile_bot_y, 35.0, 32.0, ox, layer="DCE_MCZiCZac")
            if sb.layers.get("DCE_ThepChu", True):
                rau_top = pile_head_y - float(cfg["rauCocCao"])
                u_half = max(35.0, coc_d * 0.25)
                flare = max(75.0, coc_d * 0.45)
                sb.polyline([
                    (ox + px - u_half - flare, rau_top),
                    (ox + px - u_half, pile_head_y),
                    (ox + px + u_half, pile_head_y),
                    (ox + px + u_half + flare, rau_top),
                ], CAD["rebar"], 5.2, "DCE_ThepChu")

        # 3. Pile cap + column neck concrete outline (open-top monolithic joint)
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.polyline([
                (ox + col_left, sec_col_top_y),
                (ox + col_left, sec_top_y),
                (ox - half_b, sec_top_y),
                (ox - half_b, sec_bot_y),
                (ox + half_b, sec_bot_y),
                (ox + half_b, sec_top_y),
                (ox + col_right, sec_top_y),
                (ox + col_right, sec_col_top_y),
            ], CAD["concrete"], 4.5, "DCE_BaoBeTong")
            sb.zigzag_h(col_left - 85.0, col_right + 85.0, sec_col_top_y, 35.0, 35.0, ox, layer="DCE_MCZiCZac")

        # 4. Lean concrete segmented cleanly around pile shafts (AR-CONC hatch + cyan outline)
        if float(cfg["lotDay"]) > 0:
            intervals = []
            cur_s = -half_b - lean_mc
            end_x = half_b + lean_mc
            for px in unique_xs:
                p_l = px - coc_d / 2.0
                p_r = px + coc_d / 2.0
                if p_l > cur_s + 5.0:
                    intervals.append((cur_s, p_l))
                cur_s = max(cur_s, p_r)
            if end_x > cur_s + 5.0:
                intervals.append((cur_s, end_x))
            for is_x, ie_x in intervals:
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_concrete([
                        (is_x, sec_bot_y),
                        (ie_x, sec_bot_y),
                        (ie_x, lean_bot_y),
                        (is_x, lean_bot_y),
                    ], ox=ox, scale=15.0 * sc, pattern="AR-CONC")
                if sb.layers.get("DCE_BaoBeTong", True):
                    sb.rect(ox + is_x, sec_bot_y, ie_x - is_x, float(cfg["lotDay"]), stroke=CAD["concrete"], fill=None, width=3.8, layer="DCE_BaoBeTong")

        # 5. Rebar cage + column starter dowels + side belt skin bars (2)
        r_l = -half_b + float(cfg["coverCanh"])
        r_r = half_b - float(cfg["coverCanh"])
        r_b = sec_bot_y - float(cfg["coverDay"])
        r_t = sec_top_y + float(cfg["coverTren"])
        moc_top = max(r_t + 50.0, r_b - float(cfg["mocDuoiLen"]))
        if sb.layers.get("DCE_ThepChu", True):
            # Bottom B1 U-bar & Top T1 inverted U-bar (legs reach r_b, inset 25mm)
            sb.polyline([(ox + r_l, moc_top), (ox + r_l, r_b), (ox + r_r, r_b), (ox + r_r, moc_top)], CAD["rebar"], 6.5, "DCE_ThepChu")
            sb.polyline([(ox + r_l + 25.0, r_b), (ox + r_l + 25.0, r_t), (ox + r_r - 25.0, r_t), (ox + r_r - 25.0, r_b)], CAD["rebar"], 6.5, "DCE_ThepChu")

            # Column starter L-dowels sitting at r_b - 60 + stirrups through cap & column neck
            d_ins = min(40.0, max(20.0, float(cfg["cotB"]) * 0.14))
            dl_x = col_left + d_ins
            dr_x = col_right - d_ins
            d_foot_y = r_b - 60.0
            chan_l = float(cfg.get("thepCotChanL", 300))
            sb.polyline([(ox + dl_x - chan_l, d_foot_y), (ox + dl_x, d_foot_y), (ox + dl_x, sec_col_top_y)], CAD["rebar"], 6.0, "DCE_ThepChu")
            sb.polyline([(ox + dr_x + chan_l, d_foot_y), (ox + dr_x, d_foot_y), (ox + dr_x, sec_col_top_y)], CAD["rebar"], 6.0, "DCE_ThepChu")
            if sb.layers.get("DCE_ThepDai", True):
                sy = d_foot_y - 50.0
                step_a = max(80.0, float(cfg.get("thepDaiA", 200)))
                while sy >= sec_col_top_y + 15.0:
                    sb.line(ox + dl_x, sy, ox + dr_x, sy, CAD["stirrup"], 4.5, "DCE_ThepDai")
                    sy -= step_a

            # Bottom & top rebar dots (B2, T2)
            dot_r_b = max(6.0, float(cfg["thepDuoiY"]["d"]) / 2.0)
            dot_r_t = max(6.0, float(cfg["thepTrenY"]["d"]) / 2.0)
            nb2 = max(2, min(28, comp["soThanhB2"]))
            b2_xs = [
                (r_l + 12.5) + (r_r - r_l - 25.0) * i / float(nb2 - 1)
                for i in range(nb2)
            ]
            for dx in b2_xs:
                sb.circle(ox + dx, r_b - 12.5, dot_r_b, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            nt2 = max(2, min(28, comp["soThanhT2"]))
            t2_xs = [
                (r_l + 37.5) + (r_r - r_l - 75.0) * i / float(nt2 - 1)
                for i in range(nt2)
            ]
            for dx in t2_xs:
                sb.circle(ox + dx, r_t + 12.5, dot_r_t, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Side belt / skin bars (2) at fractional depths on left & right walls
            n_vach = max(1, min(6, int(cfg.get("soTangThepVach", 3))))
            dot_r_v = max(6.0, float((cfg.get("thepVach") or {"d": 12})["d"]) / 2.0)
            v_last_y = (r_t + r_b) / 2.0
            for vi in range(n_vach):
                vy = r_t + (r_b - r_t) * (vi + 1) / float(n_vach + 1)
                v_last_y = vy
                sb.circle(ox + r_l + 12.5, vy, dot_r_v, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
                sb.circle(ox + r_r - 12.5, vy, dot_r_v, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Callouts *U2 (Left: T2, B2) & *U3 (Right: T1, 2, B1) with clean orthogonal LEADERs
            t2_pick_x = t2_xs[min(1, len(t2_xs) - 1)]
            b2_pick_x = b2_xs[min(1, len(b2_xs) - 1)]
            sb.callout_u12(
                -half_b - 225.0 * sc, sec_top_y - 112.5 * sc, "T2",
                "Ø%da%d" % (cfg["thepTrenY"]["d"], cfg["thepTrenY"]["a"]),
                [[(t2_pick_x, r_t + 12.5), (t2_pick_x, sec_top_y - 112.5 * sc), (-half_b - 225.0 * sc, sec_top_y - 112.5 * sc)]],
                circle_side="left", s=25.0 * sc, ox=ox,
            )
            sb.callout_u12(
                -half_b - 225.0 * sc, lean_bot_y + 112.5 * sc, "B2",
                "Ø%da%d" % (cfg["thepDuoiY"]["d"], cfg["thepDuoiY"]["a"]),
                [[(b2_pick_x, r_b - 12.5), (b2_pick_x, lean_bot_y + 112.5 * sc), (-half_b - 225.0 * sc, lean_bot_y + 112.5 * sc)]],
                circle_side="left", s=25.0 * sc, ox=ox,
            )
            t1_pick_x = r_r - 100.0
            b1_pick_x = r_r - 100.0
            sb.callout_u12(
                half_b + 237.5 * sc, sec_top_y - 125.0 * sc, "T1",
                "Ø%da%d" % (cfg["thepTrenX"]["d"], cfg["thepTrenX"]["a"]),
                [[(t1_pick_x, r_t), (t1_pick_x, sec_top_y - 125.0 * sc), (half_b + 237.5 * sc, sec_top_y - 125.0 * sc)]],
                circle_side="right", s=25.0 * sc, ox=ox,
            )
            vach_cfg = cfg.get("thepVach") or {"d": 12, "a": 200}
            sb.callout_u12(
                half_b + 237.5 * sc, v_last_y, "2",
                "Ø%da%d" % (vach_cfg["d"], vach_cfg["a"]),
                [[(r_r - 12.5, v_last_y), (half_b + 237.5 * sc, v_last_y)]],
                circle_side="right", s=25.0 * sc, ox=ox,
            )
            sb.callout_u12(
                half_b + 237.5 * sc, lean_bot_y + 125.0 * sc, "B1",
                "Ø%da%d" % (cfg["thepDuoiX"]["d"], cfg["thepDuoiX"]["a"]),
                [[(b1_pick_x, r_b), (b1_pick_x, lean_bot_y + 125.0 * sc), (half_b + 237.5 * sc, lean_bot_y + 125.0 * sc)]],
                circle_side="right", s=25.0 * sc, ox=ox,
            )

        # 6. Elevation flag on left cap surface (-0.500, clear of left vertical dims)
        sb.elevation_flag(-half_b - 450.0, sec_top_y, format_elevation(cfg["caoTrinhMatDai"]), scale=float(cfg["tiLe"]), side="left", ox=ox)

        # 7. Inner vertical hook dims (mocDuoiLen = 360) left & right
        sb.dim_v(moc_top, r_b, ox + r_l + 125.0, r_l, str(int(round(cfg["mocDuoiLen"]))), text_side="left", rotate_text=True)
        sb.dim_v(moc_top, r_b, ox + r_r - 125.0, r_r, str(int(round(cfg["mocDuoiLen"]))), text_side="right", rotate_text=True)

        # Left vertical dims: inner = ngamCoc (100); outer = H (900) & lotDay (100)
        sb.dim_v(pile_head_y, sec_bot_y, ox - half_b - 175.0, -half_b, str(int(round(cfg["ngamCoc"]))), text_side="left", rotate_text=True)
        sb.dim_v(sec_top_y, sec_bot_y, ox - half_b - 300.0, -half_b, str(int(round(H))), text_side="left", rotate_text=True)
        if float(cfg["lotDay"]) > 0:
            sb.dim_v(sec_bot_y, lean_bot_y, ox - half_b - 300.0, -half_b - lean_mc, str(int(round(cfg["lotDay"]))), text_side="left", rotate_text=True)

        # Top horizontal dims above column cut line: dxLeft | cotB | dxRight
        top_sec_dim_y = sec_col_top_y - 125.0
        if comp["dxLeft"] > 0:
            sb.dim_h(ox - half_b, ox + col_left, top_sec_dim_y, sec_col_top_y, str(comp["dxLeft"]), text_above=True)
        sb.dim_h(ox + col_left, ox + col_right, top_sec_dim_y, sec_col_top_y, str(int(round(cfg["cotB"]))), text_above=True)
        if comp["dxRight"] > 0:
            sb.dim_h(ox + col_right, ox + half_b, top_sec_dim_y, sec_col_top_y, str(comp["dxRight"]), text_above=True)

        # Bottom horizontal dims: lean_mc | edge | pile_spacings | edge | lean_mc & B
        mc_bot1 = lean_bot_y + 210.0
        mc_bot2 = lean_bot_y + 335.0
        if lean_mc > 0:
            sb.dim_h(ox - half_b - lean_mc, ox - half_b, mc_bot1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        if unique_xs:
            sb.dim_h(ox - half_b, ox + unique_xs[0], mc_bot1, sec_bot_y, str(int(round(unique_xs[0] - (-half_b)))), text_above=False)
            for k in range(len(unique_xs) - 1):
                sb.dim_h(ox + unique_xs[k], ox + unique_xs[k + 1], mc_bot1, sec_bot_y, str(int(round(unique_xs[k + 1] - unique_xs[k]))), text_above=False)
            sb.dim_h(ox + unique_xs[-1], ox + half_b, mc_bot1, sec_bot_y, str(int(round(half_b - unique_xs[-1]))), text_above=False)
        if lean_mc > 0:
            sb.dim_h(ox + half_b, ox + half_b + lean_mc, mc_bot1, lean_bot_y, str(int(round(lean_mc))), text_above=False)
        sb.dim_h(ox - half_b, ox + half_b, mc_bot2, sec_bot_y, str(int(round(B))), text_above=False)

        sb.title_block(0, sec_title_y, "MC 1-1", "TL: 1/%d" % cfg["tiLe"], font_title=95.0 * sc, font_scale=50.0 * sc, ox=ox, underline_dxf=True)

    if view_mode == "sheet" and include_schedule:
        tbl_sc = max(0.85, min(1.2, (B + 1600.0) / 2980.0))
        tbl_w = 2980.0 * tbl_sc
        sb.draw_rebar_table(
            ox - tbl_w / 2.0,
            sec_title_y + 340.0,
            "BẢNG THỐNG KÊ THÉP - ĐÀI CỌC %s (SL=%d)" % (cfg["ten"], cfg["soLuong"]),
            comp.get("rebarSchedule"),
            by_diam=comp.get("rebarByDiameter"),
            scale=tbl_sc,
        )


# ==================== 3. MÓNG BĂNG SCENE ====================

def _draw_strip_footing(sb, cfg, view_mode="sheet", ox=0.0, include_schedule=False):
    comp = compute_strip_footing(cfg)
    tong_l = float(comp["tongL"])
    H_dam = float(cfg["H_dam"])
    B_dam = float(cfg["B_dam"])
    lot_day = float(cfg["lotDay"])
    lot_chia = float(cfg["lotChia"])
    co_cot_h = max(120.0, float(cfg.get("chieuCaoCoCot", 250)))
    vai_mep = max(0.0, float(cfg.get("vaiMepDam", 50)))

    b_half = B_dam / 2.0
    canh_trai = max(0.0, float(cfg["canhTrai"]))
    canh_phai = max(0.0, float(cfg["canhPhai"]))
    left_edge = -b_half - canh_trai
    right_edge = b_half + canh_phai

    s_elev = max(30.0, float(cfg.get("tiLeMatDung", 50)))
    s_sec = max(15.0, float(cfg.get("tiLeMatCat", 25)))

    # Elevation coordinate frame (true 1:1 mm model units, top of beam y=0)
    y_top, y_bot = 0.0, H_dam
    y_col_top = -co_cot_h
    lean_bot = y_bot + lot_day
    top_dim_y = y_col_top - 500.0          # -750
    axis_dim1_y = lean_bot + 700.0         # +1400
    axis_dim2_y = lean_bot + 950.0         # +1650
    axis_sc = 60.0 * (s_elev / 50.0)
    elev_title_y = axis_dim2_y + 750.0     # +2400

    # Section coordinate frame (true 1:1 mm model units matching sample DXF)
    sec_ox = ox + (0.0 if view_mode == "section" else b_half)
    sec_oy = 0.0 if view_mode == "section" else (elev_title_y + 1150.0)

    if view_mode in ("sheet", "elevation"):
        # Invisible Defpoints frame matching MẪU MÓNG BĂNG.dxf
        sb.rect(ox - 860.0, top_dim_y - 600.0, tong_l + 1210.0, (elev_title_y + 400.0) - (top_dim_y - 600.0),
                stroke=None, fill=None, width=0.0, layer="Defpoints")

        # 1. Green dashed axis lines & Dce_KhTenTruc bubbles + dashed cross-beams on Layer '3'
        col_count = len(comp["colLayouts"])
        for ci, col in enumerate(comp["colLayouts"]):
            sb.line(ox + col["axisX"], y_col_top, ox + col["axisX"], axis_dim2_y, CAD["axisGreen"], 3.0, "3", dash=(120, 45))
            sb.axis_bubble(col["axisX"], axis_dim2_y, col["trucLabel"], s=axis_sc, ox=ox)
            # Dashed cross-beam rectangle inside beam elevation (Layer '3')
            cw = min(float(col.get("crossW") or min(col["bCot"], B_dam)), col["bCot"])
            if ci == 0 and col["trucAlign"] == "left":
                cb_x = col["xStart"]
            elif ci == col_count - 1 and col["trucAlign"] == "right":
                cb_x = col["xEnd"] - cw
            elif abs(cw - col["bCot"]) < 1.0:
                cb_x = col["xStart"]
            else:
                cb_x = col["axisX"] - cw / 2.0
            sb.rect(ox + cb_x, y_top, cw, H_dam, stroke=CAD["axisGreen"], fill=None, width=3.0, layer="3", dash=(90, 45))

        # 2. Lean concrete AR-CONC hatch & cyan outline
        if lot_day > 0:
            if sb.layers.get("DCE_Hatch", True):
                sb.hatch_concrete([
                    (-lot_chia, y_bot),
                    (tong_l + lot_chia, y_bot),
                    (tong_l + lot_chia, lean_bot),
                    (-lot_chia, lean_bot),
                ], ox=ox, scale=25.4 * (s_elev / 50.0), pattern="AR-CONC")
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(ox - lot_chia, y_bot, tong_l + 2 * lot_chia, lot_day, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 3. Beam spans, column stubs & cyan break zigzags (DCE_MCZiCZac)
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.line(ox, y_bot, ox + tong_l, y_bot, CAD["concrete"], 5.0, "DCE_BaoBeTong")
            sb.line(ox, y_bot, ox, y_col_top, CAD["concrete"], 5.0, "DCE_BaoBeTong")
            sb.line(ox + tong_l, y_bot, ox + tong_l, y_col_top, CAD["concrete"], 5.0, "DCE_BaoBeTong")
            for sp in comp["spanLayouts"]:
                sb.line(ox + sp["xStart"], y_top, ox + sp["xEnd"], y_top, CAD["concrete"], 5.0, "DCE_BaoBeTong")
            for ci, col in enumerate(comp["colLayouts"]):
                if ci > 0:
                    sb.line(ox + col["xStart"], y_top, ox + col["xStart"], y_col_top, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                if ci < col_count - 1:
                    sb.line(ox + col["xEnd"], y_top, ox + col["xEnd"], y_col_top, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.zigzag_h(col["xStart"] - 35.0, col["xEnd"] + 35.0, y_col_top, 35.0, 35.0, ox, layer="DCE_MCZiCZac")

        # 4. Longitudinal & stirrup rebar on elevation
        cover = float(cfg["cover"])
        rt_y, rb_y = y_top + cover, y_bot - cover
        rl_x, rr_x = cover, tong_l - cover
        rm_y = y_top + H_dam / 2.0
        n_gia = max(0, int(cfg.get("thepGiaCount", 0)))

        if sb.layers.get("DCE_ThepChu", True):
            hk_t = min(float(cfg["thepTrenMocLen"]), H_dam - 2.0 * cover - 40.0)
            hk_b = min(float(cfg["thepDuoiMocLen"]), H_dam - 2.0 * cover - 40.0)
            ch = 30.0
            # Top bar (1): chamfered corners + inward 20deg flared end hooks
            sb.polyline([
                (ox + rl_x + 24.0, rt_y + hk_t - 66.0),
                (ox + rl_x, rt_y + hk_t),
                (ox + rl_x, rt_y + ch),
                (ox + rl_x + ch, rt_y),
                (ox + rr_x - ch, rt_y),
                (ox + rr_x, rt_y + ch),
                (ox + rr_x, rt_y + hk_t),
                (ox + rr_x - 24.0, rt_y + hk_t - 66.0),
            ], CAD["rebar"], 7.5, "DCE_ThepChu")
            # Bottom bar (2): chamfered corners + inward flared end hooks
            sb.polyline([
                (ox + rl_x + 25.0 + 24.0, rb_y - hk_b + 66.0),
                (ox + rl_x + 25.0, rb_y - hk_b),
                (ox + rl_x + 25.0, rb_y - ch),
                (ox + rl_x + 25.0 + ch, rb_y),
                (ox + rr_x - 25.0 - ch, rb_y),
                (ox + rr_x - 25.0, rb_y - ch),
                (ox + rr_x - 25.0, rb_y - hk_b),
                (ox + rr_x - 25.0 - 24.0, rb_y - hk_b + 66.0),
            ], CAD["rebar"], 7.5, "DCE_ThepChu")
            # Wing longitudinal bar line (3) at bottom edge
            sb.line(ox + rl_x + 55.0, rb_y, ox + rr_x - 55.0, rb_y, CAD["rebar"], 6.0, "DCE_ThepChu")
            # Skin bars (4) at mid-depth only when thepGiaCount > 0
            if n_gia > 0:
                gx0 = rl_x + 180.0
                gx1 = rr_x - 180.0
                sb.polyline([
                    (ox + gx0 + 66.0, rm_y - 24.0),
                    (ox + gx0, rm_y),
                    (ox + gx1, rm_y),
                    (ox + gx1 - 66.0, rm_y - 24.0),
                ], CAD["rebar"], 6.5, "DCE_ThepChu")

        span_stirrups = {}
        if sb.layers.get("DCE_ThepDai", True):
            for idx, sp in enumerate(comp["spanLayouts"]):
                tx_list = []
                step_vis = max(220.0, min(380.0, sp["L_nhip"] / 10.0))
                cur_tx = sp["xStart"] + 80.0
                while cur_tx < sp["xEnd"] - 60.0:
                    sb.line(ox + cur_tx, rt_y, ox + cur_tx, rb_y, CAD["stirrup"], 4.8, "DCE_ThepDai")
                    tx_list.append(cur_tx)
                    cur_tx += step_vis
                if sp["xEnd"] - 80.0 > sp["xStart"] + 120.0 and (not tx_list or abs(tx_list[-1] - (sp["xEnd"] - 80.0)) > 100.0):
                    etx = sp["xEnd"] - 80.0
                    sb.line(ox + etx, rt_y, ox + etx, rb_y, CAD["stirrup"], 4.8, "DCE_ThepDai")
                    tx_list.append(etx)
                span_stirrups[idx] = tx_list

        # 5. Per-span Section markers DCE_MatCatA, clean Stirrup callout (5) without horizontal bar underline, and (1)/(2)/(4)
        for idx, sp in enumerate(comp["spanLayouts"]):
            mid_x = sp["midX"]
            # Top & bottom DCE_MatCatA 1-1 cut arrows clear of all dims & axis bubbles
            sb.section_marker(mid_x, top_dim_y - 380.0, "right", "1", size=s_elev, line_len=5.5 * s_elev, ox=ox, label_side="left")
            sb.section_marker(mid_x, axis_dim2_y + 350.0, "right", "1", size=s_elev, line_len=5.5 * s_elev, ox=ox, label_side="left")

            # Clean Stirrup callout (5): badge + angled leader straight to a vertical stirrup bar (no horizontal underline)
            if sb.layers.get("DCE_Block", True):
                u10_r = 2.4 * s_elev
                u10_cx = mid_x - 3.6 * s_elev
                u10_cy = top_dim_y + 3.4 * s_elev
                st_bars = span_stirrups.get(idx) or [mid_x]
                pick_st = min(st_bars, key=lambda x: abs(x - (mid_x - 1.5 * s_elev)))
                sb.line(ox + u10_cx, u10_cy + u10_r, ox + pick_st, rt_y + 60.0, CAD["dimLine"], 2.8, "DCE_Dim")
                sb.circle(ox + u10_cx, u10_cy, u10_r, stroke=CAD["calloutCircle"], fill=CAD["bg"], width=3.5, layer="DCE_Block")
                sb.text(ox + u10_cx, u10_cy + 0.1 * s_elev, "5", CAD["calloutNum"], 2.0 * s_elev, "middle", "DCE_Block", bold=True)
                sb.text(ox + u10_cx + u10_r + 0.45 * s_elev, u10_cy + 0.1 * s_elev, "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiA"]), CAD["dimText"], 2.0 * s_elev, "start", "DCE_Block", bold=True)

            # Callouts (1), (2), and optional (4)
            sh_w = min(375.0, max(220.0, sp["L_nhip"] * 0.28))
            y_c_top = y_top - 250.0
            y_c_bot = lean_bot + 350.0
            if idx % 2 == 0:
                sb.callout_u12(mid_x - sh_w, y_c_top, "1", "%dØ%d" % (cfg["thepTrenCount"], cfg["thepTrenD"]),
                               [[(mid_x, rt_y), (mid_x, y_c_top), (mid_x - sh_w, y_c_top)]], "left", s=s_elev, ox=ox)
                sb.callout_u12(mid_x - sh_w, y_c_bot, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                               [[(mid_x, rb_y), (mid_x, y_c_bot), (mid_x - sh_w, y_c_bot)]], "left", s=s_elev, ox=ox)
                if n_gia > 0:
                    g_pick = min(sp["xEnd"] - 250.0, mid_x + 200.0)
                    sb.callout_u12(g_pick + sh_w + 100.0, y_c_bot, "4", "%dØ%d" % (n_gia, cfg["thepGiaD"]),
                                   [[(g_pick, rm_y), (g_pick, y_c_bot), (g_pick + sh_w + 100.0, y_c_bot)]], "right", s=s_elev, ox=ox)
            else:
                sb.callout_u12(mid_x + sh_w, y_c_top, "1", "%dØ%d" % (cfg["thepTrenCount"], cfg["thepTrenD"]),
                               [[(mid_x, rt_y), (mid_x, y_c_top), (mid_x + sh_w, y_c_top)]], "right", s=s_elev, ox=ox)
                sb.callout_u12(mid_x + sh_w, y_c_bot, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                               [[(mid_x, rb_y), (mid_x, y_c_bot), (mid_x + sh_w, y_c_bot)]], "right", s=s_elev, ox=ox)
                if n_gia > 0:
                    g_pick = max(sp["xStart"] + 250.0, mid_x - 225.0)
                    sb.callout_u12(g_pick - sh_w - 100.0, y_c_bot, "4", "%dØ%d" % (n_gia, cfg["thepGiaD"]),
                                   [[(g_pick, rm_y), (g_pick, y_c_bot), (g_pick - sh_w - 100.0, y_c_bot)]], "left", s=s_elev, ox=ox)

        # 6. Elevation flag & Dimensions matching MẪU MÓNG BĂNG.dxf
        sb.elevation_flag(-100.0, y_top, format_elevation(cfg["caoTrinhTop"]), scale=s_elev, side="left", ox=ox)
        sb.dim_v(y_top, y_bot, ox - 350.0, 0.0, str(int(round(H_dam))), font_size=115.0, tick_size=40.0, overshoot=80.0, text_side="left", rotate_text=True)

        for idx, col in enumerate(comp["colLayouts"]):
            sb.dim_h(ox + col["xStart"], ox + col["xEnd"], top_dim_y, y_col_top, str(int(round(col["bCot"]))), font_size=110.0, tick_size=40.0, overshoot=80.0)
            if idx < len(comp["spanLayouts"]):
                sp = comp["spanLayouts"][idx]
                sb.dim_h(ox + sp["xStart"], ox + sp["xEnd"], top_dim_y, y_col_top, str(int(round(sp["L_nhip"]))), font_size=110.0, tick_size=40.0, overshoot=80.0)

        for idx, gap in enumerate(comp["axisGaps"]):
            sb.dim_h(ox + comp["colLayouts"][idx]["axisX"], ox + comp["colLayouts"][idx + 1]["axisX"], axis_dim1_y, lean_bot + 350.0, str(int(round(gap))), font_size=115.0, tick_size=40.0, overshoot=80.0)
        if len(comp["colLayouts"]) >= 2:
            sb.dim_h(ox + comp["colLayouts"][0]["axisX"], ox + comp["colLayouts"][-1]["axisX"], axis_dim2_y, lean_bot + 350.0, str(int(round(comp["axisTotalSpan"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)

        sb.title_block(tong_l / 2.0, elev_title_y, "MÓNG %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]),
                       "TL: 1/%d" % cfg["tiLeMatDung"], font_title=220.0, font_scale=115.0, ox=ox, underline_dxf=True)

    if view_mode in ("sheet", "section"):
        def sx(val):
            return sec_ox + val

        def sy(val):
            return sec_oy + val

        y_s_top, y_s_sh, y_s_mep, y_s_bot = 0.0, float(comp["hTren"]), H_dam - float(cfg["hMep"]), H_dam
        y_s_lean = y_s_bot + lot_day
        sh_l = min(vai_mep, canh_trai) if canh_trai > 0 else 0.0
        sh_r = min(vai_mep, canh_phai) if canh_phai > 0 else 0.0

        sec_dim1_x = min(-b_half - 475.0, left_edge - 175.0)
        sec_dim2_x = sec_dim1_x - 125.0
        sec_box_l = sec_dim2_x - 425.0
        sec_box_r = max(right_edge + 850.0, b_half + 1250.0)
        sec_box_t = y_s_top - 285.0
        sec_box_b = y_s_lean + 790.0
        sb.rect(sx(sec_box_l), sy(sec_box_t), sec_box_r - sec_box_l, sec_box_b - sec_box_t,
                stroke=None, fill=None, width=0.0, layer="Defpoints")

        # 1. Lean concrete in section (AR-CONC hatch + cyan outline)
        if lot_day > 0:
            if sb.layers.get("DCE_Hatch", True):
                sb.hatch_concrete([
                    (left_edge - lot_chia, y_s_bot),
                    (right_edge + lot_chia, y_s_bot),
                    (right_edge + lot_chia, y_s_lean),
                    (left_edge - lot_chia, y_s_lean),
                ], ox=sec_ox, oy=sec_oy, scale=25.4 * (s_sec / 25.0), pattern="AR-CONC")
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(sx(left_edge - lot_chia), sy(y_s_bot), comp["B_mong"] + 2 * lot_chia, lot_day, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 2. Beam + wings 10-point concrete section polygon
        pts = [(-b_half, y_s_top), (b_half, y_s_top)]
        if canh_phai > 0:
            pts.append((b_half, y_s_sh))
            if sh_r > 0:
                pts.append((b_half + sh_r, y_s_sh))
            pts.extend([(right_edge, y_s_mep), (right_edge, y_s_bot)])
        else:
            pts.append((b_half, y_s_bot))
        if canh_trai > 0:
            pts.extend([(left_edge, y_s_bot), (left_edge, y_s_mep)])
            if sh_l > 0:
                pts.append((-b_half - sh_l, y_s_sh))
            pts.append((-b_half, y_s_sh))
        else:
            pts.append((-b_half, y_s_bot))
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.polygon([(sx(px), sy(py)) for (px, py) in pts], stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")

        # 3. Stirrups (5) with chamfered corners + 135deg hooks, and optional C-tie (6) wrapping skin bars (4)
        cover = float(cfg["cover"])
        st_l, st_r, st_t, st_b = -b_half + cover, b_half - cover, y_s_top + cover, y_s_bot - cover
        mid_y = H_dam / 2.0
        n_gia_sec = max(0, int(cfg.get("thepGiaCount", 0)))
        ch = min(20.0, (st_r - st_l) * 0.15)
        if sb.layers.get("DCE_ThepDai", True):
            # Closed stirrup (5) with 135deg top-right hooks matching DXF [077]
            sb.polyline([
                (sx(st_r - ch - 45.0), sy(st_t + ch + 25.0)),
                (sx(st_r - ch), sy(st_t)),
                (sx(st_r), sy(st_t + ch)),
                (sx(st_r), sy(st_b - ch)),
                (sx(st_r - ch), sy(st_b)),
                (sx(st_l + ch), sy(st_b)),
                (sx(st_l), sy(st_b - ch)),
                (sx(st_l), sy(st_t + ch)),
                (sx(st_l + ch), sy(st_t)),
                (sx(st_r - ch), sy(st_t)),
                (sx(st_r), sy(st_t + ch)),
                (sx(st_r - 45.0), sy(st_t + ch + 45.0)),
            ], CAD["stirrup"], 5.0, "DCE_ThepDai")

            # C-tie (6) wrapping skin bars (4) at mid_y only when thepGiaCount > 0
            if n_gia_sec > 0:
                g_lx, g_rx = st_l + 20.0, st_r - 20.0
                ct_top, ct_bot = mid_y - 20.0, mid_y + 20.0
                sb.polyline([
                    (sx(g_lx + 64.0), sy(ct_top)),
                    (sx(g_lx), sy(ct_top)),
                    (sx(g_lx), sy(ct_bot)),
                    (sx(g_rx), sy(ct_bot)),
                    (sx(g_rx), sy(ct_top)),
                    (sx(g_rx - 64.0), sy(ct_top)),
                ], CAD["stirrup"], 4.5, "DCE_ThepDai")

        # 4. Rebar dots & wing bars
        nt = max(1, int(cfg["thepTrenCount"]))
        nb = max(1, int(cfg["thepDuoiCount"]))
        dot_ty = st_t + 20.0
        dot_by = st_b - 20.0
        top_xs = [((st_l + st_r) / 2.0) if nt == 1 else (st_l + 20.0 + (st_r - st_l - 40.0) * i / float(nt - 1)) for i in range(nt)]
        bot_xs = [((st_l + st_r) / 2.0) if nb == 1 else (st_l + 20.0 + (st_r - st_l - 40.0) * i / float(nb - 1)) for i in range(nb)]
        g_lx, g_rx = st_l + 20.0, st_r - 20.0

        wing_xs = []
        mb_l, mb_r, mb_y = left_edge + cover, right_edge - cover, y_s_bot - cover
        wing_dot_y = mb_y - 20.0
        n_wing = max(2, min(16, int(cfg.get("thepDocCanhCount", 6))))
        if canh_trai > 0 and canh_phai > 0:
            half_n = max(1, n_wing // 2)
            for wi in range(1, half_n + 1):
                wing_xs.append((st_l + 20.0) + ((mb_l + 20.0) - (st_l + 20.0)) * wi / float(half_n))
            wing_xs.sort()
            for wi in range(1, (n_wing - half_n) + 1):
                wing_xs.append((st_r - 20.0) + ((mb_r - 20.0) - (st_r - 20.0)) * wi / float(max(1, n_wing - half_n)))
        elif canh_phai > 0:
            for wi in range(1, n_wing + 1):
                wing_xs.append((st_r - 20.0) + ((mb_r - 20.0) - (st_r - 20.0)) * wi / float(n_wing))
        elif canh_trai > 0:
            for wi in range(1, n_wing + 1):
                wing_xs.append((st_l + 20.0) + ((mb_l + 20.0) - (st_l + 20.0)) * wi / float(n_wing))
            wing_xs.sort()

        if sb.layers.get("DCE_ThepChu", True):
            # Wing U-bar MB with 20mm chamfered bottom corners matching DXF [085] & [294]
            hk = max(40.0, float(cfg["thepNgangCanhHook"]))
            mb_ch = min(20.0, (mb_r - mb_l) * 0.1)
            sb.polyline([
                (sx(mb_l), sy(mb_y - mb_ch - hk)),
                (sx(mb_l), sy(mb_y - mb_ch)),
                (sx(mb_l + mb_ch), sy(mb_y)),
                (sx(mb_r - mb_ch), sy(mb_y)),
                (sx(mb_r), sy(mb_y - mb_ch)),
                (sx(mb_r), sy(mb_y - mb_ch - hk)),
            ], CAD["rebar"], 6.0, "DCE_ThepChu")

            r_top = max(7.5, float(cfg["thepTrenD"]) * 0.52)
            r_bot = max(7.5, float(cfg["thepDuoiD"]) * 0.52)
            r_gia = max(6.0, float(cfg["thepGiaD"]) * 0.52)
            r_wing = max(6.0, float(cfg.get("thepDocCanhD", 12)) * 0.52)

            for dx in top_xs:
                sb.circle(sx(dx), sy(dot_ty), r_top, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            for dx in bot_xs:
                sb.circle(sx(dx), sy(dot_by), r_bot, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            if n_gia_sec > 0:
                sb.circle(sx(g_lx), sy(mid_y), r_gia, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
                sb.circle(sx(g_rx), sy(mid_y), r_gia, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            for wx in wing_xs:
                sb.circle(sx(wx), sy(wing_dot_y), r_wing, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Left stacked callouts *U1: (1), (5), optional (4)/(6), (2) with multi-branch leaders matching DXF
            lx_tip = -b_half - 300.0
            y1_call = y_s_top - 75.0
            y2_call = y_s_lean + 125.0
            y5_call = st_t + 100.0
            y4_call = mid_y
            y6_call = mid_y + 125.0

            sb.callout_u12(lx_tip, y1_call, "1", "%dØ%d" % (cfg["thepTrenCount"], cfg["thepTrenD"]),
                           [[(dx, dot_ty), (dx, y1_call), (lx_tip, y1_call)] for dx in top_xs], "left", s=s_sec, ox=sec_ox, oy=sec_oy)
            sb.callout_u12(lx_tip, y5_call, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiA"]),
                           [[(st_l, y5_call), (lx_tip, y5_call)]], "left", s=s_sec, ox=sec_ox, oy=sec_oy)
            if n_gia_sec > 0:
                sb.callout_u12(lx_tip, y4_call, "4", "%dØ%d" % (n_gia_sec, cfg["thepGiaD"]),
                               [[(g_rx, mid_y), (lx_tip, y4_call)], [(g_lx, mid_y), (lx_tip, y4_call)]], "left", s=s_sec, ox=sec_ox, oy=sec_oy)
                sb.callout_u12(lx_tip, y6_call, "6", "Ø%da%d" % (cfg["thepDaiGiaD"], cfg["thepDaiGiaA"]),
                               [[(g_lx + (g_rx - g_lx) * 0.33, mid_y + 20.0), (g_lx + (g_rx - g_lx) * 0.33, y6_call), (lx_tip, y6_call)]],
                               "left", s=s_sec, ox=sec_ox, oy=sec_oy)
            sb.callout_u12(lx_tip, y2_call, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                           [[(dx, dot_by), (dx, y2_call), (lx_tip, y2_call)] for dx in bot_xs], "left", s=s_sec, ox=sec_ox, oy=sec_oy)

            # Right wing callouts *U2: (3) & (MB) matching DXF
            rx_tip = right_edge + 275.0
            if wing_xs:
                sb.callout_u12(rx_tip, y2_call, "3", "%dØ%d" % (cfg["thepDocCanhCount"], cfg["thepDocCanhD"]),
                               [[(wing_xs[-1], wing_dot_y), (wing_xs[-1], y2_call), (rx_tip, y2_call)]],
                               "right", s=s_sec, ox=sec_ox, oy=sec_oy)
            y_mb_call = y_s_bot - 100.0
            sb.callout_u12(rx_tip, y_mb_call, "MB", "Ø%da%d" % (cfg["thepNgangCanhD"], cfg["thepNgangCanhA"]),
                           [[(mb_r, y_mb_call), (rx_tip, y_mb_call)]],
                           "right", s=s_sec, ox=sec_ox, oy=sec_oy)

        # 5. Elevation flag on top-right of beam stem & Dimensions (rotated left vertical dims + bottom chain)
        sb.elevation_flag(b_half + 10.0, y_s_top, format_elevation(cfg["caoTrinhTop"]), scale=s_sec, side="right", ox=sec_ox, oy=sec_oy)

        if comp["hTren"] > 0:
            sb.dim_v(sy(y_s_top), sy(y_s_sh), sx(sec_dim1_x), sx(-b_half), str(int(round(comp["hTren"]))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_side="left", rotate_text=True)
        if float(cfg["hVat"]) > 0:
            sb.dim_v(sy(y_s_sh), sy(y_s_mep), sx(sec_dim1_x), sx(left_edge), str(int(round(cfg["hVat"]))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_side="left", rotate_text=True)
        sb.dim_v(sy(y_s_mep), sy(y_s_bot), sx(sec_dim1_x), sx(left_edge), str(int(round(cfg["hMep"]))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_side="left", rotate_text=True)

        sb.dim_v(sy(y_s_top), sy(y_s_bot), sx(sec_dim2_x), sx(-b_half), str(int(round(H_dam))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_side="left", rotate_text=True)
        if lot_day > 0:
            sb.dim_v(sy(y_s_bot), sy(y_s_lean), sx(sec_dim2_x), sx(left_edge - lot_chia), str(int(round(lot_day))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_side="left", rotate_text=True)

        # Bottom single dim chain: lotChia | [canhTrai] | B_dam | [canhPhai] | lotChia
        y_bd1 = sy(y_s_lean + 300.0)
        if lot_chia > 0:
            sb.dim_h(sx(left_edge - lot_chia), sx(left_edge), y_bd1, sy(y_s_lean), str(int(round(lot_chia))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_above=True)
        if canh_trai > 0:
            sb.dim_h(sx(left_edge), sx(-b_half), y_bd1, sy(y_s_bot), str(int(round(canh_trai))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_above=True)
        sb.dim_h(sx(-b_half), sx(b_half), y_bd1, sy(y_s_bot), str(int(round(B_dam))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_above=True)
        if canh_phai > 0:
            sb.dim_h(sx(b_half), sx(right_edge), y_bd1, sy(y_s_bot), str(int(round(canh_phai))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_above=True)
        if lot_chia > 0:
            sb.dim_h(sx(right_edge), sx(right_edge + lot_chia), y_bd1, sy(y_s_lean), str(int(round(lot_chia))), font_size=50.0, tick_size=18.0, overshoot=30.0, text_above=True)

        sb.title_block(sx(0.0), sy(y_s_lean + 525.0), "MÓNG %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]),
                       "MC 1-1 (TỶ LỆ: 1/%d)" % cfg["tiLeMatCat"], font_title=110.0, font_scale=60.0, underline_dxf=True, underline_scale_dxf=True)

    if view_mode == "sheet" and include_schedule:
        tbl_sc = max(1.05, min(1.5, max(1.05, tong_l / 8200.0)))
        tbl_x = sec_ox + sec_box_r + 420.0
        tbl_y = sec_oy + sec_box_t
        sb.draw_rebar_table(
            tbl_x,
            tbl_y,
            "BẢNG THỐNG KÊ THÉP - MÓNG BĂNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"]),
            comp.get("rebarSchedule"),
            by_diam=comp.get("rebarByDiameter"),
            scale=tbl_sc,
        )


# ==================== 4. DẦM MÓNG SCENE ====================

def _draw_foundation_beam(sb, cfg, view_mode="sheet", ox=0.0, include_schedule=False):
    comp = compute_foundation_beam(cfg)
    tong_l = float(comp["tongL"])
    H_dam = float(cfg["H_dam"])
    B_dam = float(cfg["B_dam"])
    lot_day = float(cfg["lotDay"])
    lot_chia = float(cfg["lotChiaMatCat"])
    sup_top_ext = float(cfg.get("supportTopExt", 500))

    min_dai_top = min([0.0] + [float(s.get("daiTopOffset", 0.0)) for s in comp["supportSegments"]])
    max_dai_bot = max([H_dam] + [float(s.get("daiTopOffset", 0.0)) + float(s.get("daiH", H_dam)) for s in comp["supportSegments"]])

    elev_l, elev_r = -980.0, tong_l + 460.0
    elev_t = min(0.0, min_dai_top) - sup_top_ext - 780.0
    elev_b = max(H_dam + lot_day, max_dai_bot + lot_day) + 1680.0

    b_half = B_dam / 2.0
    lean_half = b_half + lot_chia
    sec_l = -max(lean_half + 640.0, b_half + 760.0) - 540.0
    sec_r = max(lean_half + 520.0, b_half + 860.0)
    sec_t, sec_b = -380.0, H_dam + lot_day + 680.0

    sec_s = 1.0 if view_mode == "section" else 1.85
    sec_ox = ox + (0.0 if view_mode == "section" else (elev_l - sec_l * sec_s))
    sec_oy = 0.0 if view_mode == "section" else (elev_b + 380.0 - sec_t * sec_s)

    if view_mode in ("sheet", "elevation"):
        sb.rect(ox + elev_l, elev_t, elev_r - elev_l, elev_b - elev_t, stroke=None, fill=None, width=0.0, layer="Defpoints")
        y_top, y_bot = 0.0, H_dam
        y_col_top = min(0.0, min_dai_top) - sup_top_ext
        lean_bot_beam = y_bot + lot_day
        bot_start = max(lean_bot_beam, max_dai_bot + lot_day)
        top_dim_y = y_col_top - 420.0
        axis_dim1_y = bot_start + 380.0
        axis_dim2_y = bot_start + 640.0
        s_elev = max(36.0, float(cfg.get("tiLeMatDung", 50)))
        axis_sc = 56.0 * (s_elev / 50.0)
        axis_c_y = bot_start + 920.0
        elev_title_y = axis_c_y + 620.0

        # 1. All Revit Grid axis lines (supports + mid-span extraGrids) & Dce_KhTenTruc axis bubbles
        grid_lines = comp.get("gridLines") or [
            {"label": s["trucLabel"], "x": s["axisX"], "kind": "support"} for s in comp["supportSegments"]
        ]
        for gl in grid_lines:
            sb.line(ox + gl["x"], y_col_top - 80.0, ox + gl["x"], axis_c_y, CAD["axisGreen"], 3.0, "3", dash=(120, 45))
            sb.axis_bubble(gl["x"], axis_c_y, gl["label"], s=axis_sc, ox=ox)

        # 2. Lean concrete under spans & under support pads
        if lot_day > 0:
            for sp in comp["spanSegments"]:
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_concrete([
                        (sp["xStart"], y_bot),
                        (sp["xEnd"], y_bot),
                        (sp["xEnd"], y_bot + lot_day),
                        (sp["xStart"], y_bot + lot_day),
                    ], ox=ox, scale=25.4 * (s_elev / 50.0), pattern="AR-CONC")
                if sb.layers.get("DCE_BaoBeTong", True):
                    sb.rect(ox + sp["xStart"], y_bot, sp["L_thongThuy"], lot_day, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")
            for si, sup in enumerate(comp["supportSegments"]):
                y_dbot = float(sup.get("daiTopOffset", 0.0)) + float(sup.get("daiH", H_dam))
                pad_ext = lot_chia if (si == 0 or si == len(comp["supportSegments"]) - 1) else 0.0
                sx_l = sup["xStart"] - (pad_ext if si == 0 else 0.0)
                sx_r = sup["xEnd"] + (pad_ext if si == len(comp["supportSegments"]) - 1 else 0.0)
                if sb.layers.get("DCE_Hatch", True):
                    sb.hatch_concrete([
                        (sx_l, y_dbot),
                        (sx_r, y_dbot),
                        (sx_r, y_dbot + lot_day),
                        (sx_l, y_dbot + lot_day),
                    ], ox=ox, scale=25.4 * (s_elev / 50.0), pattern="AR-CONC")
                if sb.layers.get("DCE_BaoBeTong", True):
                    sb.rect(ox + sx_l, y_dbot, sx_r - sx_l, lot_day, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")

        # 3. Continuous beam concrete outline + Đài Móng pads (going down/true height) + Column stubs (going UP)
        if sb.layers.get("DCE_BaoBeTong", True):
            # Beam spans top & bottom lines
            sb.rect(ox, y_top, tong_l, H_dam, stroke=CAD["concrete"], fill=None, width=5.0, layer="DCE_BaoBeTong")
            for sup in comp["supportSegments"]:
                y_dtop = float(sup.get("daiTopOffset", 0.0))
                y_dbot = y_dtop + float(sup.get("daiH", H_dam))
                sup_l = sup["supportLen"]
                col_w = min(sup_l, max(120.0, float(sup.get("colW", 300.0))))
                col_cx = float(sup.get("colCenterX", sup["axisX"]))
                col_l = max(sup["xStart"], min(sup["xEnd"] - col_w, col_cx - col_w / 2.0))
                col_r = col_l + col_w
                y_col_base = min(y_top, y_dtop)

                # Draw Đài Móng / support pad outline when it differs from beam or is wider than column
                if y_dbot > y_bot + 5.0 or y_dtop < y_top - 5.0 or y_dtop > y_top + 5.0 or sup_l > col_w + 10.0:
                    sb.rect(ox + sup["xStart"], y_dtop, sup_l, y_dbot - y_dtop, stroke=CAD["concrete"], fill=None, width=4.8, layer="DCE_BaoBeTong")

                # Column rising UP from pad/beam top with zigzag break + green dashed core through beam depth
                sb.line(ox + col_l, y_col_base, ox + col_l, y_col_top, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.line(ox + col_r, y_col_base, ox + col_r, y_col_top, CAD["concrete"], 4.5, "DCE_BaoBeTong")
                sb.zigzag_h(col_l - 40.0, col_r + 40.0, y_col_top, 42.0, 35.0, ox, layer="DCE_MCZiCZac")
                sb.rect(ox + col_l, y_col_base, col_w, max(100.0, y_bot - y_col_base), stroke=CAD["axisGreen"], fill=None, width=3.0, layer="3", dash=(90, 45))

            for sp in comp["spanSegments"]:
                if sp.get("hasMidCrossBeam"):
                    mcw = float(sp.get("midCrossW", 300.0))
                    mch = min(H_dam * 0.55, float(sp.get("midCrossH", 300.0)))
                    mx0 = (sp["xStart"] + sp["xEnd"]) / 2.0 - mcw / 2.0
                    sb.rect(ox + mx0, y_top, mcw, mch, stroke=CAD["axisGreen"], fill=None, width=3.2, layer="3", dash=(90, 45))

        cover = float(cfg["cover"])
        rt1_y = y_top + cover
        rt2_y = rt1_y + max(42.0, cfg["thepTren1D"] * 2.5)
        rb_y = y_bot - cover
        rm_y = y_top + H_dam / 2.0
        n_tren2 = max(0, int(cfg.get("thepTren2Count", 0)))
        n_gia = max(0, int(cfg.get("thepGiaCount", 0)))
        if sb.layers.get("DCE_ThepChu", True):
            hk1 = min(float(cfg["thepTren1Moc"]), H_dam - 150.0)
            hk2 = min(float(cfg["thepTren2Moc"]), H_dam - 180.0)
            hkb = min(float(cfg["thepDuoiMoc"]), H_dam - 150.0)
            sb.polyline([(ox + cover, rt1_y + hk1), (ox + cover, rt1_y), (ox + tong_l - cover, rt1_y), (ox + tong_l - cover, rt1_y + hk1)], CAD["rebar"], 8.0, "DCE_ThepChu")
            if n_tren2 > 0:
                sb.polyline([(ox + cover + 30, rt2_y + hk2), (ox + cover + 30, rt2_y), (ox + tong_l - cover - 30, rt2_y), (ox + tong_l - cover - 30, rt2_y + hk2)], CAD["rebar"], 7.0, "DCE_ThepChu")
            sb.polyline([(ox + cover + 16, rb_y - hkb), (ox + cover + 16, rb_y), (ox + tong_l - cover - 16, rb_y), (ox + tong_l - cover - 16, rb_y - hkb)], CAD["rebar"], 8.0, "DCE_ThepChu")
            if n_gia > 0:
                gia_s = comp["spanSegments"][0]["xStart"] if comp["spanSegments"] else 0.0
                gia_e = comp["spanSegments"][-1]["xEnd"] if comp["spanSegments"] else tong_l
                sb.line(ox + max(cover + 60, gia_s - cfg["thepGiaNeoGoi"]), rm_y, ox + min(tong_l - cover - 60, gia_e + cfg["thepGiaNeoGoi"]), rm_y, CAD["rebar"], 6.5, "DCE_ThepChu")

        # Dense stirrup ticks in support zones + sparser ticks in midspan
        if sb.layers.get("DCE_ThepDai", True):
            for sp in comp["spanSegments"]:
                vgl = float(sp["vungGoiLen"])
                tx_list = [
                    sp["xStart"] + 60, sp["xStart"] + vgl * 0.35, sp["xStart"] + vgl * 0.7, sp["xStart"] + vgl,
                    (sp["xStart"] + sp["xEnd"]) / 2.0 - 220, (sp["xStart"] + sp["xEnd"]) / 2.0 + 220,
                    sp["xEnd"] - vgl, sp["xEnd"] - vgl * 0.7, sp["xEnd"] - vgl * 0.35, sp["xEnd"] - 60,
                ]
                for tx in tx_list:
                    if sp["xStart"] + 20 < tx < sp["xEnd"] - 20:
                        sb.line(ox + tx, rt1_y, ox + tx, rb_y, CAD["stirrup"], 4.8, "DCE_ThepDai")

        # Callouts on Elevation (5, 1, 3, 2, 4 + section 1-1 markers)
        y_call_bot = max(lean_bot_beam, max_dai_bot + lot_day) + 190.0
        for sp in comp["spanSegments"]:
            mid_x = (sp["xStart"] + sp["xEnd"]) / 2.0
            vgl = float(sp["vungGoiLen"])
            sb.section_marker(mid_x, y_col_top - 180.0, "right", "1", size=s_elev, line_len=5.0 * s_elev, ox=ox, label_side="left")
            sb.section_marker(mid_x, axis_c_y - 120.0, "right", "1", size=s_elev, line_len=5.0 * s_elev, ox=ox, label_side="left")
            if vgl >= 250.0:
                sb.callout(sp["xStart"] + vgl * 0.5, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"]),
                           [(sp["xStart"] + vgl * 0.5, y_top - 380.0), (sp["xStart"] + vgl * 0.5, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
                sb.callout(sp["xEnd"] - vgl * 0.5, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"]),
                           [(sp["xEnd"] - vgl * 0.5, y_top - 380.0), (sp["xEnd"] - vgl * 0.5, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            sb.callout(mid_x - 80.0, y_top - 480.0, "5", "Ø%da%d" % (cfg["thepDaiD"], cfg["thepDaiANhip"]),
                       [(mid_x, y_top - 380.0), (mid_x, rt1_y + 120.0)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)

            # Stacked top (1) & optional (3)
            sb.callout(mid_x - 320.0, y_top - 220.0, "1", "%dØ%d" % (cfg["thepTren1Count"], cfg["thepTren1D"]),
                       [(mid_x - 200.0, y_top - 220.0), (mid_x + 40.0, y_top - 220.0), (mid_x + 40.0, rt1_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            if n_tren2 > 0:
                sb.callout(mid_x - 320.0, y_top - 70.0, "3", "%dØ%d" % (n_tren2, cfg["thepTren2D"]),
                           [(mid_x - 200.0, y_top - 70.0), (mid_x - 10.0, y_top - 70.0), (mid_x - 10.0, rt2_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            # Bottom (2) & optional skin (4)
            sb.callout(mid_x - 280.0, y_call_bot, "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(mid_x - 180.0, y_call_bot), (mid_x - 20.0, y_call_bot), (mid_x - 20.0, rb_y)], "left", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)
            if n_gia > 0:
                sb.callout(mid_x + 280.0, y_call_bot, "4", "%dØ%d" % (n_gia, cfg["thepGiaD"]),
                           [(mid_x + 180.0, y_call_bot), (mid_x + 40.0, y_call_bot), (mid_x + 40.0, rm_y)], "right", r=1.9 * s_elev, font_size=1.7 * s_elev, ox=ox)

        # Top dimensions split into support + 3 span zones (vungGoi | vungNhip | vungGoi)
        for idx, sup in enumerate(comp["supportSegments"]):
            y_dtop = float(sup.get("daiTopOffset", 0.0))
            sb.dim_h(ox + sup["xStart"], ox + sup["xEnd"], top_dim_y, min(y_top, y_dtop), str(int(round(sup["supportLen"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
            if idx < len(comp["spanSegments"]):
                sp = comp["spanSegments"][idx]
                vgl = sp["vungGoiLen"]
                if vgl > 50 and sp["vungNhipLen"] > 50:
                    sb.dim_h(ox + sp["xStart"], ox + sp["xStart"] + vgl, top_dim_y, y_top, str(int(round(vgl))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                    sb.dim_h(ox + sp["xStart"] + vgl, ox + sp["xEnd"] - vgl, top_dim_y, y_top, str(int(round(sp["vungNhipLen"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                    sb.dim_h(ox + sp["xEnd"] - vgl, ox + sp["xEnd"], top_dim_y, y_top, str(int(round(vgl))), font_size=115.0, tick_size=40.0, overshoot=80.0)
                else:
                    sb.dim_h(ox + sp["xStart"], ox + sp["xEnd"], top_dim_y, y_top, str(int(round(sp["L_thongThuy"]))), font_size=115.0, tick_size=40.0, overshoot=80.0)

        # Bottom Grid-to-Grid & Total Grid Span dimension chains
        for i in range(len(grid_lines) - 1):
            a1, a2 = grid_lines[i]["x"], grid_lines[i + 1]["x"]
            sb.dim_h(ox + a1, ox + a2, axis_dim1_y, bot_start, str(int(round(a2 - a1))), font_size=120.0, tick_size=42.0, overshoot=80.0)
        if len(grid_lines) >= 2:
            a0, an = grid_lines[0]["x"], grid_lines[-1]["x"]
            sb.dim_h(ox + a0, ox + an, axis_dim2_y, bot_start, str(int(round(an - a0))), font_size=120.0, tick_size=42.0, overshoot=80.0)

        # Left vertical height dim (H_dam + optional first đài height)
        sb.dim_v(y_top, y_bot, ox - 280.0, 0.0, str(int(round(H_dam))), font_size=120.0, tick_size=42.0, overshoot=80.0, text_side="left", rotate_text=True)
        if comp["supportSegments"]:
            sup0 = comp["supportSegments"][0]
            y_dtop0 = float(sup0.get("daiTopOffset", 0.0))
            dh0 = float(sup0.get("daiH", H_dam))
            if abs(dh0 - H_dam) > 15.0:
                sb.dim_v(y_dtop0, y_dtop0 + dh0, ox - 480.0, 0.0, str(int(round(dh0))), font_size=110.0, tick_size=38.0, overshoot=70.0, text_side="left", rotate_text=True)

        sb.elevation_flag(-120.0, y_top, format_elevation(cfg["caoTrinhTop"]), scale=s_elev, side="left", ox=ox)
        sb.title_block(tong_l / 2.0, elev_title_y, "DẦM %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]), "TL: 1/%d" % cfg["tiLeMatDung"], font_title=210.0, font_scale=120.0, ox=ox, underline_dxf=True)

    if view_mode in ("sheet", "section"):
        def sx(val):
            return sec_ox + val * sec_s

        def sy(val):
            return sec_oy + val * sec_s

        s_sec = max(18.0, float(cfg["tiLeMatCat"])) * sec_s
        sb.rect(sx(sec_l), sy(sec_t), (sec_r - sec_l) * sec_s, (sec_b - sec_t) * sec_s, stroke=None, fill=None, width=0.0, layer="Defpoints")
        if lot_day > 0:
            if sb.layers.get("DCE_Hatch", True):
                sb.hatch_concrete([
                    (-lean_half * sec_s, H_dam * sec_s),
                    (lean_half * sec_s, H_dam * sec_s),
                    (lean_half * sec_s, (H_dam + lot_day) * sec_s),
                    (-lean_half * sec_s, (H_dam + lot_day) * sec_s),
                ], ox=sec_ox, oy=sec_oy, scale=25.4 * (s_sec / 25.0), pattern="AR-CONC")
            if sb.layers.get("DCE_BaoBeTong", True):
                sb.rect(sx(-lean_half), sy(H_dam), 2 * lean_half * sec_s, lot_day * sec_s, stroke=CAD["concrete"], fill=None, width=4.0, layer="DCE_BaoBeTong")
        if sb.layers.get("DCE_BaoBeTong", True):
            sb.rect(sx(-b_half), sy(0), B_dam * sec_s, H_dam * sec_s, stroke=CAD["concrete"], fill=None, width=4.5, layer="DCE_BaoBeTong")
        cover = float(cfg["cover"])
        st_l, st_r, st_t, st_b = -b_half + cover, b_half - cover, cover, H_dam - cover
        dt1 = st_t + max(18.0, cfg["thepTren1D"] * 1.1)
        dt2 = dt1 + max(48.0, cfg["thepTren2D"] * 2.8)
        db = st_b - max(18.0, cfg["thepDuoiD"] * 1.1)
        mid_y = H_dam / 2.0

        n_tren2 = max(0, int(cfg.get("thepTren2Count", 0)))
        n_gia = max(0, int(cfg.get("thepGiaCount", 0)))
        if sb.layers.get("DCE_ThepDai", True):
            sb.rect(sx(st_l), sy(st_t), (st_r - st_l) * sec_s, (st_b - st_t) * sec_s, stroke=CAD["stirrup"], fill=None, width=5.0, layer="DCE_ThepDai")
            # 135-deg outer stirrup corner hook
            sb.line(sx(st_l), sy(st_t), sx(st_l + 32), sy(st_t + 32), CAD["stirrup"], 4.5, "DCE_ThepDai")
            if n_tren2 > 0:
                # C-tie (6) clamping layer 2 top bars
                sb.polyline([
                    (sx(st_l + 30), sy(dt2 + 32)), (sx(st_l), sy(dt2 + 32)),
                    (sx(st_l), sy(dt2)), (sx(st_r), sy(dt2)),
                    (sx(st_r), sy(dt2 + 32)), (sx(st_r - 30), sy(dt2 + 32)),
                ], CAD["stirrup"], 4.5, "DCE_ThepDai")
            if n_gia > 0:
                # C-tie (7) clamping mid-depth skin bars
                sb.polyline([
                    (sx(st_l + 30), sy(mid_y - 36)), (sx(st_l), sy(mid_y - 36)),
                    (sx(st_l), sy(mid_y)), (sx(st_r), sy(mid_y)),
                    (sx(st_r), sy(mid_y - 36)), (sx(st_r - 30), sy(mid_y - 36)),
                ], CAD["stirrup"], 4.5, "DCE_ThepDai")

        if sb.layers.get("DCE_ThepChu", True):
            bar_groups = [(cfg["thepTren1Count"], dt1, cfg["thepTren1D"]), (cfg["thepDuoiCount"], db, cfg["thepDuoiD"])]
            if n_tren2 > 0:
                bar_groups.append((n_tren2, dt2, cfg["thepTren2D"]))
            for cnt, cy_dot, diam in bar_groups:
                n = max(1, int(cnt))
                for i in range(n):
                    dx = ((st_l + st_r) / 2.0) if n == 1 else (st_l + 22 + (st_r - st_l - 44) * i / float(n - 1))
                    sb.circle(sx(dx), sy(cy_dot), max(10.0, diam * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
            if n_gia > 0:
                sb.circle(sx(st_l + 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")
                sb.circle(sx(st_r - 22), sy(mid_y), max(8.0, cfg["thepGiaD"] * 0.75) * sec_s, stroke=CAD["rebar"], fill=CAD["rebar"], width=1.0, layer="DCE_ThepChu")

            # Stacked left callouts: (6), (1), (7), (4), (5), (2) + right (3)
            lx_c = -lean_half - 440.0
            if n_tren2 > 0:
                sb.callout(sx(lx_c), sy(dt1 - 165), "6", "Ø%da%d" % (cfg["thepDaiCTrenD"], cfg["thepDaiCTrenA"]),
                           [(sx(lx_c + 65), sy(dt1 - 165)), (sx(st_l + 30), sy(dt1 - 165)), (sx(st_l + 30), sy(dt2))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(dt1 - 20), "1", "%dØ%d" % (cfg["thepTren1Count"], cfg["thepTren1D"]),
                       [(sx(lx_c + 65), sy(dt1 - 20)), (sx(st_l + 22), sy(dt1))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            if n_gia > 0:
                sb.callout(sx(lx_c), sy(mid_y - 125), "7", "Ø%da%d" % (cfg["thepDaiCHongD"], cfg["thepDaiCHongA"]),
                           [(sx(lx_c + 65), sy(mid_y - 125)), (sx(st_l), sy(mid_y))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
                sb.callout(sx(lx_c), sy(mid_y + 20), "4", "%dØ%d" % (n_gia, cfg["thepGiaD"]),
                           [(sx(lx_c + 65), sy(mid_y + 20)), (sx(st_l + 22), sy(mid_y))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(mid_y + 185), "5", "Ø%da%d/%d" % (cfg["thepDaiD"], cfg["thepDaiAGoi"], cfg["thepDaiANhip"]),
                       [(sx(lx_c + 65), sy(mid_y + 185)), (sx(st_l), sy(mid_y + 185))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            sb.callout(sx(lx_c), sy(H_dam + lot_day + 80), "2", "%dØ%d" % (cfg["thepDuoiCount"], cfg["thepDuoiD"]),
                       [(sx(lx_c + 65), sy(H_dam + lot_day + 80)), (sx(st_l + 22), sy(H_dam + lot_day + 80)), (sx(st_l + 22), sy(db))], "left", r=2.0 * s_sec, font_size=1.8 * s_sec)
            if n_tren2 > 0:
                sb.callout(sx(lean_half + 320), sy(dt2), "3", "%dØ%d" % (n_tren2, cfg["thepTren2D"]),
                           [(sx(lean_half + 255), sy(dt2)), (sx(st_r - 22), sy(dt2))], "right", r=2.0 * s_sec, font_size=1.8 * s_sec)

        sb.elevation_flag(b_half + 100, 0.0, format_elevation(cfg["caoTrinhTop"]), scale=s_sec / sec_s, side="right", ox=sec_ox + b_half * (sec_s - 1.0), oy=sec_oy)
        # Bottom MC 1-1 dim chain: lotChia | B_dam | lotChia
        y_mc_b = sy(H_dam + lot_day + 160)
        if lot_chia > 0:
            sb.dim_h(sx(-lean_half), sx(-b_half), y_mc_b, sy(H_dam + lot_day), str(int(round(lot_chia))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        sb.dim_h(sx(-b_half), sx(b_half), y_mc_b, sy(H_dam), str(int(round(B_dam))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)
        if lot_chia > 0:
            sb.dim_h(sx(b_half), sx(lean_half), y_mc_b, sy(H_dam + lot_day), str(int(round(lot_chia))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_above=False)

        sb.dim_v(sy(0), sy(H_dam), sx(-b_half - 180), sx(-b_half), str(int(round(H_dam))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_side="left", rotate_text=True)
        if lot_day > 0:
            sb.dim_v(sy(H_dam), sy(H_dam + lot_day), sx(-b_half - 180), sx(-lean_half), str(int(round(lot_day))), font_size=48.0 * sec_s, tick_size=16.0 * sec_s, overshoot=28.0 * sec_s, text_side="left", rotate_text=True)
        sb.title_block(sx(0), sy(H_dam + lot_day + 440), "DẦM %s (SL=%d; L=%d)" % (cfg["ten"], cfg["soLuong"], comp["tongL"]), "MC 1-1 (TỶ LỆ 1/%d)" % cfg["tiLeMatCat"], font_title=65.0 * sec_s, font_scale=44.0 * sec_s, underline_dxf=True, underline_scale_dxf=True)

    if view_mode == "sheet" and include_schedule:
        tbl_sc = max(1.15, min(1.75, max(1.15, (tong_l - (sec_r - sec_l) * sec_s) / 3150.0)))
        tbl_x = sx(sec_r) + 460.0
        tbl_y = sy(sec_t)
        sb.draw_rebar_table(
            tbl_x,
            tbl_y,
            "BẢNG THỐNG KÊ THÉP - DẦM MÓNG %s (SL=%d)" % (cfg["ten"], cfg["soLuong"]),
            comp.get("rebarSchedule"),
            by_diam=comp.get("rebarByDiameter"),
            scale=tbl_sc,
        )


def build_cad_scene(module, items, active_id, view_mode, layers, all_module_lists=None):
    """Build complete scene dict for the active module & view mode."""
    sb = SceneBuilder(layers)
    active = None
    for it in items:
        if it["id"] == active_id:
            active = it
            break
    if active is None and items:
        active = items[0]
    if active is None:
        return sb.build_result()

    if module == "mong_don":
        if view_mode == "all":
            cur_x = 0.0
            for it in items:
                half_b = float(it["B"]) / 2.0
                ox = cur_x + half_b + 1100.0
                _draw_single_footing(sb, it, "sheet", ox=ox)
                cur_x = ox + half_b + 1600.0
        else:
            _draw_single_footing(sb, active, view_mode, ox=0.0)
    elif module == "mong_bang":
        if view_mode == "all_strip":
            cur_x = 0.0
            for it in items:
                comp = compute_strip_footing(it)
                ox = cur_x + 1400.0
                _draw_strip_footing(sb, it, "sheet", ox=ox)
                cur_x = ox + float(comp["tongL"]) + 1500.0
        else:
            _draw_strip_footing(sb, active, view_mode, ox=0.0)
    elif module == "mong_coc":
        if view_mode == "all":
            cur_x = 0.0
            for it in items:
                half_b = float(it["B"]) / 2.0
                ox = cur_x + half_b + 1200.0
                _draw_pile_cap(sb, it, "sheet", ox=ox)
                cur_x = ox + half_b + 1500.0
        else:
            _draw_pile_cap(sb, active, view_mode, ox=0.0)
    elif module == "dam_mong":
        if view_mode == "all_strip":
            cur_x = 0.0
            for it in items:
                comp = compute_foundation_beam(it)
                ox = cur_x + 1100.0
                _draw_foundation_beam(sb, it, "sheet", ox=ox)
                cur_x = ox + float(comp["tongL"]) + 1300.0
        else:
            _draw_foundation_beam(sb, active, view_mode, ox=0.0)

    return sb.build_result()


def build_full_project_dxf_scene(footings, strips, pile_caps, beams, layers, include_schedule=False):
    """Arrange all 4 foundation modules into 1 AutoCAD DXF detailing sheet (rebar schedule optional)."""
    sb = SceneBuilder(layers)
    row_top = 0.0
    row_gap = 2400.0

    def _emit_row(header_title, items, draw_cb, step_advance_fn):
        if not items:
            return None
        row_sb = SceneBuilder(layers)
        cur_x = 0.0
        for it in items:
            ox, adv = step_advance_fn(it, cur_x)
            draw_cb(row_sb, it, "sheet", ox=ox, include_schedule=False)
            cur_x = adv
        res = row_sb.build_result()
        rmin_x, rmin_y, rmax_x, rmax_y = res["bounds"]
        dy = row_top - rmin_y + 520.0
        dx = -rmin_x
        sb.text(0.0, row_top, header_title, CAD["titleText"], 220.0, "start", "DCE_Block", bold=True, underline=True)
        for p in res["primitives"]:
            q = dict(p)
            kind = q.get("kind")
            if kind == "line":
                sb.line(q["x1"] + dx, q["y1"] + dy, q["x2"] + dx, q["y2"] + dy, q["color"], q["width"], q["layer"], q.get("dash"))
            elif kind == "rect":
                sb.rect(q["x"] + dx, q["y"] + dy, q["w"], q["h"], q["color"], q["fill"], q["width"], q["layer"], q.get("dash"))
            elif kind == "polygon":
                sb.polygon([(px + dx, py + dy) for (px, py) in q["pts"]], q["color"], q["fill"], q["width"], q["layer"], q.get("dash"))
            elif kind == "polyline":
                sb.polyline([(px + dx, py + dy) for (px, py) in q["pts"]], q["color"], q["width"], q["layer"], q.get("closed", False), q.get("dash"))
            elif kind == "circle":
                sb.circle(q["cx"] + dx, q["cy"] + dy, q["r"], q["color"], q["fill"], q["width"], q["layer"], q.get("dash"))
            elif kind == "hatch_conc":
                sb.hatch_concrete(q["outer"], q.get("hole"), ox=dx, oy=dy, scale=q.get("scale", 15.0), pattern=q.get("pattern", "AR-CONC"))
            elif kind == "text":
                sb.text(q["x"] + dx, q["y"] + dy, q["text"], q["color"], q["size"], q.get("anchor", "middle"), q["layer"], q.get("bold", False), q.get("rotate", 0.0), q.get("underline", False))
        return row_top + (rmax_y - rmin_y) + 520.0 + row_gap

    nxt = _emit_row(
        "I. TRIỂN KHAI MÓNG ĐƠN", footings, _draw_single_footing,
        lambda it, cx: (cx + max(float(it["B"]) / 2.0 + 1150.0, 1650.0), cx + max(float(it["B"]) + 2800.0, 3800.0)),
    )
    if nxt is not None:
        row_top = nxt

    nxt = _emit_row(
        "II. TRIỂN KHAI MÓNG CỌC", pile_caps, _draw_pile_cap,
        lambda it, cx: (cx + max(float(it["B"]) / 2.0 + 1250.0, 1750.0), cx + max(float(it["B"]) + 2900.0, 4000.0)),
    )
    if nxt is not None:
        row_top = nxt

    nxt = _emit_row(
        "III. TRIỂN KHAI MÓNG BĂNG", strips, _draw_strip_footing,
        lambda it, cx: (cx + 1400.0, cx + float(compute_strip_footing(it)["tongL"]) + 3200.0),
    )
    if nxt is not None:
        row_top = nxt

    nxt = _emit_row(
        "IV. TRIỂN KHAI DẦM MÓNG", beams, _draw_foundation_beam,
        lambda it, cx: (cx + 1100.0, cx + float(compute_foundation_beam(it)["tongL"]) + 2400.0),
    )
    if nxt is not None:
        row_top = nxt

    if include_schedule:
        proj_sum = build_project_rebar_summary(footings, strips, pile_caps, beams)
        if proj_sum["rows"]:
            sb.draw_rebar_table(
                0.0,
                row_top,
                "V. BẢNG TỔNG HỢP THỐNG KÊ THÉP TOÀN DỰ ÁN (TỔNG: %.1f kg)" % proj_sum["totalKg"],
                proj_sum["rows"],
                by_diam=proj_sum["byDiameter"],
                scale=1.35,
                show_kind=True,
            )

    return sb.build_result()


# ==================== WPF CANVAS VECTOR RENDERER (CPython 3 SAFE) ====================

def render_scene_to_wpf_canvas(canvas, scene, zoom=1.0, pan_x=0.0, pan_y=0.0):
    """
    Render scene primitives directly onto a System.Windows.Controls.Canvas.
    All numeric values are explicitly cast to Python float() for pythonnet 3.x compatibility.
    Returns (s, ox, oy) for mouse coordinate readout.
    """
    from System.Windows import FontWeights, Point
    from System.Windows.Controls import Canvas, TextBlock
    from System.Windows.Media import BrushConverter, DoubleCollection, FontFamily, PointCollection, RotateTransform
    from System.Windows.Shapes import Ellipse, Line, Polygon, Polyline, Rectangle

    canvas.Children.Clear()
    cw = float(canvas.ActualWidth) if canvas.ActualWidth and float(canvas.ActualWidth) > 20.0 else 860.0
    ch = float(canvas.ActualHeight) if canvas.ActualHeight and float(canvas.ActualHeight) > 20.0 else 640.0

    min_x, min_y, max_x, max_y = scene["bounds"]
    world_w = max(400.0, max_x - min_x)
    world_h = max(400.0, max_y - min_y)
    pad = 28.0
    base_scale = min((cw - 2.0 * pad) / world_w, (ch - 2.0 * pad) / world_h)
    s = float(base_scale * zoom)
    cx_w = (min_x + max_x) / 2.0
    cy_w = (min_y + max_y) / 2.0
    ox = cw / 2.0 + float(pan_x) - cx_w * s
    oy = ch / 2.0 + float(pan_y) - cy_w * s

    brush_cache = {}
    conv = BrushConverter()

    def get_brush(hex_str):
        if not hex_str:
            return None
        b = brush_cache.get(hex_str)
        if b is None:
            b = conv.ConvertFromString(hex_str)
            if b.CanFreeze:
                b.Freeze()
            brush_cache[hex_str] = b
        return b

    # Background CAD minor grid
    grid_brush = get_brush("#1B212C")
    grid_step_w = 1000.0 if (world_w > 4500.0) else 400.0
    step_px = grid_step_w * s
    if step_px >= 14.0:
        gx0 = math.floor((-ox) / step_px) * step_px + ox
        while gx0 < cw:
            gl = Line()
            gl.X1 = float(gx0)
            gl.Y1 = float(0.0)
            gl.X2 = float(gx0)
            gl.Y2 = float(ch)
            gl.Stroke = grid_brush
            gl.StrokeThickness = float(0.8)
            canvas.Children.Add(gl)
            gx0 += step_px
        gy0 = math.floor((-oy) / step_px) * step_px + oy
        while gy0 < ch:
            gl = Line()
            gl.X1 = float(0.0)
            gl.Y1 = float(gy0)
            gl.X2 = float(cw)
            gl.Y2 = float(gy0)
            gl.Stroke = grid_brush
            gl.StrokeThickness = float(0.8)
            canvas.Children.Add(gl)
            gy0 += step_px

    mono_font = FontFamily("Consolas")
    sans_font = FontFamily("Segoe UI")

    for prim in scene.get("primitives", []):
        kind = prim["kind"]
        stroke_b = get_brush(prim.get("color"))
        fill_b = get_brush(prim.get("fill"))
        sw = max(0.9, float(prim.get("width", 3.0)) * s * 0.62)
        dash_vals = prim.get("dash")

        if kind == "line":
            el = Line()
            el.X1 = float(ox + prim["x1"] * s)
            el.Y1 = float(oy + prim["y1"] * s)
            el.X2 = float(ox + prim["x2"] * s)
            el.Y2 = float(oy + prim["y2"] * s)
            el.Stroke = stroke_b
            el.StrokeThickness = float(sw)
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            canvas.Children.Add(el)

        elif kind == "rect":
            rw = float(prim["w"]) * s
            rh = float(prim["h"]) * s
            if rw <= 0.1 or rh <= 0.1:
                continue
            el = Rectangle()
            el.Width = float(rw)
            el.Height = float(rh)
            if stroke_b is not None:
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
            if fill_b is not None:
                el.Fill = fill_b
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            Canvas.SetLeft(el, float(ox + prim["x"] * s))
            Canvas.SetTop(el, float(oy + prim["y"] * s))
            canvas.Children.Add(el)

        elif kind in ("polygon", "polyline"):
            pc = PointCollection()
            for px, py in prim["pts"]:
                pc.Add(Point(float(ox + px * s), float(oy + py * s)))
            if kind == "polygon":
                el = Polygon()
                el.Points = pc
                if stroke_b is not None:
                    el.Stroke = stroke_b
                    el.StrokeThickness = float(sw)
                if fill_b is not None:
                    el.Fill = fill_b
                canvas.Children.Add(el)
            else:
                el = Polyline()
                el.Points = pc
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
                canvas.Children.Add(el)

        elif kind == "circle":
            rad = max(1.2, float(prim["r"]) * s)
            el = Ellipse()
            el.Width = float(rad * 2.0)
            el.Height = float(rad * 2.0)
            if stroke_b is not None:
                el.Stroke = stroke_b
                el.StrokeThickness = float(sw)
            if fill_b is not None:
                el.Fill = fill_b
            if dash_vals:
                dc = DoubleCollection()
                for dv in dash_vals:
                    dc.Add(float(max(2.0, dv * s / max(0.8, sw))))
                el.StrokeDashArray = dc
            Canvas.SetLeft(el, float(ox + prim["cx"] * s - rad))
            Canvas.SetTop(el, float(oy + prim["cy"] * s - rad))
            canvas.Children.Add(el)

        elif kind == "hatch_conc":
            outer = prim.get("outer") or []
            hole = prim.get("hole")
            if len(outer) >= 3:
                pc = PointCollection()
                for px, py in outer:
                    pc.Add(Point(float(ox + px * s), float(oy + py * s)))
                el = Polygon()
                el.Points = pc
                el.Fill = get_brush(prim.get("fill") or "#171B22")
                canvas.Children.Add(el)

                if hole and len(hole) >= 3:
                    hpc = PointCollection()
                    for px, py in hole:
                        hpc.Add(Point(float(ox + px * s), float(oy + py * s)))
                    hel = Polygon()
                    hel.Points = hpc
                    hel.Fill = get_brush(CAD["bg"])
                    canvas.Children.Add(hel)

                # Concrete aggregate stipple (AR-CONC visual pattern on WPF canvas)
                oxs = [p[0] for p in outer]
                oys = [p[1] for p in outer]
                hx0, hx1 = min(oxs), max(oxs)
                hy0, hy1 = min(oys), max(oys)
                hxs = [p[0] for p in hole] if hole else None
                hys = [p[1] for p in hole] if hole else None
                ix0, ix1 = (min(hxs), max(hxs)) if hxs else (1e18, -1e18)
                iy0, iy1 = (min(hys), max(hys)) if hys else (1e18, -1e18)

                def _pt_in_poly(ptx, pty, poly_pts):
                    inside = False
                    n = len(poly_pts)
                    j = n - 1
                    for ii in range(n):
                        xi, yi = poly_pts[ii]
                        xj, yj = poly_pts[j]
                        if ((yi > pty) != (yj > pty)) and (ptx < (xj - xi) * (pty - yi) / ((yj - yi) or 1e-9) + xi):
                            inside = not inside
                        j = ii
                    return inside

                step_g = max(48.0, float(prim.get("scale", 15.0)) * 4.5)
                agg_b = get_brush("#4B5563")
                gx = hx0 + step_g * 0.4
                row_i = 0
                while gx < hx1 - 8.0:
                    gy = hy0 + step_g * 0.4 + ((row_i % 2) * step_g * 0.35)
                    col_i = 0
                    while gy < hy1 - 8.0:
                        if (not hole or not (ix0 - 4.0 <= gx <= ix1 + 4.0 and iy0 - 4.0 <= gy <= iy1 + 4.0 and _pt_in_poly(gx, gy, hole))) and _pt_in_poly(gx, gy, outer):
                            sx_p = ox + gx * s
                            sy_p = oy + gy * s
                            if (row_i + col_i) % 3 == 0:
                                tri = Polygon()
                                tpc = PointCollection()
                                tr_r = max(1.6, 11.0 * s)
                                tpc.Add(Point(float(sx_p), float(sy_p - tr_r)))
                                tpc.Add(Point(float(sx_p - tr_r * 0.9), float(sy_p + tr_r * 0.7)))
                                tpc.Add(Point(float(sx_p + tr_r * 0.9), float(sy_p + tr_r * 0.7)))
                                tri.Points = tpc
                                tri.Stroke = agg_b
                                tri.StrokeThickness = float(max(0.7, 1.4 * s))
                                canvas.Children.Add(tri)
                            else:
                                dot = Ellipse()
                                dr = max(1.0, 4.0 * s)
                                dot.Width = float(dr)
                                dot.Height = float(dr)
                                dot.Fill = agg_b
                                Canvas.SetLeft(dot, float(sx_p - dr * 0.5))
                                Canvas.SetTop(dot, float(sy_p - dr * 0.5))
                                canvas.Children.Add(dot)
                        gy += step_g
                        col_i += 1
                    gx += step_g
                    row_i += 1

        elif kind == "text":
            fs = float(prim["size"]) * s * 0.92
            if fs < 5.0:
                continue
            tb = TextBlock()
            tb.Text = str(prim["text"])
            tb.Foreground = stroke_b if stroke_b is not None else get_brush("#E2E8F0")
            tb.FontSize = float(min(36.0, fs))
            tb.FontFamily = sans_font if prim["size"] >= 70.0 else mono_font
            if prim.get("bold"):
                tb.FontWeight = FontWeights.SemiBold
            tx = float(ox + prim["x"] * s)
            ty = float(oy + prim["y"] * s)
            est_w = len(tb.Text) * tb.FontSize * 0.58
            rot = float(prim.get("rotate", 0.0))
            anchor = prim.get("anchor", "middle")
            if abs(rot) > 1.0:
                tb.RenderTransform = RotateTransform(rot)
                if rot < 0:
                    if anchor == "middle":
                        Canvas.SetLeft(tb, float(tx - tb.FontSize * 0.55))
                        Canvas.SetTop(tb, float(ty + est_w / 2.0))
                    elif anchor == "end":
                        Canvas.SetLeft(tb, float(tx - tb.FontSize * 0.55))
                        Canvas.SetTop(tb, float(ty + est_w))
                    else:
                        Canvas.SetLeft(tb, float(tx - tb.FontSize * 0.55))
                        Canvas.SetTop(tb, float(ty))
                else:
                    Canvas.SetLeft(tb, float(tx))
                    Canvas.SetTop(tb, float(ty))
            else:
                if anchor == "middle":
                    tx -= est_w / 2.0
                elif anchor == "end":
                    tx -= est_w
                Canvas.SetLeft(tb, float(tx))
                Canvas.SetTop(tb, float(ty - tb.FontSize * 0.68))
            canvas.Children.Add(tb)
            if prim.get("underline") and abs(rot) <= 1.0:
                ul = Line()
                ul.X1 = float(tx)
                ul.Y1 = float(oy + prim["y"] * s + tb.FontSize * 0.55)
                ul.X2 = float(tx + est_w)
                ul.Y2 = ul.Y1
                ul.Stroke = tb.Foreground
                ul.StrokeThickness = float(max(1.2, tb.FontSize * 0.08))
                canvas.Children.Add(ul)

    return s, ox, oy
